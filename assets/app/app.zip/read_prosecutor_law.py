import os
from law_parser import get_law_text

def main():
    law_name = "ПРОКУРОРЫН ТУХАЙ.doc"
    try:
        print(f"Reading '{law_name}'...")
        text = get_law_text(law_name)
        output_file = os.path.join("C:\\Users\\DELL\\PycharmProjects\\pythonProject", "prosecutor_law.txt")
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"Successfully saved to {output_file}. Length: {len(text)} characters.")
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
