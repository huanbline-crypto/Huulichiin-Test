import cv2
import numpy as np
import os
import sys
import pytesseract
from PIL import Image as PILImage
from docx import Document
from docx.shared import Inches, Pt
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

img_path = r"E:\OCR\2025 оны шинэ жилийн зардал.jpg"
docx_path = r"E:\OCR\enhanced\output_mixed_test.docx"

if not os.path.exists(img_path):
    print("Error: Image not found")
    sys.exit(1)

# Read image
with open(img_path, "rb") as f:
    data = np.frombuffer(f.read(), dtype=np.uint8)
img = cv2.imdecode(data, cv2.IMREAD_COLOR)
h_orig, w_orig = img.shape[:2]

# If image is dark, invert it
gray_check = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
if np.mean(gray_check) < 127:
    img = 255 - img
    gray_check = 255 - gray_check

# Resize for table detection
target_w = 1200
scale = target_w / w_orig
img_resized = cv2.resize(img, (target_w, int(h_orig * scale)))
gray = cv2.cvtColor(img_resized, cv2.COLOR_BGR2GRAY)

# Binarize
thresh = cv2.adaptiveThreshold(
    ~gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 15, -2
)

# Extract lines
cols = thresh.shape[1]
horizontal_size = cols // 40
horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (horizontal_size, 1))
horizontal_lines = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, horizontal_kernel)

rows = thresh.shape[0]
vertical_size = rows // 40
vertical_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, vertical_size))
vertical_lines = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, vertical_kernel)

grid = cv2.add(horizontal_lines, vertical_lines)

# Find table contours
table_contours, _ = cv2.findContours(grid, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

main_table = None
max_area = 0
for cnt in table_contours:
    x, y, w, h = cv2.boundingRect(cnt)
    if w > 200 and h > 200:
        area = w * h
        if area > max_area:
            max_area = area
            main_table = (x, y, w, h, cnt)

has_table = False
cells = []

if main_table is not None:
    tx, ty, tw, th, tcnt = main_table
    table_grid = grid[ty:ty+th, tx:tx+tw]
    cell_contours, _ = cv2.findContours(table_grid, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    for cnt in cell_contours:
        cx, cy, cw, ch = cv2.boundingRect(cnt)
        if 15 < cw < tw - 15 and 15 < ch < th - 15:
            is_parent = False
            for cnt2 in cell_contours:
                c2x, c2y, c2w, c2h = cv2.boundingRect(cnt2)
                if (c2w < cw or c2h < ch) and c2x > cx and c2y > cy and c2x+c2w < cx+cw and c2y+c2h < cy+ch:
                    is_parent = True
                    break
            if not is_parent:
                cells.append((cx + tx, cy + ty, cw, ch))

    if len(cells) >= 4:
        has_table = True

# Create docx
doc = Document()

# Get available languages
try:
    available_langs = pytesseract.get_languages()
except Exception:
    available_langs = []
langs_to_use = [l for l in ["mon", "rus", "eng"] if l in available_langs]
if not langs_to_use:
    langs_to_use = ["eng"]
lang_str = "+".join(langs_to_use)
config = f"--psm 6 -l {lang_str}"

def ocr_region(image, y_start_scale, y_end_scale):
    # Scale coordinates back to original image size
    y_start = int(y_start_scale / scale)
    y_end = int(y_end_scale / scale)
    
    crop = image[y_start:y_end, 0:w_orig]
    if crop.size == 0 or crop.shape[0] < 10:
        return ""
        
    crop_gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    if crop_gray.shape[0] < 2000:
        s = 2000 / crop_gray.shape[0]
        crop_gray = cv2.resize(crop_gray, None, fx=s, fy=s, interpolation=cv2.INTER_CUBIC)
        
    _, crop_bin = cv2.threshold(crop_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    pil_img = PILImage.fromarray(crop_bin)
    
    # Use PSM 3 for generic multi-line unstructured text blocks
    text = pytesseract.image_to_string(pil_img, config=f"--psm 3 -l {lang_str}")
    return text.strip()

if has_table:
    # Get actual Y boundaries of table from cell coordinates
    y_grid_start = min(y for (x, y, w, h) in cells)
    y_grid_end = max(y + h for (x, y, w, h) in cells)
    
    print(f"Table grid Y boundaries: {y_grid_start} to {y_grid_end}")
    
    # 1. OCR Plain text above table
    print("Running OCR on header region...")
    header_text = ocr_region(img, 0, y_grid_start)
    if header_text:
        for line in header_text.splitlines():
            if line.strip():
                doc.add_paragraph(line.strip())
                
    # 2. Reconstruct Table
    print("Reconstructing table grid...")
    x_coords = sorted([x for (x, y, w, h) in cells] + [x + w for (x, y, w, h) in cells])
    y_coords = sorted([y for (x, y, w, h) in cells] + [y + h for (x, y, w, h) in cells])
    
    col_edges = merge_coords = sorted(list(set(x_coords)))
    row_edges = sorted(list(set(y_coords)))
    
    # Merge helper
    def merge_c(coords, tol):
        if not coords:
            return []
        merged = [coords[0]]
        for c in coords[1:]:
            if c - merged[-1] > tol:
                merged.append(c)
        return merged
        
    col_edges = merge_c(col_edges, 15)
    row_edges = merge_c(row_edges, 12)
    
    num_cols = len(col_edges) - 1
    num_rows = len(row_edges) - 1
    print(f"Grid size: {num_rows}x{num_cols}")
    
    grid_cells = [[None for _ in range(num_cols)] for _ in range(num_rows)]
    
    for cell in cells:
        cx, cy, cw, ch = cell
        overlapping_rows = []
        for r in range(num_rows):
            r_top = row_edges[r]
            r_bottom = row_edges[r+1]
            overlap = min(cy + ch, r_bottom) - max(cy, r_top)
            if overlap > 0.4 * (r_bottom - r_top) and overlap > 0.4 * ch:
                overlapping_rows.append(r)
                
        overlapping_cols = []
        for c in range(num_cols):
            c_left = col_edges[c]
            c_right = col_edges[c+1]
            overlap = min(cx + cw, c_right) - max(cx, c_left)
            if overlap > 0.4 * (c_right - c_left) and overlap > 0.4 * cw:
                overlapping_cols.append(c)
                
        if overlapping_rows and overlapping_cols:
            r_start = min(overlapping_rows)
            r_end = max(overlapping_rows)
            c_start = min(overlapping_cols)
            c_end = max(overlapping_cols)
            
            cell_info = {
                'box': cell,
                'r_start': r_start,
                'r_end': r_end,
                'c_start': c_start,
                'c_end': c_end
            }
            for r in range(r_start, r_end + 1):
                for c in range(c_start, c_end + 1):
                    grid_cells[r][c] = cell_info
                    
    docx_table = doc.add_table(rows=num_rows, cols=num_cols)
    processed_boxes = set()
    
    for r in range(num_rows):
        for c in range(num_cols):
            cell_info = grid_cells[r][c]
            if cell_info is None:
                continue
            box = cell_info['box']
            if box in processed_boxes:
                continue
            processed_boxes.add(box)
            bx, by, bw, bh = box
            
            docx_cell = docx_table.cell(cell_info['r_start'], cell_info['c_start'])
            if cell_info['r_start'] != cell_info['r_end'] or cell_info['c_start'] != cell_info['c_end']:
                target_cell = docx_table.cell(cell_info['r_end'], cell_info['c_end'])
                docx_cell = docx_cell.merge(target_cell)
                
            orig_x = int(bx / scale)
            orig_y = int(by / scale)
            orig_w = int(bw / scale)
            orig_h = int(bh / scale)
            
            orig_x_pad = max(0, orig_x - 2)
            orig_y_pad = max(0, orig_y - 2)
            orig_w_pad = min(w_orig - orig_x_pad, orig_w + 4)
            orig_h_pad = min(h_orig - orig_y_pad, orig_h + 4)
            
            cell_crop = img[orig_y_pad:orig_y_pad+orig_h_pad, orig_x_pad:orig_x_pad+orig_w_pad]
            cell_gray = cv2.cvtColor(cell_crop, cv2.COLOR_BGR2GRAY)
            if cell_gray.shape[0] < 50:
                cell_gray = cv2.resize(cell_gray, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)
                
            cell_text = pytesseract.image_to_string(cell_gray, config=config).strip()
            docx_cell.text = cell_text
            docx_cell.paragraphs[0].runs[0].font.size = Pt(9)
            
    # 3. OCR Plain text below table
    print("Running OCR on footer region...")
    footer_text = ocr_region(img, y_grid_end, thresh.shape[0])
    if footer_text:
        doc.add_paragraph("") # Spacing
        for line in footer_text.splitlines():
            if line.strip():
                doc.add_paragraph(line.strip())
else:
    # Regular plain text OCR
    print("No table found. Running plain text OCR...")
    gray_ocr = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    if max(h_orig, w_orig) < 2000:
        s = 2000 / max(h_orig, w_orig)
        gray_ocr = cv2.resize(gray_ocr, None, fx=s, fy=s, interpolation=cv2.INTER_CUBIC)
    _, binary_ocr = cv2.threshold(gray_ocr, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    pil_img = PILImage.fromarray(binary_ocr)
    text = pytesseract.image_to_string(pil_img, config=config)
    for line in text.splitlines():
        if line.strip():
            doc.add_paragraph(line.strip())

doc.save(docx_path)
print(f"Mixed document OCR completed. Saved: {docx_path}")
