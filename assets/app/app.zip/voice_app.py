"""
Ц.Энхбатын ухаалаг дуу хураагуур — PC хувилбар (Flet 0.85)
ЭЦСИЙН ТӨГС ЗАСВАР: Timeout алдаа гаргадаг FilePicker-ийг Tkinter-ээр сольж хавтас сонголтыг 100% асуудалгүй болгов.
"""
import flet as ft
import flet_audio_recorder as ftar
import time
import datetime
import os
import sys
import threading
import subprocess
import shutil
import asyncio
from tkinter import filedialog, Tk # Windows-ийн найдвартай хавтас сонгогч

if getattr(sys, "frozen", False):
    BUNDLE_DIR = sys._MEIPASS
    EXE_DIR    = os.path.dirname(sys.executable)
else:
    BUNDLE_DIR = os.path.dirname(os.path.abspath(__file__))
    EXE_DIR    = BUNDLE_DIR

ASSETS_DIR = os.path.join(BUNDLE_DIR, "assets")
OUTPUT_DIR = os.path.join(EXE_DIR, "Бичлэгүүд")
os.makedirs(ASSETS_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

IMG_SRC = None
for img in ("audio.png", "icon.png", "icon1.png"):
    if os.path.exists(os.path.join(ASSETS_DIR, img)):
        IMG_SRC = img
        break

FFMPEG = shutil.which("ffmpeg") or r"C:\ffmpeg\bin\ffmpeg.exe"
HAS_FFMPEG = shutil.which("ffmpeg") is not None or os.path.isfile(r"C:\ffmpeg\bin\ffmpeg.exe")


def open_file(path: str):
    try:
        if sys.platform == "win32":
            os.startfile(path)
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception as ex:
        print(f"Нээж чадсангүй: {ex}")


def wav_to_mp3(wav_path: str, mp3_path: str) -> bool:
    try:
        cmd = ["ffmpeg", "-y", "-i", wav_path, "-q:a", "2", mp3_path]
        r = subprocess.run(cmd, capture_output=True, timeout=120)
        return r.returncode == 0 and os.path.exists(mp3_path)
    except Exception:
        return False


def format_time(sec: float) -> str:
    h = int(sec // 3600)
    m = int((sec % 3600) // 60)
    s = int(sec % 60)
    return f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def format_size(path: str) -> str:
    try:
        b = os.path.getsize(path)
        if b < 1024:     return f"{b} B"
        if b < 1024**2:  return f"{b/1024:.1f} KB"
        return f"{b/1024**2:.2f} MB"
    except Exception:
        return "—"


def make_btn(label, icon, color, on_click=None, width=165):
    return ft.Button(
        content=ft.Row(
            [ft.Icon(icon, color="white", size=18),
             ft.Text(label, color="white", size=13, weight=ft.FontWeight.W_600)],
            tight=True, spacing=6),
        bgcolor=color, on_click=on_click,
        height=48, width=width,
        style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=12)),
    )


def main(page: ft.Page):
    page.title         = "Ц.Энхбатын ухаалаг дуу хураагуур 🎙️"
    page.window_width  = 680
    page.window_height = 840
    page.window_resizable = True
    page.theme_mode    = ft.ThemeMode.LIGHT
    page.padding       = 20
    page.bgcolor       = "#F3F4F6"

    # ── Багажууд ─────────────────────────────────────────────────────────────
    recorder = ftar.AudioRecorder()
    page.services.append(recorder)

    error_snack = ft.SnackBar(content=ft.Text(""), bgcolor=ft.Colors.RED_500)
    page.overlay.append(error_snack)

    # ── Төлөв ────────────────────────────────────────────────────────────────
    state = {
        "recording":    False,
        "paused":       False,
        "wav_path":     None,
        "start_time":   None,
        "pause_accum":  0.0,
        "pause_start":  None,
        "display_sec":  0.0,
        "output_dir":   OUTPUT_DIR
    }
    device_map = {}

    def show_err(msg):
        error_snack.content = ft.Text(msg)
        error_snack.open    = True
        status_text.value   = msg
        status_text.color   = ft.Colors.RED_600
        page.update()

    # ── UI элементүүд ─────────────────────────────────────────────────────────
    mic_dropdown = ft.Dropdown(
        label="Микрофон сонгох",
        options=[ft.dropdown.Option(key="default", text="🎙️  Default (системийн микрофон)")],
        value="default", width=600, bgcolor="white", border_radius=8,
    )

    fmt_options = [ft.dropdown.Option(key="wav", text="🎵  WAV — Өндөр чанар")]
    if HAS_FFMPEG:
        fmt_options.append(ft.dropdown.Option(key="mp3", text="🎧  MP3 — Шахсан формат"))
    else:
        fmt_options.append(ft.dropdown.Option(key="mp3", text="🎧  MP3 — Шахсан формат (WAV-аар хадгалагдана)"))

    format_dropdown = ft.Dropdown(
        label="Хадгалах формат", options=fmt_options, value="wav",
        width=340, bgcolor="white", border_radius=8,
    )

    timer_text = ft.Text("00:00", size=48, weight=ft.FontWeight.BOLD, color=ft.Colors.GREY_700)
    status_text = ft.Text("🎙️  Микрофон сонгоод эхлэнэ үү.", color=ft.Colors.GREY_600, size=13)
    dir_text = ft.Text(f"📁 Хадгалах газар: {state['output_dir']}", size=11, color=ft.Colors.GREY_500, italic=True)
    history_list = ft.ListView(expand=True, spacing=6, padding=8)

    # ── ЗАСВАР 1: Алдаа гаргадаг FilePicker-ийг Tkinter-ийн найдвартай хавтас сонгогчоор солив ──
    def choose_folder(e):
        try:
            root = Tk()
            root.withdraw() # Үндсэн хоосон цонхыг нуух
            root.attributes('-topmost', True) # Хавтас сонгох цонхыг хамгийн дээр гаргах
            selected_path = filedialog.askdirectory(initialdir=state["output_dir"])
            root.destroy()

            if selected_path:
                state["output_dir"] = os.path.normpath(selected_path)
                dir_text.value = f"📁 Хадгалах газар: {state['output_dir']}"
                load_history()
                status_text.value = "📁 Хадгалах хавтас амжилттай солигдлоо."
                status_text.color = ft.Colors.GREEN_700
                page.update()
        except Exception as ex:
            show_err(f"Хавтас сонгоход алдаа: {ex}")

    # ── Тоолуур ──────────────────────────────────────────────────────────────
    async def _timer_task():
        while state["recording"]:
            if not state["paused"]:
                elapsed = (time.time() - state["start_time"]) - state["pause_accum"]
                state["display_sec"] = elapsed
                timer_text.value = format_time(elapsed)
                timer_text.color = ft.Colors.RED_600
                page.update()
            await asyncio.sleep(0.2)

    # ── Хадгалагдсан файлуудын жагсаалт ────────────────────────────────────────
    def load_history():
        history_list.controls.clear()
        target_dir = state["output_dir"]
        try:
            files = sorted(
                [f for f in os.listdir(target_dir) if f.lower().endswith((".wav", ".mp3"))],
                reverse=True)
        except Exception:
            files = []

        if not files:
            history_list.controls.append(
                ft.Container(
                    content=ft.Text("Энэ хавтсанд бичлэг алга байна...", color=ft.Colors.GREY_400, italic=True),
                    alignment=ft.Alignment(0, 0), padding=24))
        else:
            for f in files:
                fpath = os.path.join(target_dir, f)
                try:
                    st     = os.stat(fpath)
                    dt_str = datetime.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d  %H:%M:%S")
                    sz     = format_size(fpath)
                    ext    = f.rsplit(".", 1)[-1].upper()
                    badge_color = ft.Colors.BLUE_700 if ext == "WAV" else ft.Colors.ORANGE_700

                    def _make_del(fp):
                        return lambda e: [os.remove(fp) if os.path.exists(fp) else None, load_history()]

                    tile = ft.Container(
                        content=ft.Row([
                            ft.Text("🎵" if ext == "WAV" else "🎧", size=26),
                            ft.Column([
                                ft.Text(f, size=12, weight=ft.FontWeight.W_600, overflow=ft.TextOverflow.ELLIPSIS),
                                ft.Row([
                                    ft.Container(
                                        content=ft.Text(ext, size=10, color="white", weight=ft.FontWeight.W_700),
                                        bgcolor=badge_color, border_radius=4, padding=ft.Padding(7, 7, 2, 2)),
                                    ft.Text(f"📅 {dt_str}", size=11, color=ft.Colors.GREY_600),
                                    ft.Text(f"💾 {sz}", size=11, color=ft.Colors.GREY_600),
                                ], spacing=8),
                            ], expand=True, spacing=3),
                            ft.Row([
                                ft.IconButton(icon=ft.Icons.PLAY_CIRCLE_OUTLINE, icon_color=ft.Colors.BLUE_600, icon_size=24, on_click=lambda e, fp=fpath: open_file(fp)),
                                ft.IconButton(icon=ft.Icons.DELETE_OUTLINE, icon_color=ft.Colors.RED_400, icon_size=24, on_click=_make_del(fpath)),
                            ], spacing=0),
                        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                        bgcolor="white", border_radius=10, padding=ft.Padding(14, 6, 10, 10),
                        shadow=ft.BoxShadow(blur_radius=5, color=ft.Colors.with_opacity(0.07, "black")),
                    )
                    history_list.controls.append(tile)
                except Exception:
                    pass
        page.update()

    # ── Микрофон татах ───────────────────────────────────────────────────────
    async def load_devices():
        try:
            devices = await recorder.get_input_devices()
            device_map.clear()
            new_opts = [ft.dropdown.Option(key="default", text="🎙️  Default (системийн микрофон)")]

            for d in devices:
                key = str(d.id)
                device_map[key] = d
                short = d.label if len(d.label) <= 54 else d.label[:51] + "..."
                new_opts.append(ft.dropdown.Option(key=key, text=f"  [{d.id}]  {short}"))

            mic_dropdown.options = new_opts
            page.update()
        except Exception as ex:
            status_text.value = f"ℹ️  Микрофон жагсаалт авах боломжгүй: {ex}"
            page.update()

    # ── Товчнууд ─────────────────────────────────────────────────────────────
    btn_row = ft.Row(alignment=ft.MainAxisAlignment.CENTER, spacing=14)

    rec_btn    = make_btn("Бичиж эхлэх",   ft.Icons.MIC,        ft.Colors.RED_600,    width=200)
    pause_btn  = make_btn("Түр зогсоох",   ft.Icons.PAUSE,      ft.Colors.ORANGE_600, width=175)
    resume_btn = make_btn("Үргэлжлүүлэх", ft.Icons.PLAY_ARROW,  ft.Colors.BLUE_700,   width=175)
    finish_btn = make_btn("Дуусгах",       ft.Icons.CHECK,      ft.Colors.GREEN_700,  width=145)

    def _show_idle():
        btn_row.controls         = [rec_btn]
        mic_dropdown.disabled    = False
        format_dropdown.disabled = False
        timer_text.color         = ft.Colors.GREY_700
        page.update()

    def _show_recording():
        btn_row.controls         = [pause_btn, finish_btn]
        mic_dropdown.disabled    = True
        format_dropdown.disabled = True
        page.update()

    def _show_paused():
        btn_row.controls = [resume_btn, finish_btn]
        page.update()

    # ── Бичиж эхлэх ──────────────────────────────────────────────────────────
    async def start_recording(e):
        if state["recording"]: return
        timer_text.value = "00:00"
        ts     = time.strftime("%Y%m%d_%H%M%S")
        wav_fp = os.path.join(state["output_dir"], f"_tmp_{ts}.wav")
        state.update({"wav_path": wav_fp, "start_time": time.time(), "pause_accum": 0.0, "pause_start": None, "display_sec": 0.0})

        sel_key = mic_dropdown.value
        sel_dev = device_map.get(sel_key) if sel_key != "default" else None

        config = ftar.AudioRecorderConfiguration(
            encoder=ftar.AudioEncoder.WAV, suppress_noise=True, cancel_echo=True, auto_gain=True, channels=1, sample_rate=44100, device=sel_dev,
        )
        try:
            ok = await recorder.start_recording(output_path=wav_fp, configuration=config)
            if ok is False: raise RuntimeError("Эхлүүлэх хариу ирсэнгүй")
            state["recording"] = True
            state["paused"]    = False
            status_text.value  = "🔴  Бичиж байна..."
            status_text.color  = ft.Colors.RED_600
            _show_recording()
            page.run_task(_timer_task)
        except Exception as ex:
            show_err(f"❌ Эхлэхэд алдаа: {ex}")

    # ── Түр зогсоох ──────────────────────────────────────────────────────────
    async def toggle_pause(e):
        if not state["recording"]: return
        try:
            if not state["paused"]:
                await recorder.pause_recording()
                state.update({"paused": True, "pause_start": time.time()})
                status_text.value = "⏸  Түр зогсоосон..."
                status_text.color = ft.Colors.ORANGE_600
                timer_text.color  = ft.Colors.ORANGE_600
                _show_paused()
            else:
                await recorder.resume_recording()
                if state["pause_start"]:
                    state["pause_accum"] += time.time() - state["pause_start"]
                state.update({"paused": False, "pause_start": None})
                status_text.value = "🔴  Бичиж байна..."
                status_text.color = ft.Colors.RED_600
                timer_text.color  = ft.Colors.RED_600
                _show_recording()
        except Exception as ex: show_err(f"❌ Үйлдэл амжилтгүй: {ex}")

    # ── Дуусгах ──────────────────────────────────────────────────────────────
    async def finish_recording(e):
        if not state["recording"]: return
        try:
            saved  = await recorder.stop_recording()
            wav_fp = saved or state["wav_path"]
            state["recording"] = False

            if state["pause_start"]:
                state["pause_accum"] += time.time() - state["pause_start"]

            elapsed = state["display_sec"]
            mn, sc  = int(elapsed // 60), int(elapsed % 60)
            timer_text.value = format_time(elapsed)
            timer_text.color = ft.Colors.GREEN_700
            status_text.value = f"⏳  Хадгалж байна...  ⏱ {mn}:{sc:02d}"
            status_text.color = ft.Colors.BLUE_600
            _show_idle()

            page.run_thread(_finalize, wav_fp, elapsed)
        except Exception as ex: show_err(f"❌ Дуусгахад алдаа: {ex}")

    def _finalize(wav_fp: str, elapsed: float):
        ts      = time.strftime("%Y%m%d_%H%M%S")
        mn, sc  = int(elapsed // 60), int(elapsed % 60)
        fmt     = format_dropdown.value
        target_dir = state["output_dir"]

        if fmt == "mp3" and wav_fp and os.path.exists(wav_fp):
            mp3_fp = os.path.join(target_dir, f"Bichleg_{ts}_{mn}m{sc:02d}s.mp3")
            status_text.value = "⏳  MP3 болгож хөрвүүлж байна..."
            page.update()
            if wav_to_mp3(wav_fp, mp3_fp):
                try: os.remove(wav_fp)
                except: pass
                final = mp3_fp
            else:
                final = os.path.join(target_dir, f"Bichleg_{ts}_{mn}m{sc:02d}s.wav")
                try: os.rename(wav_fp, final)
                except: final = wav_fp
        else:
            final = os.path.join(target_dir, f"Bichleg_{ts}_{mn}m{sc:02d}s.wav")
            if wav_fp and os.path.exists(wav_fp):
                try: os.rename(wav_fp, final)
                except: final = wav_fp

        if final and os.path.exists(final):
            sz  = format_size(final)
            status_text.value = f"✅  Хадгалагдлаа!  💾 {sz}  ⏱ {mn}:{sc:02d}"
            status_text.color = ft.Colors.GREEN_700
        else:
            status_text.value = "⚠️  Хадгалах үед алдаа гарлаа."
            status_text.color = ft.Colors.ORANGE_700
        load_history()

    # ── Сэргээх (Refresh) функц — ТҮҮХ БОЛОН ХУГАЦААГ ТЭГЛЭНЭ ──────────────────
    async def refresh_all(e):
        status_text.value = "🔄 Шинэчилж байна..."
        page.update()

        # Тоолуур болон секундүүдийг бүрэн тэгэлж цэвэрлэнэ
        state["display_sec"] = 0.0
        timer_text.value = "00:00"
        timer_text.color = ft.Colors.GREY_700

        await load_devices()
        load_history()
        status_text.value = "🎙️ Микрофон болон хугацаа тэгнэгдэж шинэчлэгдлээ."
        status_text.color = ft.Colors.GREEN_700
        page.update()

    rec_btn.on_click    = lambda e: page.run_task(start_recording, e)
    pause_btn.on_click  = lambda e: page.run_task(toggle_pause, e)
    resume_btn.on_click = lambda e: page.run_task(toggle_pause, e)
    finish_btn.on_click = lambda e: page.run_task(finish_recording, e)

    _show_idle()

    # ── Нэвтрэх ──────────────────────────────────────────────────────────────
    APP_PASSWORD    = "2026"
    login_container = ft.Container(visible=True,  expand=True)
    main_container  = ft.Container(visible=False, expand=True)
    pw_input = ft.TextField(label="Нууц үг", password=True, can_reveal_password=True, width=300, border_radius=8)

    async def check_login(e):
        if pw_input.value == APP_PASSWORD:
            login_container.visible = False
            main_container.visible  = True
            page.update()
            await load_devices()
            load_history()
        else: show_err("Нууц үг буруу байна!")

    pw_input.on_submit = lambda e: page.run_task(check_login, e)

    def logout(e):
        if state["recording"]:
            show_err("⚠️  Бичлэг дуусгаад гарна уу!")
            return
        main_container.visible  = False
        login_container.visible = True
        pw_input.value          = ""
        timer_text.value        = "00:00"
        timer_text.color        = ft.Colors.GREY_700
        page.update()

    # ── Дэлгэц угсралт ───────────────────────────────────────────────────────
    login_icon = ft.Image(src=IMG_SRC, width=110, height=110) if IMG_SRC else ft.Icon(ft.Icons.MIC_EXTERNAL_ON, size=90, color=ft.Colors.BLUE_700)
    login_container.content = ft.Column([
        login_icon, ft.Text("Ц.Энхбатын ухаалаг", size=22, weight=ft.FontWeight.BOLD),
        ft.Text("дуу хураагуур 🎙️", size=22, weight=ft.FontWeight.BOLD),
        ft.Container(height=15), pw_input, ft.Container(height=10),
        ft.Button(content=ft.Text("Нэвтрэх", color="white"), bgcolor=ft.Colors.BLUE_700, on_click=lambda e: page.run_task(check_login, e), width=300, height=50),
    ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER)

    header = ft.Container(
        content=ft.Row([
            ft.Row([ft.Image(src=IMG_SRC, width=34, height=34) if IMG_SRC else ft.Icon(ft.Icons.MIC, color="white"),
                    ft.Column([ft.Text("Ц.Энхбатын ухаалаг дуу хураагуур", size=14, weight="bold", color="white"),
                               ft.Text("Хувийн хэрэгцээнд зориулав", size=10, color=ft.Colors.GREY_300)])]),
            ft.Row([
                # ЗАСВАР 2: get_directory_path-ийн оронд шууд манай choose_folder функцийг холбов (гацахгүй)
                ft.IconButton(icon=ft.Icons.CREATE_NEW_FOLDER, icon_color=ft.Colors.GREEN_400, tooltip="Хадгалах хавтас сонгох", on_click=choose_folder),
                ft.IconButton(icon=ft.Icons.FOLDER_OPEN, icon_color=ft.Colors.YELLOW_300, tooltip="Хавтас нээх", on_click=lambda e: open_file(state["output_dir"])),
                ft.IconButton(icon=ft.Icons.REFRESH, icon_color=ft.Colors.LIGHT_BLUE_200, tooltip="Шинэчлэх", on_click=lambda e: page.run_task(refresh_all, e)),
                ft.IconButton(icon=ft.Icons.LOGOUT, icon_color=ft.Colors.RED_300, tooltip="Гарах", on_click=logout),
            ], spacing=5)
        ], alignment="spaceBetween"), bgcolor="#1e3a8a", padding=ft.Padding(12, 6, 8, 8), border_radius=8,
    )

    main_container.content = ft.Column([
        header, ft.Container(height=10),
        ft.Card(content=ft.Container(content=ft.Column([mic_dropdown, ft.Row([format_dropdown])], spacing=10), padding=14)),
        ft.Container(height=15),
        ft.Row([ft.Container(content=ft.Column([timer_text, ft.Text("Бичлэгийн хугацаа", size=11, color=ft.Colors.GREY_500)], horizontal_alignment=ft.CrossAxisAlignment.CENTER), bgcolor="white", border_radius=14, padding=ft.Padding(40, 40, 15, 15), shadow=ft.BoxShadow(blur_radius=8, color=ft.Colors.with_opacity(0.08, "black")))], alignment=ft.MainAxisAlignment.CENTER),
        ft.Container(height=15), btn_row, ft.Container(height=6), ft.Row([status_text], alignment=ft.MainAxisAlignment.CENTER),
        ft.Divider(height=18, color=ft.Colors.GREY_300),
        ft.Row([ft.Icon(ft.Icons.HISTORY, color=ft.Colors.GREY_700, size=18), ft.Text("Хадгалагдсан бичлэгүүд", weight=ft.FontWeight.BOLD, size=14)]),
        ft.Container(content=history_list, expand=True, bgcolor="#EAECF0", border_radius=10),
        ft.Container(height=6), dir_text, ft.Container(height=6),
    ], expand=True, spacing=0)

    page.add(login_container, main_container)

if __name__ == "__main__":
    ft.app(main, assets_dir=ASSETS_DIR)