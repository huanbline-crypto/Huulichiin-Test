import json
import sys

file_path = r"C:\Users\DELL\PycharmProjects\pythonProject\batch5_prosecutor.json"

try:
    with open(file_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    print(f"Validation SUCCESS: JSON is valid.")
    print(f"Number of questions: {len(data)}")
    
    # Check structure
    for idx, item in enumerate(data):
        assert "question" in item, f"Missing question in item {idx}"
        assert "options" in item, f"Missing options in item {idx}"
        assert "correct" in item, f"Missing correct in item {idx}"
        assert "correct_text" in item, f"Missing correct_text in item {idx}"
        assert "explanation" in item, f"Missing explanation in item {idx}"
        
        correct_key = item["correct"]
        assert correct_key in item["options"], f"Correct key {correct_key} not in options for item {idx}"
        assert item["correct_text"] == item["options"][correct_key], f"correct_text mismatch for item {idx}"
        
    print("All structural constraints verified successfully!")
except Exception as e:
    print(f"Validation FAILED: {str(e)}")
    sys.exit(1)
