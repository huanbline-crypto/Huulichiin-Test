@echo off
echo ============================================
echo   BUILDING STANDALONE EXECUTABLE
echo ============================================
echo Installing required packages...
pip install pyinstaller opencv-python-headless numpy pillow python-docx customtkinter windnd
echo Running PyInstaller...
pyinstaller --noconfirm --onefile --windowed --name "Ц_Энхбатын_баримт_хөрвүүлэгч" --icon "assets\icons.ico" --add-data "assets;assets" --hidden-import=PIL --hidden-import=docx --hidden-import=windnd document_enhancer.py
echo Done.
