import os
import sys
import json
import time
import math
import struct
import threading
import ctypes
import pyaudio
import speech_recognition as sr
import pyperclip
import keyboard
import customtkinter as ctk
import pystray
from PIL import Image, ImageDraw, ImageTk

# Settings file path
SETTINGS_FILE = os.path.expanduser("~/.mongol_voice_typer_settings.json")

def get_resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

class VoiceTyperApp:
    def __init__(self):
        # Initialize CustomTkinter settings
        ctk.set_appearance_mode("Dark")
        ctk.set_default_color_theme("blue")
        
        self.root = ctk.CTk()
        self.root.title("Ц.Энхбатын Монгол Voice Typer")
        self.root.geometry("400x530")
        self.root.resizable(False, False)
        
        # Load user settings
        self.load_settings()
        
        # Set always on top based on settings
        self.root.attributes("-topmost", self.settings.get("always_on_top", True))
        
        # Try to apply Windows 11 Dark Mode Title Bar
        self.set_dark_title_bar()
        
        # State variables
        self.is_recording = False
        self.is_processing = False
        self.audio_frames = []
        self.pulse_radius = 50
        self.pulse_dir = 1
        self.spinner_angle = 0
        self.is_minimized_to_tray = False
        
        # Speech Recognition Init
        self.recognizer = sr.Recognizer()
        
        # Setup UI Components
        self.create_widgets()
        
        # Setup System Tray
        self.setup_tray()
        
        # Bind close event
        self.root.protocol('WM_DELETE_WINDOW', self.on_closing)
        
        # Register Hotkeys
        self.register_hotkeys()
        
        # Reset visualizer
        self.reset_visualizer()
        
        # Draw initial microphone state
        self.draw_idle_mic()

    def set_dark_title_bar(self):
        """Force Windows 10/11 Dark Title Bar"""
        try:
            self.root.update()
            hwnd = ctypes.windll.user32.GetParent(self.root.winfo_id())
            if hwnd == 0:
                hwnd = self.root.winfo_id()
            # DWMWA_USE_IMMERSIVE_DARK_MODE = 20
            value = ctypes.c_int(1)
            ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 20, ctypes.byref(value), ctypes.sizeof(value))
        except Exception as e:
            print("Windows dark title bar setting error:", e)

    def load_settings(self):
        default_settings = {
            "language": "mn-MN",
            "hotkey": "f8",
            "typing_method": "clipboard",
            "auto_space": True,
            "always_on_top": True
        }
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                    settings = json.load(f)
                    default_settings.update(settings)
            except Exception as e:
                print("Error loading settings:", e)
        self.settings = default_settings

    def save_settings(self):
        try:
            with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
                json.dump(self.settings, f, ensure_ascii=False, indent=4)
        except Exception as e:
            print("Error saving settings:", e)

    def create_tray_icon(self):
        icon_path = get_resource_path("assets/icon.png")
        if os.path.exists(icon_path):
            try:
                image = Image.open(icon_path)
                image = image.resize((64, 64), Image.Resampling.LANCZOS)
                return image
            except Exception as e:
                print("Error loading custom icon:", e)
                
        # Generate microphone icon dynamically using PIL (fallback)
        image = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
        dc = ImageDraw.Draw(image)
        white_color = (255, 255, 255, 255)
        
        # Draw mic shape
        dc.rounded_rectangle((24, 12, 40, 38), radius=8, fill=white_color)
        dc.arc((16, 20, 48, 42), start=0, end=180, fill=white_color, width=4)
        dc.line((32, 42, 32, 52), fill=white_color, width=4)
        dc.line((20, 52, 44, 52), fill=white_color, width=4)
        return image

    def setup_tray(self):
        image = self.create_tray_icon()
        # Create PhotoImage for app window icon
        self.app_icon = ImageTk.PhotoImage(image)
        self.root.wm_iconphoto(True, self.app_icon)
        
        # System tray menu
        menu = pystray.Menu(
            pystray.MenuItem('Нээх (Show)', self.show_window, default=True),
            pystray.MenuItem('Сонсох/Зогсоох', self.toggle_recording_from_tray),
            pystray.MenuItem('Гарах (Exit)', self.quit_app)
        )
        self.tray_icon = pystray.Icon("VoiceTyper", image, "Voice Typer", menu)
        threading.Thread(target=self.tray_icon.run, daemon=True).start()

    def register_hotkeys(self):
        try:
            keyboard.remove_all_hotkeys()
        except Exception:
            pass
        
        hotkey = self.settings.get("hotkey", "f8")
        try:
            keyboard.add_hotkey(hotkey, self.toggle_recording_from_hotkey, suppress=False)
            self.hotkey_btn.configure(text=hotkey.upper())
        except Exception as e:
            print("Hotkey registration failed, fallback to F8:", e)
            keyboard.add_hotkey("f8", self.toggle_recording_from_hotkey, suppress=False)
            self.hotkey_btn.configure(text="F8")

    def create_widgets(self):
        # Configure app colors
        self.bg_color = "#111116" # Deep space dark
        self.card_color = "#181824" # Sleek Dark Indigo
        self.accent_color = "#7B2CBF" # Electric purple
        self.hover_color = "#9D4EDD" # Bright Violet
        self.success_color = "#00F5D4" # Neon Teal
        self.danger_color = "#FF007F" # Neon Pink
        self.text_color = "#F7F4F9"
        self.gray_text = "#8C8A97"

        self.root.configure(fg_color=self.bg_color)

        # 1. Title Bar Area
        title_frame = ctk.CTkFrame(self.root, fg_color="transparent")
        title_frame.pack(fill="x", padx=20, pady=(15, 5))
        
        title_lbl = ctk.CTkLabel(title_frame, text="ҮГИЙН ҮЙЛЧЛЭГЧ", font=ctk.CTkFont(family="Outfit", size=18, weight="bold"), text_color=self.accent_color)
        title_lbl.pack(anchor="w")
        
        self.status_lbl = ctk.CTkLabel(title_frame, text="Хүлээж байна. Эхлүүлэхийн тулд F8 дарна уу.", font=ctk.CTkFont(family="Inter", size=12), text_color=self.gray_text)
        self.status_lbl.pack(anchor="w", pady=(2, 0))

        # 2. Main Circle Button Area
        self.canvas_frame = ctk.CTkFrame(self.root, fg_color="transparent")
        self.canvas_frame.pack(pady=10)

        self.canvas = ctk.CTkCanvas(self.canvas_frame, width=160, height=160, bg=self.bg_color, highlightthickness=0)
        self.canvas.pack()
        self.canvas.bind("<Button-1>", lambda e: self.toggle_recording())

        # 3. Audio Visualizer Area
        self.visualizer_canvas = ctk.CTkCanvas(self.root, width=220, height=40, bg=self.bg_color, highlightthickness=0)
        self.visualizer_canvas.pack(pady=(0, 10))
        
        # 4. Settings Card (Grouped Panel)
        settings_frame = ctk.CTkFrame(self.root, fg_color=self.card_color, corner_radius=15)
        settings_frame.pack(fill="x", padx=20, pady=5)
        
        # Language Selector
        lang_lbl = ctk.CTkLabel(settings_frame, text="Яриа таних хэл:", font=ctk.CTkFont(family="Inter", size=12, weight="bold"), text_color=self.text_color)
        lang_lbl.grid(row=0, column=0, padx=15, pady=(15, 8), sticky="w")
        
        lang_options = {"Монгол": "mn-MN", "English": "en-US", "Русский": "ru-RU"}
        self.lang_var = ctk.StringVar(value=[k for k, v in lang_options.items() if v == self.settings["language"]][0])
        
        lang_menu = ctk.CTkOptionMenu(
            settings_frame, 
            values=list(lang_options.keys()), 
            variable=self.lang_var, 
            command=lambda v: self.change_setting("language", lang_options[v]),
            fg_color=self.bg_color,
            button_color=self.accent_color,
            button_hover_color=self.hover_color,
            text_color=self.text_color,
            dropdown_fg_color=self.card_color,
            dropdown_text_color=self.text_color
        )
        lang_menu.grid(row=0, column=1, padx=15, pady=(15, 8), sticky="e")
        
        # Hotkey Button
        hotkey_lbl = ctk.CTkLabel(settings_frame, text="Шивэх товчлуур (Hotkey):", font=ctk.CTkFont(family="Inter", size=12, weight="bold"), text_color=self.text_color)
        hotkey_lbl.grid(row=1, column=0, padx=15, pady=8, sticky="w")
        
        self.hotkey_btn = ctk.CTkButton(
            settings_frame, 
            text=self.settings["hotkey"].upper(), 
            command=self.start_hotkey_rebinding,
            fg_color=self.bg_color,
            hover_color=self.hover_color,
            text_color=self.accent_color,
            width=100
        )
        self.hotkey_btn.grid(row=1, column=1, padx=15, pady=8, sticky="e")

        # Typing Method Selector
        method_lbl = ctk.CTkLabel(settings_frame, text="Шивэх загвар (Method):", font=ctk.CTkFont(family="Inter", size=12, weight="bold"), text_color=self.text_color)
        method_lbl.grid(row=2, column=0, padx=15, pady=8, sticky="w")
        
        method_options = {"Paste (Хурдан)": "clipboard", "Type (Шивэх)": "direct"}
        self.method_var = ctk.StringVar(value=[k for k, v in method_options.items() if v == self.settings["typing_method"]][0])
        
        method_menu = ctk.CTkOptionMenu(
            settings_frame,
            values=list(method_options.keys()),
            variable=self.method_var,
            command=lambda v: self.change_setting("typing_method", method_options[v]),
            fg_color=self.bg_color,
            button_color=self.accent_color,
            button_hover_color=self.hover_color,
            text_color=self.text_color,
            dropdown_fg_color=self.card_color,
            dropdown_text_color=self.text_color
        )
        method_menu.grid(row=2, column=1, padx=15, pady=8, sticky="e")

        # Switches Container (row 3, columns span)
        switches_frame = ctk.CTkFrame(settings_frame, fg_color="transparent")
        switches_frame.grid(row=3, column=0, columnspan=2, sticky="ew", padx=15, pady=(5, 15))
        
        # Always on top
        self.top_switch = ctk.CTkSwitch(
            switches_frame, 
            text="Үргэлж дээр байх", 
            command=self.toggle_always_on_top,
            progress_color=self.accent_color,
            text_color=self.text_color,
            font=ctk.CTkFont(family="Inter", size=12)
        )
        if self.settings["always_on_top"]:
            self.top_switch.select()
        self.top_switch.pack(side="left", padx=(0, 10))
        
        # Auto space
        self.space_switch = ctk.CTkSwitch(
            switches_frame, 
            text="Зай авах (Auto-space)", 
            command=self.toggle_auto_space,
            progress_color=self.accent_color,
            text_color=self.text_color,
            font=ctk.CTkFont(family="Inter", size=12)
        )
        if self.settings["auto_space"]:
            self.space_switch.select()
        self.space_switch.pack(side="right", padx=(10, 0))

        # 5. Help Info/Tip Footer
        footer_frame = ctk.CTkFrame(self.root, fg_color="transparent")
        footer_frame.pack(fill="x", padx=20, pady=(10, 10))
        
        tip_lbl = ctk.CTkLabel(
            footer_frame, 
            text="Зөвлөмж: Апп нь систем дээр хуулж (Paste) бичдэг тул\nМонгол фонттой талбарт курсороо байрлуулж ярина уу.", 
            font=ctk.CTkFont(family="Inter", size=10, slant="italic"), 
            text_color=self.gray_text,
            justify="center"
        )
        tip_lbl.pack(fill="x")

    def draw_idle_mic(self):
        self.canvas.delete("all")
        # Base circle
        self.canvas.create_oval(30, 30, 130, 130, fill=self.card_color, outline="", tags="inner")
        self.draw_mic_vector(self.text_color)

    def draw_mic_vector(self, color):
        # Draw micro icon vector manually in canvas
        # Body
        self.canvas.create_rectangle(72, 55, 88, 90, fill=color, outline=color, width=2, tags="icon")
        self.canvas.create_oval(72, 47, 88, 63, fill=color, outline=color, tags="icon")
        self.canvas.create_oval(72, 82, 88, 98, fill=color, outline=color, tags="icon")
        
        # U-shaped stand
        self.canvas.create_arc(62, 57, 98, 97, start=180, extent=180, style="arc", outline=color, width=4, tags="icon")
        
        # Connector
        self.canvas.create_line(80, 97, 80, 112, fill=color, width=4, tags="icon")
        self.canvas.create_line(68, 112, 92, 112, fill=color, width=4, tags="icon")

    def animate_pulse(self):
        if not self.is_recording:
            return
            
        self.canvas.delete("pulse")
        
        # Expand/contract radius
        self.pulse_radius += self.pulse_dir * 1.5
        if self.pulse_radius > 68 or self.pulse_radius < 45:
            self.pulse_dir *= -1
            
        # Draw pulse glow (neon danger/rose color)
        self.canvas.create_oval(
            80 - self.pulse_radius, 80 - self.pulse_radius,
            80 + self.pulse_radius, 80 + self.pulse_radius,
            fill=self.danger_color, outline="", tags="pulse"
        )
        
        self.canvas.tag_raise("inner")
        self.canvas.tag_raise("icon")
        
        self.root.after(40, self.animate_pulse)

    def animate_spinner(self):
        if not self.is_processing:
            return
            
        self.canvas.delete("spinner")
        self.spinner_angle = (self.spinner_angle + 10) % 360
        
        # Draw spinning neon teal circular line
        self.canvas.create_arc(
            22, 22, 138, 138,
            start=self.spinner_angle, extent=70,
            style="arc", outline=self.success_color, width=4, tags="spinner"
        )
        
        self.root.after(30, self.animate_spinner)

    def reset_visualizer(self):
        self.visualizer_canvas.delete("all")
        self.bars = []
        # Draw 7 idle bars
        for i in range(7):
            x0 = i * 25 + 35
            y0 = 18
            x1 = x0 + 12
            y1 = 22
            bar = self.visualizer_canvas.create_rectangle(x0, y0, x1, y1, fill=self.card_color, outline="", width=0)
            self.bars.append(bar)

    def update_visualizer(self, rms):
        if not self.is_recording:
            return
            
        # Standardize volume to 0.0 - 1.0 range
        max_rms = 4000.0
        normalized = min(1.0, max(0.02, rms / max_rms))
        
        for i, bar in enumerate(self.bars):
            # Dynamic height variation
            factor = 0.3 + 0.7 * math.sin((i + 1) * time.time() * 8)
            height = max(4, int(normalized * 34 * factor))
            
            x0 = i * 25 + 35
            y0 = 20 - height // 2
            x1 = x0 + 12
            y1 = 20 + height // 2
            
            # Change color to pinkish red based on volume
            color = self.danger_color if normalized > 0.4 else self.accent_color
            self.visualizer_canvas.coords(bar, x0, y0, x1, y1)
            self.visualizer_canvas.itemconfig(bar, fill=color)

    def change_setting(self, key, value):
        self.settings[key] = value
        self.save_settings()

    def toggle_always_on_top(self):
        is_on = self.top_switch.get()
        self.root.attributes("-topmost", is_on)
        self.change_setting("always_on_top", is_on)

    def toggle_auto_space(self):
        is_on = self.space_switch.get()
        self.change_setting("auto_space", is_on)

    def start_hotkey_rebinding(self):
        self.hotkey_btn.configure(text="Дарах...", text_color=self.danger_color)
        try:
            keyboard.remove_all_hotkeys()
        except Exception:
            pass
            
        def on_key(event):
            if event.name in ['ctrl', 'shift', 'alt', 'windows', 'left ctrl', 'right ctrl', 'left shift', 'right shift', 'left alt', 'right alt']:
                return
                
            hotkey = event.name
            mods = []
            if keyboard.is_pressed('ctrl'): mods.append('ctrl')
            if keyboard.is_pressed('alt'): mods.append('alt')
            if keyboard.is_pressed('shift'): mods.append('shift')
            
            if mods:
                hotkey = "+".join(mods) + "+" + hotkey
                
            self.settings["hotkey"] = hotkey
            self.save_settings()
            
            keyboard.unhook(hook_id)
            
            # Register new hotkeys on main UI thread
            self.root.after(0, self.register_hotkeys)
            
        hook_id = keyboard.on_press(on_key)

    def toggle_recording_from_hotkey(self):
        """Thread-safe toggle from hotkey listener"""
        self.root.after(0, self.toggle_recording)

    def toggle_recording_from_tray(self):
        """Thread-safe toggle from tray menu"""
        self.root.after(0, self.toggle_recording)

    def toggle_recording(self):
        if self.is_processing:
            return # Block interaction during processing
            
        if not self.is_recording:
            self.start_recording()
        else:
            self.stop_recording()

    def start_recording(self):
        self.is_recording = True
        self.status_lbl.configure(text="Сонсож байна... [Яриад зогсоорой]", text_color=self.danger_color)
        
        # UI recording state
        self.canvas.delete("all")
        self.canvas.create_oval(30, 30, 130, 130, fill=self.card_color, outline="", tags="inner")
        self.draw_mic_vector(self.danger_color)
        
        # Start animations
        self.pulse_radius = 50
        self.animate_pulse()
        
        # Start recording thread
        threading.Thread(target=self.pyaudio_recording_loop, daemon=True).start()

    def stop_recording(self):
        self.is_recording = False
        # Recording thread will terminate and start processing

    def pyaudio_recording_loop(self):
        try:
            p = pyaudio.PyAudio()
            stream = p.open(
                format=pyaudio.paInt16,
                channels=1,
                rate=16000,
                input=True,
                frames_per_buffer=1024
            )
        except Exception as e:
            self.is_recording = False
            self.update_status_safe("error_mic", str(e))
            return

        self.audio_frames = []
        
        while self.is_recording:
            try:
                data = stream.read(1024, exception_on_overflow=False)
                self.audio_frames.append(data)
                
                # Audio level metering
                count = len(data) // 2
                if count > 0:
                    shorts = struct.unpack(f"{count}h", data)
                    sum_squares = sum(s * s for s in shorts)
                    rms = math.sqrt(sum_squares / count)
                    self.root.after(0, lambda r=rms: self.update_visualizer(r))
            except Exception as e:
                print("Audio capture error:", e)
                break
                
        try:
            stream.stop_stream()
            stream.close()
            p.terminate()
        except Exception:
            pass

        # If we didn't capture enough audio, return to idle
        if len(self.audio_frames) < 5:
            self.update_status_safe("idle")
            return
            
        # Prepare audio data for speech recognition
        audio_bytes = b"".join(self.audio_frames)
        audio_data = sr.AudioData(audio_bytes, 16000, 2)
        
        # Trigger processing mode
        self.is_processing = True
        self.update_status_safe("processing")
        
        # Start recognition thread
        threading.Thread(target=self.recognize_audio, args=(audio_data,), daemon=True).start()

    def update_status_safe(self, state, detail=None):
        self.root.after(0, lambda: self.update_status_ui(state, detail))

    def update_status_ui(self, state, detail=None):
        if state == "idle":
            self.is_processing = False
            self.status_lbl.configure(text=f"Хүлээж байна. Эхлүүлэх: {self.settings['hotkey'].upper()}", text_color=self.gray_text)
            self.draw_idle_mic()
            self.reset_visualizer()
            
        elif state == "processing":
            self.status_lbl.configure(text="Боловсруулж байна (Google API)...", text_color=self.success_color)
            self.canvas.delete("all")
            # Drawing blue-violet processing state
            self.canvas.create_oval(30, 30, 130, 130, fill=self.card_color, outline="", tags="inner")
            self.draw_mic_vector(self.success_color)
            self.animate_spinner()
            self.reset_visualizer()
            
        elif state == "success":
            self.is_processing = False
            truncated_text = detail if len(detail) < 25 else detail[:22] + "..."
            self.status_lbl.configure(text=f"Амжилттай: \"{truncated_text}\"", text_color=self.success_color)
            # Revert to idle after 3 seconds
            self.root.after(3000, lambda: self.update_status_ui("idle") if not self.is_recording and not self.is_processing else None)
            
        elif state == "error_unknown":
            self.is_processing = False
            self.status_lbl.configure(text="Алдаа: Яриаг таньсангүй.", text_color=self.danger_color)
            self.root.after(3000, lambda: self.update_status_ui("idle") if not self.is_recording and not self.is_processing else None)
            
        elif state == "error_request":
            self.is_processing = False
            self.status_lbl.configure(text="Алдаа: Интернэт сүлжээгээ шалгана уу.", text_color=self.danger_color)
            self.root.after(4000, lambda: self.update_status_ui("idle") if not self.is_recording and not self.is_processing else None)
            
        elif state == "error_mic":
            self.is_processing = False
            self.status_lbl.configure(text="Микрофон холболтын алдаа!", text_color=self.danger_color)
            self.root.after(4000, lambda: self.update_status_ui("idle") if not self.is_recording and not self.is_processing else None)

    def recognize_audio(self, audio_data):
        selected_lang = self.settings.get("language", "mn-MN")
        try:
            # Query Google Web Speech API
            text = self.recognizer.recognize_google(audio_data, language=selected_lang)
            if text:
                self.paste_text(text)
                self.update_status_safe("success", text)
            else:
                self.update_status_safe("error_unknown")
        except sr.UnknownValueError:
            self.update_status_safe("error_unknown")
        except sr.RequestError:
            self.update_status_safe("error_request")
        except Exception as e:
            print("Recognition thread crash:", e)
            self.update_status_safe("error_unknown")

    def paste_text(self, text):
        if not text:
            return
            
        # Add auto-spacing at the end of word/sentence
        if self.settings.get("auto_space", True):
            text = text + " "
            
        if self.settings.get("typing_method", "clipboard") == "clipboard":
            try:
                # Store original clipboard
                orig_clipboard = pyperclip.paste()
            except Exception:
                orig_clipboard = ""
                
            # Copy text to clipboard
            pyperclip.copy(text)
            
            # Simulate Ctrl+V to paste
            time.sleep(0.05) # Tiny wait for OS window focus
            keyboard.press_and_release('ctrl+v')
            time.sleep(0.12) # Wait for OS to finish paste transaction
            
            # Restore clipboard
            if orig_clipboard:
                pyperclip.copy(orig_clipboard)
        else:
            # Slower character injection fallback
            # Note: might fail unicode depending on destination window keyboard driver
            keyboard.write(text, delay=0.01)

    def show_window(self):
        self.root.after(0, self.root.deiconify)
        self.root.after(0, self.root.focus_force)
        self.is_minimized_to_tray = False

    def hide_window(self):
        self.root.withdraw()
        self.is_minimized_to_tray = True

    def on_closing(self):
        # Standard utility behaviour: minimize to system tray instead of destroying
        self.hide_window()

    def quit_app(self):
        self.is_recording = False
        self.is_processing = False
        try:
            self.tray_icon.stop()
        except Exception:
            pass
        self.root.after(0, self.root.destroy)

if __name__ == "__main__":
    app = VoiceTyperApp()
    app.root.mainloop()
