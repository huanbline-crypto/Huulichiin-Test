import flet as ft
import datetime
import requests
import subprocess
import sys
import re

URL_REGEX = re.compile(r'(https?://[^\s]+)')

def parse_text_to_spans(text_str):
    spans = []
    last_idx = 0
    for match in URL_REGEX.finditer(text_str):
        start, end = match.span()
        if start > last_idx:
            spans.append(ft.TextSpan(text_str[last_idx:start]))
        url = match.group(0)
        spans.append(ft.TextSpan(
            url,
            url=url,
            style=ft.TextStyle(
                color=ft.Colors.BLUE_600,
                decoration=ft.TextDecoration.UNDERLINE,
            )
        ))
        last_idx = end
    if last_idx < len(text_str):
        spans.append(ft.TextSpan(text_str[last_idx:]))
    return spans

BASE_URL = "https://my-calendar-3980f-default-rtdb.firebaseio.com"


def main(page: ft.Page):
    page.title = "Үүлэн Тэмдэглэлийн Апп ☁️"
    page.scroll = "auto"
    page.window_width = 400
    page.window_height = 700
    page.theme_mode = ft.ThemeMode.LIGHT
    page.padding = 20

    # Clipboard service initialization
    clipboard = ft.Clipboard()
    # page.overlay.append(clipboard)

    def show_message(msg, bg_color=ft.Colors.GREEN_600):
        snack = ft.SnackBar(ft.Text(msg), bgcolor=bg_color, duration=3500)
        page.overlay.append(snack)
        snack.open = True
        page.update()

    # ================= 1. НЭВТРЭХ ХЭСЭГ (LOGIN) =================
    MY_PASSWORD = "43215678-"

    password_input = ft.TextField(label="Нууц үг", prefix_icon=ft.Icons.LOCK, password=True, can_reveal_password=True,
                                  width=300)

    def check_login(e):
        if password_input.value == MY_PASSWORD:
            show_main_notes()
        else:
            show_message("Нууц үг буруу байна!", ft.Colors.RED_500)

    # ЗАСВАР 1: Товчны өнгийг шинэ стандартын дагуу (ft.ButtonStyle) оруулсан
    login_btn = ft.ElevatedButton(
        "Нэвтрэх",
        on_click=check_login,
        width=300,
        style=ft.ButtonStyle(color=ft.Colors.WHITE, bgcolor=ft.Colors.BLUE_600)
    )

    login_view = ft.Column(
        [
            ft.Icon(ft.Icons.LOCK_OUTLINE, size=80, color=ft.Colors.BLUE_600),
            ft.Text("Хувийн тэмдэглэл", size=24, weight=ft.FontWeight.BOLD),
            ft.Text("Зөвхөн Ц.Энхбат нэвтрэх эрхтэй", color=ft.Colors.GREY_500, size=12),
            ft.Container(height=20),
            password_input,
            ft.Container(height=10),
            login_btn
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
    )

    def show_login_screen():
        page.clean()
        password_input.value = ""
        page.vertical_alignment = ft.MainAxisAlignment.CENTER
        page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
        page.add(login_view)
        page.update()

    # ================= 2. ҮНДСЭН ТЭМДЭГЛЭЛИЙН ХЭСЭГ =================
    selected_date = ft.Text(value="Огноо сонгоогүй байна", size=16, weight=ft.FontWeight.BOLD)
    notes_list = ft.Column(spacing=10)
    all_notes = {}

    search_input = ft.TextField(
        label="Тэмдэглэл дотроос хайх...",
        prefix_icon=ft.Icons.SEARCH,
        height=45,
        text_size=13,
        on_change=lambda e: render_notes()
    )

    def render_notes():
        notes_list.controls.clear()
        search_query = search_input.value.lower() if search_input.value else ""

        sorted_items = sorted(
            all_notes.items(),
            key=lambda x: (x[1].get('done', False), x[1].get('date', '9999-99-99'))
        )

        for note_id, note_data in sorted_items:
            if search_query in note_data['text'].lower() or search_query in note_data['date']:
                is_done = note_data.get('done', False)
                new_note = create_note_ui(note_id, note_data['date'], note_data['text'], is_done)
                notes_list.controls.append(new_note)
        page.update()

    def create_note_ui(note_id, date_str, text_str, is_done):
        text_element = ft.Text(
            spans=parse_text_to_spans(text_str),
            color=ft.Colors.GREY_500 if is_done else ft.Colors.BLACK87,
            italic=is_done,
            max_lines=3,
            overflow=ft.TextOverflow.ELLIPSIS,
            size=14,
            selectable=False
        )

        def toggle_expand(e):
            if text_element.max_lines == 3:
                text_element.max_lines = None
                text_element.overflow = None
            else:
                text_element.max_lines = 3
                text_element.overflow = ft.TextOverflow.ELLIPSIS
            page.update()

        text_container = ft.Container(
            content=text_element,
            on_click=toggle_expand,
            tooltip="Товшиж дэлгэх / хумих"
        )

        def done_clicked(e):
            new_done_state = checkbox.value
            try:
                response = requests.patch(f"{BASE_URL}/notes/{note_id}.json", json={"done": new_done_state})
                if response.status_code == 200:
                    if note_id in all_notes:
                        all_notes[note_id]['done'] = new_done_state
                    render_notes()
                else:
                    checkbox.value = not new_done_state
                    page.update()
                    show_message(f"Firebase алдаа: {response.status_code}", ft.Colors.RED_500)
            except Exception as ex:
                checkbox.value = not new_done_state
                page.update()
                show_message(f"Холболтын алдаа: {ex}", ft.Colors.RED_500)

        def edit_clicked(e):
            edit_input = ft.TextField(value=text_str, multiline=True, min_lines=3, max_lines=5)

            def save_edit(e):
                new_text = edit_input.value
                if new_text.strip():
                    try:
                        response = requests.patch(f"{BASE_URL}/notes/{note_id}.json", json={"text": new_text})
                        if response.status_code == 200:
                            if note_id in all_notes:
                                all_notes[note_id]['text'] = new_text
                            edit_dialog.open = False
                            render_notes()
                            show_message("Амжилттай засагдлаа! ✏️", ft.Colors.GREEN_600)
                        else:
                            show_message(f"Засаж чадсангүй. Статус: {response.status_code}", ft.Colors.RED_500)
                    except Exception as ex:
                        show_message("Засахад алдаа гарлаа. Интернэтээ шалгана уу!", ft.Colors.RED_500)
                else:
                    show_message("Текст хоосон байна!", ft.Colors.ORANGE_500)

            def cancel_edit(e):
                edit_dialog.open = False
                page.update()

            edit_dialog = ft.AlertDialog(
                title=ft.Text("Тэмдэглэл засах", weight=ft.FontWeight.BOLD),
                content=edit_input,
                actions=[
                    ft.TextButton("Болих", on_click=cancel_edit),
                    ft.ElevatedButton("Хадгалах", on_click=save_edit,
                                      style=ft.ButtonStyle(color=ft.Colors.WHITE, bgcolor=ft.Colors.BLUE_500)),
                ],
                actions_alignment=ft.MainAxisAlignment.END,
            )
            page.overlay.append(edit_dialog)
            edit_dialog.open = True
            page.update()

        def delete_clicked(e):
            def close_dialog(e):
                confirm_dialog.open = False
                page.update()

            def confirm_delete(e):
                try:
                    response = requests.delete(f"{BASE_URL}/notes/{note_id}.json")
                    if response.status_code == 200:
                        if note_id in all_notes:
                            del all_notes[note_id]
                        confirm_dialog.open = False
                        render_notes()
                        show_message("Тэмдэглэлийг устгалаа!")
                    else:
                        show_message(f"Устгаж чадсангүй. Статус: {response.status_code}", ft.Colors.RED_500)
                except Exception as ex:
                    print("Устгахад алдаа гарлаа:", ex)

            confirm_dialog = ft.AlertDialog(
                title=ft.Text("Анхааруулга", weight=ft.FontWeight.BOLD),
                content=ft.Text("Та энэ тэмдэглэлийг бүрмөсөн устгахдаа итгэлтэй байна уу?"),
                actions=[
                    ft.TextButton("Үгүй", on_click=close_dialog),
                    ft.TextButton(
                        "Тийм",
                        on_click=confirm_delete,
                        icon=ft.Icons.DELETE_OUTLINE,
                        icon_color=ft.Colors.RED_400
                    ),
                ],
                actions_alignment=ft.MainAxisAlignment.END,
            )
            page.overlay.append(confirm_dialog)
            confirm_dialog.open = True
            page.update()

        def copy_clicked(e):
            text_to_copy = str(text_str).strip()
            try:
                page.run_task(clipboard.set, text_to_copy)
                show_message("Тэмдэглэлийг амжилттай хууллаа! ✅")
            except Exception as ex:
                show_message(f"Хуулж чадсангүй: {ex}", ft.Colors.RED_500)

        checkbox = ft.Checkbox(value=is_done, on_change=done_clicked, fill_color=ft.Colors.GREEN_500)

        edit_btn = ft.IconButton(icon=ft.Icons.EDIT, icon_color=ft.Colors.ORANGE_500, on_click=edit_clicked,
                                 icon_size=20)
        copy_btn = ft.IconButton(icon=ft.Icons.COPY, icon_color=ft.Colors.BLUE_500, on_click=copy_clicked, icon_size=20)
        delete_btn = ft.IconButton(icon=ft.Icons.DELETE_OUTLINE, icon_color=ft.Colors.RED_400, on_click=delete_clicked,
                                   icon_size=20)

        header_row = ft.Row(
            [
                checkbox,
                ft.Text(date_str, size=12, color=ft.Colors.GREY_500),
                ft.Container(expand=True),
                edit_btn,
                copy_btn,
                delete_btn
            ],
            spacing=0
        )

        # ЗАСВАР 3: Гар утсыг гацаагаад байсан padding коммандыг хамгийн зөв бөгөөд аюулгүй хэлбэр рүү шилжүүлэв
        note_card = ft.Card(
            content=ft.Container(
                content=ft.Column(
                    [
                        header_row,
                        ft.Container(
                            content=text_container,
                            padding=ft.padding.Padding(left=45, top=0, right=10, bottom=15)  # Яг энд алдаа гарч байсан
                        )
                    ],
                    spacing=0
                ),
                padding=5,
                bgcolor=ft.Colors.WHITE if not is_done else ft.Colors.GREY_100,
                border_radius=10
            ),
            elevation=2
        )

        return note_card

    def load_notes_from_cloud():
        try:
            response = requests.get(f"{BASE_URL}/notes.json")
            if response.status_code == 200:
                data = response.json()
                if data is not None:
                    if isinstance(data, dict) and "error" in data:
                        show_message(f"Хандах эрхийн алдаа: {data['error']}", ft.Colors.RED_500)
                        return
                    all_notes.clear()
                    for note_id, note_data in data.items():
                        if note_data is None or 'date' not in note_data or 'text' not in note_data:
                            continue
                        all_notes[note_id] = note_data
                    render_notes()
            elif response.status_code == 401:
                show_message("Алдаа 401: Firebase-ийн дүрэм (Rules) хугацаа дууссан байна!", ft.Colors.RED_500)
            else:
                show_message(f"Firebase холболтын алдаа. Статус: {response.status_code}", ft.Colors.RED_500)
        except Exception as e:
            print("Алдаа гарлаа:", e)

    def on_date_change(e):
        dt = e.control.value
        if dt.hour > 0:
            dt += datetime.timedelta(hours=(24 - dt.hour))
        selected_date.value = f"Сонгосон огноо: {dt.strftime('%Y-%m-%d')}"
        page.update()

    date_picker = ft.DatePicker(
        first_date=datetime.datetime(2020, 1, 1),
        last_date=datetime.datetime(2030, 12, 31),
        on_change=on_date_change
    )
    page.overlay.append(date_picker)

    def open_calendar(e):
        date_picker.open = True
        page.update()

    note_input = ft.TextField(label="Тэмдэглэлээ бичнэ үү...", multiline=True)

    def save_note(e):
        if note_input.value and "сонгоогүй" not in selected_date.value:
            date_str = selected_date.value.split(': ')[1]
            text_str = note_input.value

            cloud_data = {
                "date": date_str,
                "text": text_str,
                "done": False
            }

            try:
                response = requests.post(f"{BASE_URL}/notes.json", json=cloud_data)
                if response.status_code == 200:
                    res_data = response.json()
                    if isinstance(res_data, dict) and "name" in res_data:
                        note_id = res_data["name"]
                        all_notes[note_id] = cloud_data
                        render_notes()
                        note_input.value = ""
                        page.update()
                        show_message("Амжилттай хадгаллаа! ☁️")
                    else:
                        error_msg = res_data.get("error", "Тодорхойгүй алдаа") if isinstance(res_data, dict) else "Алдаатай хариу"
                        show_message(f"Хадгалж чадсангүй: {error_msg}", ft.Colors.RED_500)
                elif response.status_code == 401:
                    show_message("Алдаа 401: Firebase-ийн дүрэм (Rules) хугацаа дууссан байна!", ft.Colors.RED_500)
                else:
                    show_message(f"Хадгалахад алдаа гарлаа. Статус: {response.status_code}", ft.Colors.RED_500)
            except Exception as ex:
                show_message(f"Холболтын алдаа: {ex}", ft.Colors.RED_500)
        else:
            show_message("Огноо сонгож, тэмдэглэлээ бичнэ үү!", ft.Colors.RED_500)

    def show_main_notes():
        page.clean()
        page.vertical_alignment = ft.MainAxisAlignment.START
        page.horizontal_alignment = ft.CrossAxisAlignment.START

        header = ft.Row([
            ft.Text("Ц.Энхбатын Үүлэн Календарь ☁️📅", size=16, weight=ft.FontWeight.BOLD),
            ft.IconButton(icon=ft.Icons.LOGOUT, icon_color=ft.Colors.RED_500, tooltip="Гарах",
                          on_click=lambda e: show_login_screen())
        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)

        # ЗАСВАР 4: Хадгалах товчны өнгийг шинэ стандартын дагуу оруулсан
        page.add(
            header,
            ft.ElevatedButton(
                "Огноо сонгох",
                icon=ft.Icons.CALENDAR_TODAY,
                on_click=open_calendar
            ),
            selected_date,
            ft.Divider(),
            note_input,
            ft.ElevatedButton("Үүлэнд хадгалах",
                              style=ft.ButtonStyle(color=ft.Colors.WHITE, bgcolor=ft.Colors.BLUE_500),
                              on_click=save_note),
            ft.Divider(),
            search_input,
            notes_list
        )

        load_notes_from_cloud()

    show_login_screen()


ft.run(main)