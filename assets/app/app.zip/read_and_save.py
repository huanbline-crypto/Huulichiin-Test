import os
import docx

LAWS_DIR = r"D:\AJIL\ALFA OMEGA\МИНИЙХ\ХУУЛЬЧИЙН СОНГОН ШАЛГАРУУЛАЛТ 2025\хуулиуд"
law_name = "МОНГОЛ УЛСЫН ШҮҮХИЙН ТУХАЙ _Шинэчилсэн найруулга_.docx"
file_path = os.path.join(LAWS_DIR, law_name)

doc = docx.Document(file_path)
full_text = []
for para in doc.paragraphs:
    full_text.append(para.text)
for table in doc.tables:
    for row in table.rows:
        row_text = [cell.text.strip() for cell in row.cells]
        full_text.append(" | ".join(row_text))

output_path = r"C:\Users\DELL\PycharmProjects\pythonProject\court_law_full_text.txt"
with open(output_path, "w", encoding="utf-8") as f:
    f.write("\n".join(full_text))

print("Saved full text to:", output_path)
