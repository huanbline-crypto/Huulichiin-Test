import zipfile
import xml.etree.ElementTree as ET
import os

def docx_to_text(docx_path):
    # Try importing docx first
    try:
        import docx
        doc = docx.Document(docx_path)
        return "\n".join([p.text for p in doc.paragraphs])
    except ImportError:
        # Fallback to zipfile and xml parsing
        try:
            with zipfile.ZipFile(docx_path) as z:
                xml_content = z.read('word/document.xml')
                root = ET.fromstring(xml_content)
                namespaces = {
                    'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
                }
                paragraphs = []
                for p in root.findall('.//w:p', namespaces):
                    p_text = ""
                    for r in p.findall('.//w:r', namespaces):
                        t = r.find('w:t', namespaces)
                        if t is not None and t.text:
                            p_text += t.text
                    paragraphs.append(p_text)
                return "\n".join(paragraphs)
        except Exception as e:
            return f"Error: {str(e)}"

docx_path = r"D:\AJIL\ALFA OMEGA\МИНИЙХ\ХУУЛЬЧИЙН СОНГОН ШАЛГАРУУЛАЛТ 2025\хуулиуд\ХӨДӨЛМӨРИЙН АЮУЛГҮЙ БАЙДАЛ, ЭРҮҮЛ АХУЙН ТУХАЙ.docx"
text = docx_to_text(docx_path)

out_path = r"C:\Users\DELL\PycharmProjects\pythonProject\law_text.txt"
with open(out_path, "w", encoding="utf-8") as f:
    f.write(text)

print(f"Extracted {len(text)} characters to {out_path}")
