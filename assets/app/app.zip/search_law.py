import re

txt_path = r"C:\Users\DELL\PycharmProjects\pythonProject\decision_enforce.txt"
out_path = r"C:\Users\DELL\PycharmProjects\pythonProject\search_results.txt"

queries = [
    "тогтолцоо",
    "эрхлэх асуудлын хүрээнд",
    "төрийн тусгай алба",
    "гүйцэтгэх баримт бичиг",
    "хувийн хэрэг нээж",
    "сайн дураар биелүүлэх",
    "битүүмжлэх",
    "хураах",
    "үнэлгээ",
    "дуудлага худалдаа",
    "хорих ангийн дарга",
    "сахилгын байр",
    "хорихоос өөр",
    "торгох ял",
    "нийтэд тустай ажил",
    "зорчих эрх",
    "урт хугацааны уулзалт",
    "түр уулзалт"
]

results = []

try:
    with open(txt_path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    
    results.append(f"Total lines in law: {len(lines)}")
    
    for query in queries:
        results.append(f"\n=== Matches for: {query} ===")
        match_count = 0
        for i, line in enumerate(lines):
            if query.lower() in line.lower():
                results.append(f"Line {i+1}: {line.strip()}")
                match_count += 1
                if match_count >= 15: # limit per query
                    results.append("... (too many matches, truncated)")
                    break
                    
    with open(out_path, "w", encoding="utf-8") as f_out:
        f_out.write("\n".join(results))
    print("Search completed. Results written to search_results.txt")
except Exception as e:
    print(f"Error: {e}")
