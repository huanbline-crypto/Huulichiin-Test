import os
import sys
import docx
import win32com.client as win32

LAWS_DIR = r"D:\AJIL\ALFA OMEGA\МИНИЙХ\ХУУЛЬЧИЙН СОНГОН ШАЛГАРУУЛАЛТ 2025\хуулиуд"
LAW_NAME = "ЗӨРЧИЛ ШАЛГАН ШИЙДВЭРЛЭХ ТУХАЙ.doc"
OUTPUT_FILE = r"C:\Users\DELL\PycharmProjects\pythonProject\law_text.txt"

def read_docx(file_path):
    doc = docx.Document(file_path)
    full_text = []
    for para in doc.paragraphs:
        full_text.append(para.text)
    for table in doc.tables:
        for row in table.rows:
            row_text = [cell.text.strip() for cell in row.cells]
            full_text.append(" | ".join(row_text))
    return "\n".join(full_text)

def read_doc_via_word(file_path):
    try:
        word = win32.gencache.EnsureDispatch('Word.Application')
    except Exception:
        word = win32.Dispatch('Word.Application')
        
    word.Visible = False
    
    abs_path = os.path.abspath(file_path)
    temp_docx = abs_path + "x" # Append 'x' to make it .docx
    
    try:
        doc = word.Documents.Open(abs_path)
        doc.SaveAs2(temp_docx, FileFormat=16) # 16 is wdFormatXMLDocument (docx)
        doc.Close()
    finally:
        word.Quit()
    
    text = read_docx(temp_docx)
    
    if os.path.exists(temp_docx):
        os.remove(temp_docx)
        
    return text

def main():
    file_path = os.path.join(LAWS_DIR, LAW_NAME)
    if not os.path.exists(file_path):
        # Try finding case-insensitively
        files = os.listdir(LAWS_DIR)
        matched = [f for f in files if f.lower() == LAW_NAME.lower()]
        if matched:
            file_path = os.path.join(LAWS_DIR, matched[0])
        else:
            print(f"Error: File not found {file_path}")
            return
            
    print(f"Reading {file_path}...")
    if file_path.lower().endswith('.docx'):
        text = read_docx(file_path)
    elif file_path.lower().endswith('.doc'):
        text = read_doc_via_word(file_path)
    else:
        print("Unsupported file format")
        return
        
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
        f.write(text)
    print(f"Successfully wrote {len(text)} characters to {OUTPUT_FILE}")

if __name__ == "__main__":
    main()
