import flet as ft
import librouteros
import librouteros.exceptions
import threading
import logging
import time

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

SOCIAL_KEYWORDS = {
    "YouTube":  "youtube",
    "Facebook": "facebook",
    "Telegram": "telegram",
    "Viber":    "viber",
}
GLOBAL_RULE_COMMENT = "GLOBAL-SOCIAL-BLOCK"
WAN_INTERFACE = "ether1"


def set_app_disabled(api, keyword, disabled):
    try:
        path = api.path("ip", "firewall", "address-list")
        entries = [e for e in path if e.get("list") == "block-social"]
        count = 0
        for entry in entries:
            if entry.get("dynamic") in ("true", True):
                continue
            addr = entry.get("address", "").lower()
            comment = entry.get("comment", "").lower()
            if keyword.lower() not in addr and keyword.lower() not in comment:
                continue
            try:
                path.update(**{".id": entry[".id"], "disabled": "yes" if disabled else "no"})
                count += 1
            except Exception as ex:
                logger.error("Update aldaa (%s): %s", entry[".id"], ex)
        if count == 0:
            return False, keyword + " олдсонгүй"
        return True, str(count) + " шинэчлэгдлээ"
    except Exception as e:
        return False, str(e)


def set_global_rule(api, disabled):
    try:
        path = api.path("ip", "firewall", "filter")
        entries = list(path)
        found = False
        for entry in entries:
            if GLOBAL_RULE_COMMENT in entry.get("comment", ""):
                path.update(**{".id": entry[".id"], "disabled": "yes" if disabled else "no"})
                found = True
        if not found:
            return False, GLOBAL_RULE_COMMENT + " дүрэм олдсонгүй"
        return True, "Амжилттай"
    except librouteros.exceptions.TrapError as e:
        return False, "MikroTik алдаа: " + str(e)
    except Exception as e:
        return False, str(e)


def get_traffic(api):
    # ether1 шууд унших — WAN порт
    try:
        path = api.path("interface")
        result = list(path("monitor-traffic", **{"interface": "ether1", "once": ""}))
        if result:
            r = result[0]
            rx = int(r.get("rx-bits-per-second", 0)) // 1000000
            tx = int(r.get("tx-bits-per-second", 0)) // 1000000
            return rx, tx
    except Exception as e:
        logger.warning("ether1 traffic aldaa: %s", e)
    # ether1 амжилтгүй бол bridge1 туршина
    try:
        path = api.path("interface")
        result = list(path("monitor-traffic", **{"interface": "bridge1", "once": ""}))
        if result:
            r = result[0]
            rx = int(r.get("rx-bits-per-second", 0)) // 1000000
            tx = int(r.get("tx-bits-per-second", 0)) // 1000000
            return rx, tx
    except Exception as e:
        logger.warning("bridge1 traffic aldaa: %s", e)
    return None, None


def get_app_status(api, keyword):
    try:
        path = api.path("ip", "firewall", "address-list")
        entries = [e for e in path if e.get("list") == "block-social"]
        for entry in entries:
            if entry.get("dynamic") in ("true", True):
                continue
            addr = entry.get("address", "").lower()
            comment = entry.get("comment", "").lower()
            if keyword.lower() in addr or keyword.lower() in comment:
                return entry.get("disabled") in ("true", True, "yes")
    except Exception as e:
        logger.warning("Status aldaa (%s): %s", keyword, e)
    return False


def get_attack_logs(api, limit=20):
    """
    MikroTik log-оос login failure мэдэгдлийг авна.
    /log print where topics~"system" and message~"login failure"
    """
    try:
        path = api.path("log")
        entries = list(path)
        attacks = []
        for entry in entries:
            topics = entry.get("topics", "")
            message = entry.get("message", "")
            if "system" in topics and "login failure" in message:
                attacks.append({
                    "time": entry.get("time", ""),
                    "message": message,
                })
        return attacks[-limit:]
    except Exception as e:
        logger.warning("Log avahad aldaa: %s", e)
        return []


def extract_ip_from_message(message):
    """Log мэдэгдлээс IP хаяг олно."""
    if " from " in message:
        parts = message.split(" from ")
        if len(parts) > 1:
            ip_part = parts[1].split(" ")[0]
            # IP форматыг шалгана
            parts2 = ip_part.split(".")
            if len(parts2) == 4:
                return ip_part
    return ""


def block_attacker_ip(api, ip):
    """Халдагч IP-г firewall input chain-д хаана."""
    try:
        # Аль хэдийн хаагдсан эсэхийг шалгана
        path = api.path("ip", "firewall", "filter")
        entries = list(path)
        for entry in entries:
            if entry.get("src-address") == ip and entry.get("chain") == "input":
                return False, ip + " аль хэдийн хаагдсан байна"
        path.add(**{
            "chain": "input",
            "src-address": ip,
            "action": "drop",
            "comment": "Auto-block: " + ip,
        })
        return True, ip + " амжилттай хаагдлаа"
    except librouteros.exceptions.TrapError as e:
        return False, "MikroTik алдаа: " + str(e)
    except Exception as e:
        return False, str(e)


def main(page: ft.Page):
    page.title = "Сүлжээний удирдлага"
    page.theme_mode = ft.ThemeMode.DARK
    page.window_width = 480
    page.window_height = 720
    page.padding = 0
    page.bgcolor = "#0a0e1a"

    api_ref = {"api": None}
    monitor_running = {"value": False}

    # ── Login хуудас ──────────────────────────────────────
    host_field = ft.TextField(
        label="MikroTik IP хаяг",
        value="192.168.51.1",
        border_color="#1e293b",
        focused_border_color="#3b82f6",
        label_style=ft.TextStyle(color="#64748b"),
        color="white",
        bgcolor="#0f172a",
        border_radius=12,
        height=52,
    )
    user_field = ft.TextField(
        label="Хэрэглэгчийн нэр",
        border_color="#1e293b",
        focused_border_color="#3b82f6",
        label_style=ft.TextStyle(color="#64748b"),
        color="white",
        bgcolor="#0f172a",
        border_radius=12,
        height=52,
    )
    pass_field = ft.TextField(
        label="Нууц үг",
        password=True,
        can_reveal_password=True,
        border_color="#1e293b",
        focused_border_color="#3b82f6",
        label_style=ft.TextStyle(color="#64748b"),
        color="white",
        bgcolor="#0f172a",
        border_radius=12,
        height=52,
    )
    login_error = ft.Text("", color="#ef4444", size=13)
    login_progress = ft.ProgressBar(visible=False, color="#3b82f6", bgcolor="#1e293b")
    login_btn = ft.ElevatedButton(
        "Нэвтрэх",
        bgcolor="#3b82f6",
        color="white",
        height=50,
        style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=12)),
    )

    login_view = ft.Container(
        content=ft.Column(
            controls=[
                ft.Container(height=60),
                ft.Row(
                    controls=[ft.Icon(ft.Icons.ROUTER_ROUNDED, color="#3b82f6", size=48)],
                    alignment=ft.MainAxisAlignment.CENTER,
                ),
                ft.Container(height=16),
                ft.Text(
                    "Сүлжээний удирдлага",
                    size=24,
                    weight=ft.FontWeight.BOLD,
                    color="white",
                    text_align=ft.TextAlign.CENTER,
                ),
                ft.Container(height=4),
                ft.Text(
                    "MikroTik холболтын мэдээлэл оруулна уу",
                    size=13,
                    color="#64748b",
                    text_align=ft.TextAlign.CENTER,
                ),
                ft.Container(height=36),
                host_field,
                ft.Container(height=12),
                user_field,
                ft.Container(height=12),
                pass_field,
                ft.Container(height=8),
                login_error,
                ft.Container(height=8),
                login_progress,
                ft.Container(height=8),
                login_btn,
                ft.Container(height=20),
            ],
            spacing=0,
            horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
        ),
        padding=32,
        expand=True,
    )

    # ── Үндсэн хуудас ─────────────────────────────────────
    conn_text = ft.Text("Холбогдсон", size=13, color="#22c55e")
    traffic_dl = ft.Text("-- Mbps", size=20, weight=ft.FontWeight.BOLD, color="#38bdf8")
    traffic_ul = ft.Text("-- Mbps", size=20, weight=ft.FontWeight.BOLD, color="#4ade80")
    action_status = ft.Text("", size=13, color="#94a3b8")
    app_switches = {}

    # ── Халдлагын хяналт UI ───────────────────────────────
    attack_count_text = ft.Text("--", size=32, weight=ft.FontWeight.BOLD, color="#64748b")
    attack_label = ft.Text("Хяналт эхлүүлэнэ үү", size=12, color="#64748b")
    attack_log_column = ft.Column(controls=[], spacing=4, scroll=ft.ScrollMode.AUTO)
    monitor_btn = ft.ElevatedButton(
        "Хяналт эхлүүлэх",
        bgcolor="#1e3a5f",
        color="white",
        height=40,
        style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=10)),
    )

    def render_attack_logs(attacks):
        """Log жагсаалтыг UI-д харуулна."""
        count = len(attacks)
        attack_count_text.value = str(count)
        if count == 0:
            attack_label.value = "Халдлага илрээгүй"
            attack_label.color = "#22c55e"
            attack_count_text.color = "#22c55e"
        else:
            attack_label.value = "Халдлага илэрлээ!"
            attack_label.color = "#ef4444"
            attack_count_text.color = "#ef4444"

        attack_log_column.controls.clear()
        for atk in reversed(attacks[-10:]):
            ip = extract_ip_from_message(atk["message"])
            row_items = [
                ft.Text(atk["time"], size=10, color="#475569", width=65),
                ft.Text(atk["message"], size=11, color="#fca5a5", expand=True),
            ]
            if ip:
                row_items.append(
                    ft.TextButton(
                        "Хаах",
                        style=ft.ButtonStyle(color="#ef4444"),
                        on_click=lambda e, i=ip: do_block_ip(i),
                    )
                )
            attack_log_column.controls.append(
                ft.Container(
                    content=ft.Row(controls=row_items, spacing=4),
                    bgcolor="#160808",
                    border_radius=8,
                    padding=8,
                )
            )
        page.update()

    def do_block_ip(ip):
        """Товч дарахад IP хаана."""
        action_status.value = ip + " хаагдаж байна..."
        action_status.color = "#94a3b8"
        page.update()
        def run():
            ok, msg = block_attacker_ip(api_ref["api"], ip)
            action_status.value = msg
            action_status.color = "#22c55e" if ok else "#ef4444"
            page.update()
        threading.Thread(target=run, daemon=True).start()

    def toggle_monitor(e):
        """Хяналт эхлүүлэх / зогсоох товч."""
        if monitor_running["value"]:
            monitor_running["value"] = False
            monitor_btn.text = "Хяналт эхлүүлэх"
            monitor_btn.bgcolor = "#1e3a5f"
            page.update()
            return

        monitor_running["value"] = True
        monitor_btn.text = "Хяналт зогсоох"
        monitor_btn.bgcolor = "#450a0a"
        page.update()

        def loop():
            while monitor_running["value"]:
                try:
                    attacks = get_attack_logs(api_ref["api"], limit=20)
                    render_attack_logs(attacks)
                except Exception as ex:
                    logger.error("Monitor loop aldaa: %s", ex)
                time.sleep(5)

        threading.Thread(target=loop, daemon=True).start()

    monitor_btn.on_click = toggle_monitor

    def on_toggle(e, app_name):
        block = e.control.value
        keyword = SOCIAL_KEYWORDS[app_name]
        action_status.value = app_name + (" хаагдаж" if block else " нээгдэж") + " байна..."
        action_status.color = "#94a3b8"
        page.update()
        def run():
            ok, msg = set_app_disabled(api_ref["api"], keyword, disabled=not block)
            if ok:
                action_status.value = app_name + (" хаагдсан" if block else " нээлттэй")
                action_status.color = "#ef4444" if block else "#22c55e"
            else:
                action_status.value = "Алдаа: " + msg
                action_status.color = "#ef4444"
                e.control.value = not block
            page.update()
        threading.Thread(target=run, daemon=True).start()

    def block_all(e):
        for sw in app_switches.values():
            sw.value = True
        action_status.value = "Бүх сошиал хаагдаж байна..."
        action_status.color = "#94a3b8"
        page.update()
        def run():
            ok, msg = set_global_rule(api_ref["api"], disabled=False)
            action_status.value = "Бүх сошиал хаагдсан" if ok else "Алдаа: " + msg
            action_status.color = "#ef4444"
            page.update()
        threading.Thread(target=run, daemon=True).start()

    def unblock_all(e):
        for sw in app_switches.values():
            sw.value = False
        action_status.value = "Бүх сошиал нээгдэж байна..."
        action_status.color = "#94a3b8"
        page.update()
        def run():
            ok, msg = set_global_rule(api_ref["api"], disabled=True)
            action_status.value = "Бүх сошиал нээлттэй" if ok else "Алдаа: " + msg
            action_status.color = "#22c55e"
            page.update()
        threading.Thread(target=run, daemon=True).start()

    def refresh_traffic(e):
        traffic_dl.value = "..."
        traffic_ul.value = "..."
        page.update()
        def run():
            rx, tx = get_traffic(api_ref["api"])
            traffic_dl.value = str(rx) + " Mbps" if rx is not None else "Алдаа"
            traffic_ul.value = str(tx) + " Mbps" if tx is not None else "Алдаа"
            page.update()
        threading.Thread(target=run, daemon=True).start()

    def load_initial_status():
        for app_name, keyword in SOCIAL_KEYWORDS.items():
            is_blocked = get_app_status(api_ref["api"], keyword)
            app_switches[app_name].value = is_blocked
        page.update()

    def logout(e):
        monitor_running["value"] = False
        api_ref["api"] = None
        for sw in app_switches.values():
            sw.value = False
        action_status.value = ""
        login_error.value = ""
        pass_field.value = ""
        page.controls.clear()
        page.add(login_view)
        page.update()

    app_colors = {
        "YouTube": "#ef4444",
        "Facebook": "#3b82f6",
        "Telegram": "#38bdf8",
        "Viber": "#8b5cf6",
    }

    switch_rows = []
    for app_name in SOCIAL_KEYWORDS:
        sw = ft.Switch(
            value=False,
            active_color="#ef4444",
            inactive_thumb_color="#22c55e",
            on_change=lambda e, n=app_name: on_toggle(e, n),
        )
        app_switches[app_name] = sw
        switch_rows.append(
            ft.Container(
                content=ft.Row(
                    controls=[
                        ft.Container(
                            content=ft.Text(
                                app_name[0],
                                size=14,
                                weight=ft.FontWeight.BOLD,
                                color=app_colors.get(app_name, "white"),
                            ),
                            width=36,
                            height=36,
                            bgcolor="#1e293b",
                            border_radius=8,
                        ),
                        ft.Container(width=10),
                        ft.Text(app_name, size=15, color="white", expand=True),
                        ft.Text("Нээлттэй / Хаалттай", size=11, color="#475569"),
                        sw,
                    ]
                ),
                bgcolor="#0f172a",
                border_radius=12,
                padding=12,
                margin=4,
            )
        )

    main_view = ft.Column(
        controls=[
            # Header
            ft.Container(
                content=ft.Row(
                    controls=[
                        ft.Icon(ft.Icons.ROUTER_ROUNDED, color="#3b82f6", size=22),
                        ft.Container(width=8),
                        ft.Text(
                            "Сүлжээний удирдлага",
                            size=16,
                            weight=ft.FontWeight.BOLD,
                            color="white",
                            expand=True,
                        ),
                        ft.IconButton(
                            ft.Icons.LOGOUT_ROUNDED,
                            icon_color="#475569",
                            tooltip="Гарах",
                            on_click=logout,
                        ),
                    ]
                ),
                padding=14,
                bgcolor="#060c18",
            ),

            # Scroll content
            ft.Container(
                content=ft.Column(
                    controls=[
                        # Холболт
                        ft.Container(
                            content=ft.Row(
                                controls=[
                                    ft.Icon(ft.Icons.CIRCLE, color="#22c55e", size=10),
                                    ft.Container(width=6),
                                    conn_text,
                                ]
                            ),
                            bgcolor="#0f172a",
                            border_radius=12,
                            padding=14,
                        ),
                        ft.Container(height=12),

                        # Интернэт хурд
                        ft.Text("ИНТЕРНЭТ ХУРД", size=11, color="#64748b"),
                        ft.Container(height=6),
                        ft.Row(
                            controls=[
                                ft.Container(
                                    content=ft.Column(
                                        controls=[
                                            ft.Text("ТАТАХ", size=11, color="#64748b"),
                                            ft.Container(height=4),
                                            traffic_dl,
                                        ],
                                        spacing=0,
                                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                    ),
                                    bgcolor="#0f172a",
                                    border_radius=12,
                                    padding=16,
                                    expand=True,
                                ),
                                ft.Container(
                                    content=ft.Column(
                                        controls=[
                                            ft.Text("ИЛГЭЭХ", size=11, color="#64748b"),
                                            ft.Container(height=4),
                                            traffic_ul,
                                        ],
                                        spacing=0,
                                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                    ),
                                    bgcolor="#0f172a",
                                    border_radius=12,
                                    padding=16,
                                    expand=True,
                                ),
                                ft.IconButton(
                                    ft.Icons.REFRESH_ROUNDED,
                                    icon_color="#3b82f6",
                                    tooltip="Хурд шалгах",
                                    on_click=refresh_traffic,
                                ),
                            ],
                            spacing=8,
                        ),
                        ft.Container(height=16),

                        # Сошиал хяналт
                        ft.Text("СОШИАЛ МЕДИА ХЯНАЛТ", size=11, color="#64748b"),
                        ft.Container(height=6),
                        *switch_rows,
                        ft.Container(height=8),
                        action_status,
                        ft.Container(height=12),
                        ft.ElevatedButton(
                            "Бүгдийг хаах",
                            on_click=block_all,
                            bgcolor="#450a0a",
                            color="#fca5a5",
                            height=50,
                            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=12)),
                        ),
                        ft.Container(height=8),
                        ft.ElevatedButton(
                            "Бүгдийг нээх",
                            on_click=unblock_all,
                            bgcolor="#052e16",
                            color="#86efac",
                            height=50,
                            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=12)),
                        ),
                        ft.Container(height=20),

                        # ── Халдлагын хяналт ──────────────
                        ft.Text("ХАЛДЛАГЫН ХЯНАЛТ", size=11, color="#64748b"),
                        ft.Container(height=6),

                        # Тоолуур + товч
                        ft.Container(
                            content=ft.Row(
                                controls=[
                                    ft.Column(
                                        controls=[
                                            ft.Text("Нэвтрэх оролдлого", size=11, color="#64748b"),
                                            ft.Container(height=2),
                                            attack_count_text,
                                            attack_label,
                                        ],
                                        spacing=0,
                                        expand=True,
                                    ),
                                    monitor_btn,
                                ],
                                spacing=10,
                            ),
                            bgcolor="#0f172a",
                            border_radius=12,
                            padding=14,
                        ),
                        ft.Container(height=8),

                        # Log жагсаалт
                        ft.Container(
                            content=ft.Column(
                                controls=[
                                    ft.Text("Сүүлийн 10 оролдлого", size=11, color="#64748b"),
                                    ft.Container(height=8),
                                    attack_log_column,
                                ],
                                spacing=0,
                            ),
                            bgcolor="#0f172a",
                            border_radius=12,
                            padding=14,
                            height=280,
                        ),
                        ft.Container(height=20),
                    ],
                    scroll=ft.ScrollMode.AUTO,
                    spacing=0,
                ),
                padding=16,
                expand=True,
            ),
        ],
        spacing=0,
        expand=True,
    )

    # ── Нэвтрэх ───────────────────────────────────────────
    def do_login(e):
        login_error.value = ""
        host = host_field.value.strip()
        user = user_field.value.strip()
        pwd = pass_field.value
        if not host or not user or not pwd:
            login_error.value = "Бүх талбарыг бөглөнө үү"
            page.update()
            return
        login_btn.disabled = True
        login_progress.visible = True
        page.update()

        def run():
            try:
                api = librouteros.connect(host=host, username=user, password=pwd)
                api_ref["api"] = api
                page.controls.clear()
                page.add(main_view)
                page.update()
                threading.Thread(target=load_initial_status, daemon=True).start()
            except librouteros.exceptions.TrapError:
                login_error.value = "Нэвтрэх нэр эсвэл нууц үг буруу"
            except OSError:
                login_error.value = "Холбогдож чадсангүй: " + host
            except Exception as ex:
                login_error.value = "Алдаа: " + str(ex)
            finally:
                login_btn.disabled = False
                login_progress.visible = False
                page.update()

        threading.Thread(target=run, daemon=True).start()

    login_btn.on_click = do_login
    pass_field.on_submit = do_login
    page.add(login_view)


ft.app(target=main)
