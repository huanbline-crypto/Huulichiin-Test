@echo off
echo ============================================
echo   OCR APP - EXE БОЛГОХ СКРИПТ
echo ============================================
echo.

echo [1/3] PyInstaller суулгаж байна...
pip install pyinstaller

echo.
echo [2/3] EXE файл үүсгэж байна... (5-10 минут болно)
pyinstaller --noconfirm --onefile --windowed ^
  --name "ТестОЦР" ^
  --icon "assets\icon.ico" ^
  --add-data "assets;assets" ^
  ocr_app.py

echo.
echo [3/3] ДУУСЛАА!
echo.
echo ============================================
echo  EXE файл: dist\ТестОЦР.exe
echo ============================================
echo.
pause
