import os
import re
import json
import threading
import cv2
import numpy as np
import easyocr
import customtkinter as ctk
from tkinter import filedialog, messagebox
from PIL import Image


class OCRProcessorApp:
    def __init__(self):
        ctk.set_appearance_mode("Dark")
        ctk.set_default_color_theme("blue")

        self.root = ctk.CTk()
        self.root.title("Тест Боловсруулагч OCR")
        self.root.geometry("640x540")
        self.root.resizable(False, False)

        # Цонхны icon тохируулах
        import sys
        icon_paths = []
        if getattr(sys, 'frozen', False):
            # EXE горимд (PyInstaller)
            base = sys._MEIPASS
        else:
            # Хөгжүүлэлтийн горимд
            base = os.path.dirname(os.path.abspath(__file__))

        ico_path = os.path.join(base, "assets", "icon.ico")
        png_path = os.path.join(base, "assets", "icon.png")

        try:
            if os.path.exists(ico_path):
                self.root.iconbitmap(ico_path)
            elif os.path.exists(png_path):
                from PIL import ImageTk
                img = ImageTk.PhotoImage(file=png_path)
                self.root.iconphoto(True, img)
        except Exception:
            pass  # Icon олдохгүй бол үргэлжлүүлнэ

        self.selected_folder = ""
        self.is_processing = False

        self.create_widgets()
        self.reader = None

    def create_widgets(self):
        # ── Гарчиг ───────────────────────────────────────────────────────────
        ctk.CTkLabel(
            self.root,
            text="ТЕСТ БОЛОВСРУУЛАХ OCR ХЭРЭГСЭЛ",
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color="#7B2CBF"
        ).pack(pady=(20, 5))

        ctk.CTkLabel(
            self.root,
            text="Зургуудаас тестийн асуулт, хариултыг таньж (OCR),\n"
                 "ногоон өнгөтэй зөв хариултыг автоматаар илрүүлнэ.\n"
                 "Үр дүн нь зургийн хавтасанд хадгалагдана.",
            font=ctk.CTkFont(size=12),
            text_color="#8C8A97"
        ).pack(pady=(0, 10))

        # ── Хавтас сонгох ────────────────────────────────────────────────────
        folder_frame = ctk.CTkFrame(self.root, fg_color="#181824", corner_radius=10)
        folder_frame.pack(fill="x", padx=20, pady=5)

        self.folder_lbl = ctk.CTkLabel(
            folder_frame,
            text="Зургийн хавтас сонгогдоогүй байна...",
            font=ctk.CTkFont(size=12),
            text_color="#8C8A97",
            anchor="w"
        )
        self.folder_lbl.pack(side="left", padx=15, pady=12, fill="x", expand=True)

        ctk.CTkButton(
            folder_frame,
            text="Хавтас сонгох",
            command=self.select_folder,
            fg_color="#7B2CBF",
            hover_color="#9D4EDD"
        ).pack(side="right", padx=15, pady=12)

        # ── Хадгалах байршил харуулагч ───────────────────────────────────────
        save_frame = ctk.CTkFrame(self.root, fg_color="#181824", corner_radius=10)
        save_frame.pack(fill="x", padx=20, pady=5)

        ctk.CTkLabel(
            save_frame,
            text="💾  Хадгалах хавтас:",
            font=ctk.CTkFont(size=11, weight="bold"),
            text_color="#00F5D4"
        ).pack(side="left", padx=12, pady=8)

        self.save_lbl = ctk.CTkLabel(
            save_frame,
            text="(Зургийн хавтасаа сонгосны дараа автоматаар тогтогдоно)",
            font=ctk.CTkFont(size=11),
            text_color="#8C8A97",
            anchor="w"
        )
        self.save_lbl.pack(side="left", padx=4, pady=8, fill="x", expand=True)

        # ── Формат + эхлүүлэх товч ───────────────────────────────────────────
        controls_frame = ctk.CTkFrame(self.root, fg_color="transparent")
        controls_frame.pack(fill="x", padx=20, pady=8)

        ctk.CTkLabel(
            controls_frame,
            text="Формат:",
            font=ctk.CTkFont(size=12, weight="bold")
        ).pack(side="left", padx=(5, 8))

        self.format_var = ctk.StringVar(value="Хоёулаа (.txt + .json)")
        ctk.CTkOptionMenu(
            controls_frame,
            values=["Хоёулаа (.txt + .json)", "Зөвхөн Текст (.txt)", "Зөвхөн JSON (.json)"],
            variable=self.format_var,
            fg_color="#181824",
            button_color="#7B2CBF",
            button_hover_color="#9D4EDD"
        ).pack(side="left")

        self.start_btn = ctk.CTkButton(
            controls_frame,
            text="▶  Боловсруулж эхлэх",
            command=self.start_processing_thread,
            fg_color="#00F5D4",
            hover_color="#00D2B4",
            text_color="#111116",
            font=ctk.CTkFont(size=12, weight="bold")
        )
        self.start_btn.pack(side="right", padx=5)

        # ── Явц мөр ──────────────────────────────────────────────────────────
        prog_frame = ctk.CTkFrame(self.root, fg_color="transparent")
        prog_frame.pack(fill="x", padx=20, pady=4)

        self.progress_bar = ctk.CTkProgressBar(prog_frame, progress_color="#00F5D4")
        self.progress_bar.set(0)
        self.progress_bar.pack(fill="x", pady=4)

        self.status_lbl = ctk.CTkLabel(
            prog_frame,
            text="Ажиллахад бэлэн.",
            font=ctk.CTkFont(size=11),
            text_color="#8C8A97"
        )
        self.status_lbl.pack(anchor="w")

        # ── Лог ──────────────────────────────────────────────────────────────
        logs_frame = ctk.CTkFrame(self.root, fg_color="#181824", corner_radius=10)
        logs_frame.pack(fill="both", expand=True, padx=20, pady=(6, 20))

        self.log_txt = ctk.CTkTextbox(
            logs_frame,
            font=ctk.CTkFont(family="Consolas", size=11),
            fg_color="transparent",
            text_color="#F7F4F9"
        )
        self.log_txt.pack(fill="both", expand=True, padx=10, pady=10)

    # ── Туслах аргууд ─────────────────────────────────────────────────────────

    def log(self, msg):
        self.log_txt.insert("end", msg + "\n")
        self.log_txt.see("end")

    def select_folder(self):
        folder = filedialog.askdirectory()
        if folder:
            self.selected_folder = os.path.normpath(folder)
            self.folder_lbl.configure(text=self.selected_folder, text_color="#F7F4F9")
            # Хадгалах байршлыг автоматаар тогтоох
            self.save_lbl.configure(
                text=self.selected_folder,
                text_color="#00F5D4"
            )
            self.log(f"📂 Сонгогдсон хавтас: {self.selected_folder}")
            self.log(f"💾 Үр дүн хадгалагдах хавтас: {self.selected_folder}")

    def start_processing_thread(self):
        if not self.selected_folder:
            messagebox.showwarning("Анхааруулга", "Эхлээд зургийн хавтасаа сонгоно уу.")
            return
        if self.is_processing:
            return
        self.is_processing = True
        self.start_btn.configure(state="disabled")
        self.log_txt.delete("1.0", "end")
        threading.Thread(target=self.process_images, daemon=True).start()

    def read_image_unicode(self, img_path):
        try:
            with open(img_path, "rb") as f:
                file_bytes = np.frombuffer(f.read(), dtype=np.uint8)
            return cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)
        except Exception as e:
            print("Error reading image:", e)
            return None

    def check_if_green(self, img, bbox):
        try:
            if img is None:
                return False
            h, w, _ = img.shape
            xs = [pt[0] for pt in bbox]
            ys = [pt[1] for pt in bbox]
            x0, x1 = int(max(0, min(xs))), int(min(w, max(xs)))
            y0, y1 = int(max(0, min(ys))), int(min(h, max(ys)))
            if x1 <= x0 or y1 <= y0:
                return False
            margin_left = int((x1 - x0) * 0.15)
            x0e = max(0, x0 - margin_left)
            crop = img[y0:y1, x0e:x1]
            if crop is None or crop.size == 0:
                return False
            try:
                hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
            except Exception:
                return False
            mask = cv2.inRange(hsv, np.array([35, 15, 100]), np.array([85, 255, 255]))
            return (np.sum(mask > 0) / mask.size) > 0.03
        except Exception:
            return False

    def merge_lines(self, ocr_results, line_threshold=15):
        if not ocr_results:
            return []
        sorted_res = sorted(ocr_results, key=lambda x: x[0][0][1])
        merged_lines, current_line = [], []
        for item in sorted_res:
            bbox, text, prob = item
            y_center = (bbox[0][1] + bbox[2][1]) / 2
            if not current_line:
                current_line.append((bbox, text, prob, y_center))
            else:
                avg_y = sum(x[3] for x in current_line) / len(current_line)
                if abs(y_center - avg_y) < line_threshold:
                    current_line.append((bbox, text, prob, y_center))
                else:
                    merged_lines.append(current_line)
                    current_line = [(bbox, text, prob, y_center)]
        if current_line:
            merged_lines.append(current_line)

        final = []
        for line in merged_lines:
            line_sorted = sorted(line, key=lambda x: x[0][0][0])
            combined_text = " ".join([x[1] for x in line_sorted])
            bboxes = [x[0] for x in line_sorted]
            min_x = min(pt[0] for box in bboxes for pt in box)
            min_y = min(pt[1] for box in bboxes for pt in box)
            max_x = max(pt[0] for box in bboxes for pt in box)
            max_y = max(pt[1] for box in bboxes for pt in box)
            combined_bbox = [[min_x, min_y], [max_x, min_y], [max_x, max_y], [min_x, max_y]]
            avg_prob = sum(x[2] for x in line_sorted) / len(line_sorted)
            final.append((combined_bbox, combined_text, avg_prob))
        return final

    def parse_text_lines(self, merged_lines, img):
        q_pattern = re.compile(r"^\s*(\d+)[\.\-\s)]+")
        question_groups, current_group = [], []

        for item in merged_lines:
            bbox, text, prob = item
            text_strip = text.strip()
            if not text_strip:
                continue
            if q_pattern.match(text_strip):
                if current_group:
                    question_groups.append(current_group)
                current_group = [item]
            else:
                if current_group:
                    current_group.append(item)
                else:
                    current_group = [item]
        if current_group:
            question_groups.append(current_group)

        questions = []
        for group in question_groups:
            if len(group) < 5:
                questions.append({
                    "question": " ".join([x[1].strip() for x in group]),
                    "options": {},
                    "correct_answer": None
                })
            else:
                opt_lines = group[-4:]
                q_text = " ".join([x[1].strip() for x in group[:-4]])
                options = {}
                correct_answer = None
                for i, (bbox, text, prob) in enumerate(opt_lines):
                    letter = "ABCD"[i]
                    cleaned = re.sub(r"^\s*[A-DА-Гa-dа-г][\.\-\s)]+\s*", "", text.strip())
                    options[letter] = cleaned
                    if self.check_if_green(img, bbox):
                        correct_answer = letter
                questions.append({
                    "question": q_text,
                    "options": options,
                    "correct_answer": correct_answer
                })
        return questions

    def resize_image_if_needed(self, img, max_width=1200):
        try:
            h, w = img.shape[:2]
            if w > max_width:
                ratio = max_width / w
                img = cv2.resize(img, (max_width, int(h * ratio)), interpolation=cv2.INTER_AREA)
                self.log(f"  ↓ Зургийг оновчлов: ({h}×{w}) → ({int(h*ratio)}×{max_width})")
            return img
        except Exception:
            return img

    # ── Үндсэн боловсруулалт ──────────────────────────────────────────────────

    def process_images(self):
        try:
            if self.reader is None:
                self.update_status("EasyOCR ачаалж байна...", 0.05)
                self.log("🔄 EasyOCR хөдөлгүүрийг ачаалж байна...")
                self.reader = easyocr.Reader(['mn', 'ru'], gpu=False)

            valid_exts = (".png", ".jpg", ".jpeg")
            files = [f for f in os.listdir(self.selected_folder) if f.lower().endswith(valid_exts)]

            if not files:
                self.log("❌ Алдаа: Зураг олдсонгүй (.png/.jpg/.jpeg).")
                self.reset_state("Зураг олдсонгүй.")
                return

            self.log(f"📄 Нийт {len(files)} зураг олдлоо. Боловсруулж байна...\n")
            all_questions = []

            for idx, file_name in enumerate(files):
                img_path = os.path.join(self.selected_folder, file_name)
                self.update_status(
                    f"Уншиж байна: {file_name} ({idx+1}/{len(files)})",
                    (idx + 1) / len(files) * 0.90
                )
                self.log(f"[{idx+1}/{len(files)}] {file_name}")

                img = self.read_image_unicode(img_path)
                if img is None:
                    self.log(f"  ⚠ Зургийг уншиж чадсангүй.")
                    continue

                img = self.resize_image_if_needed(img)
                raw_results = self.reader.readtext(img)
                merged_lines = self.merge_lines(raw_results)
                file_questions = self.parse_text_lines(merged_lines, img)

                self.log(f"  ✔ {len(file_questions)} асуулт танигдлаа.")
                for q in file_questions:
                    self.log(f"    • {q['question'][:50]}...")
                    self.log(f"      Хариулт: {list(q['options'].keys())} | Зөв: {q['correct_answer']}")

                all_questions.extend(file_questions)

            self.update_status("Хадгалж байна...", 0.95)
            # Хадгалах ажлыг үндсэн thread дээр гүйцэтгэнэ
            self.root.after(0, lambda: self.export_results(all_questions))

        except Exception as e:
            self.log(f"\n❌ Алдаа: {e}")
            self.reset_state("Алдаа гарлаа.")

    # ── Хадгалах — зургийн хавтас руу автоматаар ──────────────────────────────

    def export_results(self, questions):
        fmt = self.format_var.get()
        saved = []
        base = self.selected_folder          # зургийн хавтас

        # ── TXT ──
        if "Текст" in fmt or "Хоёулаа" in fmt:
            txt_path = os.path.join(base, "ocr_results.txt")
            try:
                with open(txt_path, "w", encoding="utf-8") as f:
                    for idx, q in enumerate(questions):
                        f.write(f"Асуулт {idx+1}: {q['question']}\n")
                        for letter, text in sorted(q['options'].items()):
                            f.write(f"  {letter}. {text}\n")
                        correct = q['correct_answer'] or "Илрээгүй"
                        f.write(f"  ✅ Зөв хариулт: {correct}\n")
                        f.write("-" * 50 + "\n\n")
                self.log(f"\n💾 TXT хадгаллаа → {txt_path}")
                saved.append("ocr_results.txt")
            except Exception as e:
                self.log(f"❌ TXT хадгалахад алдаа: {e}")

        # ── JSON ──
        if "JSON" in fmt or "Хоёулаа" in fmt:
            json_path = os.path.join(base, "ocr_results.json")
            try:
                json_data = [
                    {
                        "id": i + 1,
                        "question": q["question"],
                        "options": q["options"],
                        "correct_answer": q["correct_answer"]
                    }
                    for i, q in enumerate(questions)
                ]
                with open(json_path, "w", encoding="utf-8") as f:
                    json.dump(json_data, f, ensure_ascii=False, indent=4)
                self.log(f"💾 JSON хадгаллаа → {json_path}")
                saved.append("ocr_results.json")
            except Exception as e:
                self.log(f"❌ JSON хадгалахад алдаа: {e}")

        # ── Дуусгах ──
        self.log("\n" + "=" * 46)
        self.log("✅ АМЖИЛТТАЙ ДУУСЛАА!")
        self.log(f"   Нийт танигдсан асуулт: {len(questions)}")
        if saved:
            self.log(f"   Хадгалсан файлууд: {', '.join(saved)}")
            self.log(f"   Байршил: {base}")
        self.log("=" * 46)

        self.reset_state("Амжилттай дууслаа!")

        if saved:
            messagebox.showinfo(
                "Амжилттай",
                f"Боловсруулалт дууслаа!\n\n"
                f"Хадгалсан файлууд:\n" +
                "\n".join(f"  • {f}" for f in saved) +
                f"\n\nБайршил:\n{base}"
            )

    # ── UI update helpers ──────────────────────────────────────────────────────

    def update_status(self, text, progress):
        self.root.after(0, lambda: (
            self.status_lbl.configure(text=text),
            self.progress_bar.set(progress)
        ))

    def reset_state(self, status_text):
        def _do():
            self.is_processing = False
            self.start_btn.configure(state="normal")
            self.status_lbl.configure(text=status_text)
            if "Амжилттай" in status_text:
                self.progress_bar.set(1.0)
        self.root.after(0, _do)


if __name__ == "__main__":
    app = OCRProcessorApp()
    app.root.mainloop()