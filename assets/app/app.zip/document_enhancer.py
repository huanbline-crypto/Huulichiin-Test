import cv2
import numpy as np
import os
import sys
from pathlib import Path
from datetime import datetime
from PIL import Image as PILImage


# ─── Зураг сайжруулах ────────────────────────────────────────────────────────

def order_points(pts):
    rect = np.zeros((4, 2), dtype="float32")
    s    = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]
    rect[2] = pts[np.argmax(s)]
    diff    = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]
    rect[3] = pts[np.argmax(diff)]
    return rect


def four_point_transform(image, pts):
    rect = order_points(pts)
    tl, tr, br, bl = rect
    maxW = max(int(np.linalg.norm(br - bl)), int(np.linalg.norm(tr - tl)))
    maxH = max(int(np.linalg.norm(tr - br)), int(np.linalg.norm(tl - bl)))
    dst  = np.array([[0,0],[maxW-1,0],[maxW-1,maxH-1],[0,maxH-1]],
                    dtype="float32")
    return cv2.warpPerspective(
        image, cv2.getPerspectiveTransform(rect, dst), (maxW, maxH))


def enhance_document(image_path, output_path=None):
    with open(image_path, "rb") as f:
        data = np.frombuffer(f.read(), dtype=np.uint8)
    orig = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if orig is None:
        return None

    # Хэрэв зургийн арын дэвсгэр нь бараан (Dark mode) байвал цагаан дэвсгэртэй болгож хөрвүүлнэ
    gray_check = cv2.cvtColor(orig, cv2.COLOR_BGR2GRAY)
    if np.median(gray_check) < 70:
        orig = 255 - orig

    h, w  = orig.shape[:2]
    scale = 800 / max(h, w)
    small = cv2.resize(orig, None, fx=scale, fy=scale)
    sh, sw = small.shape[:2]

    gray  = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(cv2.GaussianBlur(gray,(5,5),0), 50, 150)
    edges = cv2.dilate(edges, np.ones((3,3),np.uint8), iterations=2)

    contours, _ = cv2.findContours(
        edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)[:10]

    doc_contour = None
    for c in contours:
        peri   = cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, 0.02*peri, True)
        if len(approx) == 4 and cv2.contourArea(approx) > sh*sw*0.2:
            doc_contour = approx
            break

    warped = (four_point_transform(
                  orig, doc_contour.reshape(4,2).astype("float32")/scale)
              if doc_contour is not None else orig.copy())

    gray_w = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)
    ksize  = max(51, (min(gray_w.shape[:2]) // 10) | 1)
    bg     = cv2.GaussianBlur(gray_w, (ksize, ksize), 0)
    clean  = cv2.bitwise_not(
                 cv2.normalize(cv2.subtract(bg, gray_w),
                               None, 0, 255, cv2.NORM_MINMAX))
    _, binary = cv2.threshold(clean, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE,
                               np.ones((1,1), np.uint8))
    gauss  = cv2.GaussianBlur(binary, (0,0), 3)
    result = cv2.cvtColor(
                 cv2.addWeighted(binary,1.5,gauss,-0.5,0),
                 cv2.COLOR_GRAY2BGR)

    if output_path is None:
        p = Path(image_path)
        output_path = str(p.parent / f"{p.stem}_enhanced.png")

    ext = Path(output_path).suffix
    ok, enc = cv2.imencode(
        ext, result,
        [cv2.IMWRITE_JPEG_QUALITY, 95, cv2.IMWRITE_PNG_COMPRESSION, 1])
    if ok:
        with open(output_path, "wb") as f:
            f.write(enc.tobytes())
        return output_path
    return None


# ─── Зургийн файлуудыг цуглуулах ─────────────────────────────────────────────

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif"}


def collect_images(folder):
    """
    Хавтас дахь БҮГД зургийн файлуудыг нэрээр эрэмбэлж буцаана.
    output.pdf, output.docx-г алгасана. Ямар ч нэрийн шүүлт хийхгүй.
    """
    p     = Path(folder)
    files = []
    for f in sorted(p.iterdir()):
        if not f.is_file():
            continue
        if f.suffix.lower() not in IMAGE_EXTS:
            continue
        files.append(f)
    return files


# ─── PDF үүсгэх ──────────────────────────────────────────────────────────────

def images_to_pdf(image_paths, pdf_path, log_fn=print):
    try:
        from PIL import Image
    except ImportError:
        raise ImportError("pip install pillow")

    A4_W, A4_H = 2480, 3508   # 300 dpi A4

    pages = []
    for p in image_paths:
        try:
            img   = Image.open(p).convert("RGB")
            ratio = min(A4_W / img.width, A4_H / img.height)
            nw    = int(img.width  * ratio)
            nh    = int(img.height * ratio)
            img   = img.resize((nw, nh), Image.LANCZOS)
            canvas = Image.new("RGB", (A4_W, A4_H), (255,255,255))
            canvas.paste(img, ((A4_W-nw)//2, (A4_H-nh)//2))
            pages.append(canvas)
            log_fn(f"  + {Path(p).name}")
        except Exception as e:
            log_fn(f"  ⚠ {Path(p).name}: {e}")

    if not pages:
        return False

    pages[0].save(pdf_path, "PDF", resolution=300,
                  save_all=True, append_images=pages[1:])
    return True


# ─── Word (DOCX) үүсгэх ──────────────────────────────────────────────────────

def ocr_image_to_text(img_path, reader=None, log_fn=print):
    """
    Зургаас текст унших — Tesseract эсвэл easyocr ашиглана.
    Үг хоорондын зай, мөр дарааллыг зөв тохируулна.
    """
    import cv2, numpy as np

    # Зураг унших
    with open(img_path, "rb") as f:
        data = np.frombuffer(f.read(), dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        return ""

    # Хэрэв зургийн арын дэвсгэр нь бараан (Dark mode) байвал цагаан дэвсгэртэй болгож хөрвүүлнэ
    gray_check = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    if np.median(gray_check) < 70:
        img = 255 - img

    # ── Tesseract ──────────────────────────────────────────────────────────
    try:
        import pytesseract
        from PIL import Image as PILImage

        # Tesseract байрлал — таны компьютер дээр олдсон зам
        import os, glob, shutil
        TESS_PATH = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
        candidates = [
            TESS_PATH,
            r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
        ]
        # AppData дотроос хайх
        appdata = os.environ.get("LOCALAPPDATA", "")
        if appdata:
            found_list = glob.glob(
                os.path.join(appdata, "**", "tesseract.exe"), recursive=True)
            candidates += found_list
        t = shutil.which("tesseract")
        if t:
            candidates.insert(0, t)

        found = False
        for tp in candidates:
            if os.path.exists(tp):
                pytesseract.pytesseract.tesseract_cmd = tp
                found = True
                break

        if not found:
            raise FileNotFoundError(
                f"Tesseract олдсонгүй!\n"
                f"Шалгах зам: {TESS_PATH}"
            )

        # Зургийг тод болгох
        gray   = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # DPI нэмэх — бага нарийвчлалтай зургийг томруулна
        h, w   = gray.shape
        if max(h, w) < 2000:
            scale = 2000 / max(h, w)
            gray  = cv2.resize(gray, None, fx=scale, fy=scale,
                               interpolation=cv2.INTER_CUBIC)
        _, binary = cv2.threshold(gray, 0, 255,
                                  cv2.THRESH_BINARY + cv2.THRESH_OTSU)

        pil_img = PILImage.fromarray(binary)

        # Суулгасан хэлүүдийг илрүүлж тохируулах (mon, rus, eng)
        try:
            available_langs = pytesseract.get_languages()
        except Exception:
            available_langs = []

        langs_to_use = []
        for l in ["mon", "rus", "eng"]:
            if l in available_langs:
                langs_to_use.append(l)
        if not langs_to_use:
            langs_to_use = ["eng"]

        lang_str = "+".join(langs_to_use)
        config  = f"--psm 6 -l {lang_str}"
        text    = pytesseract.image_to_string(pil_img, config=config)

        if text.strip():
            log_fn("  [Tesseract OCR ашиглав]")
            return text

    except ImportError:
        pass
    except Exception as e:
        log_fn(f"  Tesseract алдаа: {e}")

    # ── EasyOCR fallback ───────────────────────────────────────────────────
    if reader is None:
        try:
            import easyocr
            log_fn("  [EasyOCR ачаалж байна...]")
            reader = easyocr.Reader(['mn', 'ru'], gpu=False)
        except ImportError:
            raise ImportError("pip install easyocr  эсвэл  pip install pytesseract")

    results = reader.readtext(img)
    if not results:
        return ""

    # bbox Y байрлалаар эрэмбэлэх
    items = [(r[0], r[1], r[2]) for r in results]
    items.sort(key=lambda x: (x[0][0][1] + x[0][2][1]) / 2)

    # Ойрхон Y-тэй үгсийг нэг мөрт нэгтгэх
    LINE_GAP = 18
    lines    = []
    cur_line = []

    for bbox, text, conf in items:
        y_mid = (bbox[0][1] + bbox[2][1]) / 2
        x_left = bbox[0][0]
        if not cur_line:
            cur_line.append((x_left, y_mid, text))
        else:
            last_y = sum(i[1] for i in cur_line) / len(cur_line)
            if abs(y_mid - last_y) <= LINE_GAP:
                cur_line.append((x_left, y_mid, text))
            else:
                lines.append(cur_line)
                cur_line = [(x_left, y_mid, text)]
    if cur_line:
        lines.append(cur_line)

    # Мөр дотор X-ээр эрэмбэлж, ЗАЙ оруулах
    text_lines = []
    for line in lines:
        line.sort(key=lambda x: x[0])
        words = []
        prev_right = None
        for x_left, y_mid, word in line:
            if prev_right is not None:
                gap = x_left - prev_right
                # Том зай → 2 зай, жижиг зай → 1 зай
                if gap > 30:
                    words.append("  ")
                else:
                    words.append(" ")
            words.append(word.strip())
            # Баруун ирмэг тооцох (ойролцоо)
            prev_right = x_left + len(word) * 10
        text_lines.append("".join(words))

    log_fn("  [EasyOCR ашиглав]")
    return "\n".join(text_lines)


def process_ocr_document(image_path, doc, reader=None, log_fn=print):
    # Зураг унших
    with open(image_path, "rb") as f:
        data = np.frombuffer(f.read(), dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Зургийг уншиж чадсангүй")
        
    h_orig, w_orig = img.shape[:2]
    
    # Хэрэв зургийн арын дэвсгэр нь бараан (Dark mode) байвал цагаан дэвсгэртэй болгож хөрвүүлнэ
    gray_check = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    if np.median(gray_check) < 70:
        img = 255 - img
        
    # Хүснэгт илрүүлэхийн тулд зургийн хэмжээг тохируулах
    target_w = 1200
    scale = target_w / w_orig
    img_resized = cv2.resize(img, (target_w, int(h_orig * scale)))
    gray = cv2.cvtColor(img_resized, cv2.COLOR_BGR2GRAY)
    
    # Хоёртын (binary) зураг болгох
    is_binary = np.mean((gray < 15) | (gray > 240)) > 0.80
    if is_binary:
        thresh = 255 - gray
    else:
        thresh = cv2.adaptiveThreshold(
            ~gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 15, -2
        )
    
    # Хэвтээ болон босоо шугамуудыг ялгаж авах
    cols = thresh.shape[1]
    horizontal_size = cols // 40
    horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (horizontal_size, 1))
    horizontal_lines = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, horizontal_kernel)
    
    rows = thresh.shape[0]
    vertical_size = rows // 40
    vertical_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, vertical_size))
    vertical_lines = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, vertical_kernel)
    
    grid = cv2.add(horizontal_lines, vertical_lines)
    
    # Торны бүх контурыг олох
    contours, _ = cv2.findContours(grid, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    
    # Нүд байх боломжтой контуруудыг хэмжээгээр нь шүүх
    candidates = []
    for cnt in contours:
        cx, cy, cw, ch = cv2.boundingRect(cnt)
        if 15 < cw < 800 and 10 < ch < 200:
            candidates.append((cx, cy, cw, ch))
            
    # Зөвхөн хамгийн доод шатны (навч) нүднүүдийг үлдээх (дотроо өөр нүд агуулаагүй)
    raw_cells = []
    for cx, cy, cw, ch in candidates:
        is_parent = False
        for c2x, c2y, c2w, c2h in candidates:
            if (c2w < cw or c2h < ch) and c2x > cx and c2y > cy and c2x+c2w < cx+cw and c2y+c2h < cy+ch:
                is_parent = True
                break
        if not is_parent:
            raw_cells.append((cx, cy, cw, ch))
            
    has_table = len(raw_cells) >= 4
    
    try:
        import pytesseract
        available_langs = pytesseract.get_languages()
    except Exception:
        available_langs = []
        
    langs_to_use = []
    for l in ["mon", "rus", "eng"]:
        if l in available_langs:
            langs_to_use.append(l)
    if not langs_to_use:
        langs_to_use = ["eng"]
    lang_str = "+".join(langs_to_use)
    config = f"--psm 6 -l {lang_str}"
    
    def ocr_region(image, y_start_scale, y_end_scale):
        y_start = int(y_start_scale / scale)
        y_end = int(y_end_scale / scale)
        crop = image[y_start:y_end, 0:w_orig]
        if crop.size == 0 or crop.shape[0] < 10:
            return ""
        crop_gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
        
        # Moiré болон гэрлийн нөлөөг арилгах зорилгоор бага зэрэг бүрсийлгэнэ
        crop_gray = cv2.GaussianBlur(crop_gray, (3, 3), 0)
        
        max_dim = max(crop_gray.shape[:2])
        if max_dim < 2000:
            s = 2000 / max_dim
            crop_gray = cv2.resize(crop_gray, None, fx=s, fy=s, interpolation=cv2.INTER_CUBIC)
        _, crop_bin = cv2.threshold(crop_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        pil_img = PILImage.fromarray(crop_bin)
        return pytesseract.image_to_string(pil_img, config=f"--psm 3 -l {lang_str}").strip()

    from docx.shared import Pt
    
    if has_table:
        # Хүснэгтийн бодит Y болон X-ийн хязгаарыг олох
        tx = min(x for (x, y, w, h) in raw_cells)
        ty = min(y for (x, y, w, h) in raw_cells)
        tw = max(x + w for (x, y, w, h) in raw_cells) - tx
        th = max(y + h for (x, y, w, h) in raw_cells) - ty
        
        log_fn(f"    [Хүснэгт илэрлээ: {len(raw_cells)} нүдтэй]")
        
        # 1. Хүснэгтийн дээрх текстийг унших
        header_text = ocr_region(img, 0, ty)
        if header_text:
            for line in header_text.splitlines():
                if line.strip():
                    doc.add_paragraph(line.strip())
                    
        # 2. Хүснэгтийн бүтцийг үүсгэх
        x_coords = sorted([x for (x, y, w, h) in raw_cells] + [x + w for (x, y, w, h) in raw_cells])
        y_coords = sorted([y for (x, y, w, h) in raw_cells] + [y + h for (x, y, w, h) in raw_cells])
        
        def merge_coords(coords, tol):
            if not coords:
                return []
            merged = [coords[0]]
            for c in coords[1:]:
                if c - merged[-1] > tol:
                    merged.append(c)
            return merged
            
        col_edges = merge_coords(x_coords, 15)
        row_edges = merge_coords(y_coords, 12)
        
        num_cols = len(col_edges) - 1
        num_rows = len(row_edges) - 1
        
        grid_cells = [[None for _ in range(num_cols)] for _ in range(num_rows)]
        
        for cell in raw_cells:
            cx, cy, cw, ch = cell
            overlapping_rows = []
            for r in range(num_rows):
                r_top = row_edges[r]
                r_bottom = row_edges[r+1]
                overlap = min(cy + ch, r_bottom) - max(cy, r_top)
                if overlap > 0.4 * (r_bottom - r_top) and overlap > 0.4 * ch:
                    overlapping_rows.append(r)
                    
            overlapping_cols = []
            for c in range(num_cols):
                c_left = col_edges[c]
                c_right = col_edges[c+1]
                overlap = min(cx + cw, c_right) - max(cx, c_left)
                if overlap > 0.4 * (c_right - c_left) and overlap > 0.4 * cw:
                    overlapping_cols.append(c)
                    
            if overlapping_rows and overlapping_cols:
                r_start = min(overlapping_rows)
                r_end = max(overlapping_rows)
                c_start = min(overlapping_cols)
                c_end = max(overlapping_cols)
                
                cell_info = {
                    'box': cell,
                    'r_start': r_start,
                    'r_end': r_end,
                    'c_start': c_start,
                    'c_end': c_end
                }
                for r in range(r_start, r_end + 1):
                    for c in range(c_start, c_end + 1):
                        grid_cells[r][c] = cell_info
                        
        docx_table = doc.add_table(rows=num_rows, cols=num_cols)
        processed_boxes = set()
        
        for r in range(num_rows):
            for c in range(num_cols):
                cell_info = grid_cells[r][c]
                if cell_info is None:
                    continue
                box = cell_info['box']
                if box in processed_boxes:
                    continue
                processed_boxes.add(box)
                bx, by, bw, bh = box
                
                docx_cell = docx_table.cell(cell_info['r_start'], cell_info['c_start'])
                if cell_info['r_start'] != cell_info['r_end'] or cell_info['c_start'] != cell_info['c_end']:
                    target_cell = docx_table.cell(cell_info['r_end'], cell_info['c_end'])
                    docx_cell = docx_cell.merge(target_cell)
                    
                orig_x = int(bx / scale)
                orig_y = int(by / scale)
                orig_w = int(bw / scale)
                orig_h = int(bh / scale)
                
                orig_x_pad = max(0, orig_x - 2)
                orig_y_pad = max(0, orig_y - 2)
                orig_w_pad = min(w_orig - orig_x_pad, orig_w + 4)
                orig_h_pad = min(h_orig - orig_y_pad, orig_h + 4)
                
                cell_crop = img[orig_y_pad:orig_y_pad+orig_h_pad, orig_x_pad:orig_x_pad+orig_w_pad]
                cell_gray = cv2.cvtColor(cell_crop, cv2.COLOR_BGR2GRAY)
                
                if np.mean(cell_gray) < 127:
                    cell_gray = 255 - cell_gray
                    
                if cell_gray.shape[0] < 50:
                    cell_gray = cv2.resize(cell_gray, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)
                    
                # Clean up binary cell image or run Otsu thresholding
                if np.max(cell_gray) - np.min(cell_gray) > 10:
                    _, cell_bin = cv2.threshold(cell_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
                else:
                    cell_bin = cell_gray
                    
                cell_text = pytesseract.image_to_string(cell_bin, config=config).strip()
                docx_cell.text = cell_text
                if docx_cell.paragraphs[0].runs:
                    docx_cell.paragraphs[0].runs[0].font.size = Pt(9)
                
        # 3. Хүснэгтийн доорх текстийг унших
        footer_text = ocr_region(img, ty + th, thresh.shape[0])
        if footer_text:
            doc.add_paragraph("")
            for line in footer_text.splitlines():
                if line.strip():
                    doc.add_paragraph(line.strip())
    else:
        # Хүснэгтгүй бол энгийн текстээр унших
        log_fn("    [Энгийн текстээр уншиж байна]")
        full_text = ocr_image_to_text(image_path, reader=reader, log_fn=log_fn)
        if not full_text.strip():
            doc.add_paragraph(f"[{Path(image_path).name} — текст илрээгүй]")
        else:
            for line in full_text.splitlines():
                if line.strip():
                    doc.add_paragraph(line.strip())


def images_to_word(image_paths, docx_path, log_fn=print,
                   ocr_mode=False, ocr_reader=None):
    """
    ocr_mode=False  → зургийг шууд Word-д оруулна (зурган хэлбэр)
    ocr_mode=True   → OCR ашиглан текст уншаад Word-д бичнэ
    """
    try:
        from docx import Document
        from docx.shared import Cm, Pt, RGBColor
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.oxml.ns  import qn
        from docx.oxml     import OxmlElement
    except ImportError:
        raise ImportError("pip install python-docx")

    # OCR горимд reader бэлдэнэ (Tesseract байвал reader хэрэггүй)
    reader = None
    if ocr_mode:
        # Tesseract байгаа эсэх шалгана
        tesseract_ok = False
        try:
            import pytesseract, os, glob, shutil
            candidates = [
                r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
            ]
            appdata = os.environ.get("LOCALAPPDATA", "")
            if appdata:
                candidates += glob.glob(
                    os.path.join(appdata, "**", "tesseract.exe"), recursive=True)
            t = shutil.which("tesseract")
            if t:
                candidates.insert(0, t)
            for tp in candidates:
                if os.path.exists(tp):
                    pytesseract.pytesseract.tesseract_cmd = tp
                    break
            pytesseract.get_tesseract_version()
            tesseract_ok = True
            log_fn("  ✔ Tesseract OCR ашиглана (илүү нарийвчлалтай)\n")
        except Exception:
            pass

        if not tesseract_ok:
            # EasyOCR fallback
            try:
                import easyocr
                log_fn("  🔄 EasyOCR ачаалж байна...")
                reader = ocr_reader or easyocr.Reader(['mn', 'ru'], gpu=False)
                log_fn("  ✔ EasyOCR бэлэн\n")
            except ImportError:
                raise ImportError(
                    "Tesseract эсвэл EasyOCR суулгана уу.\n"
                    "Tesseract: https://github.com/UB-Mannheim/tesseract/wiki\n"
                    "EasyOCR: pip install easyocr"
                )

    doc     = Document()
    section = doc.sections[0]
    section.page_width    = Cm(21)
    section.page_height   = Cm(29.7)
    section.top_margin    = Cm(2)
    section.bottom_margin = Cm(2)
    section.left_margin   = Cm(2.5)
    section.right_margin  = Cm(2.5)

    for i, p in enumerate(image_paths):
        if not os.path.exists(p):
            continue

        # Хуудасны завсар (эхний хуудсаас бусад)
        if i > 0:
            para = doc.add_paragraph()
            run  = para.add_run()
            br   = OxmlElement("w:br")
            br.set(qn("w:type"), "page")
            run._r.append(br)

        if ocr_mode:
            # ── OCR: текст уншина ─────────────────────────────────────────
            log_fn(f"  📖 OCR уншиж байна: {Path(p).name}")
            try:
                process_ocr_document(p, doc, reader=reader, log_fn=log_fn)
            except Exception as e:
                log_fn(f"    ❌ OCR алдаа: {e}")
                para = doc.add_paragraph()
                para.alignment = WD_ALIGN_PARAGRAPH.CENTER
                para.add_run().add_picture(p, width=Cm(16))

        else:
            # ── Зурган горим: зургийг шууд оруулна ───────────────────────
            para = doc.add_paragraph()
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            para.add_run().add_picture(p, width=Cm(19))
            cap = doc.add_paragraph(Path(p).stem)
            cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
            cap.runs[0].font.size = Pt(8)
            log_fn(f"  + {Path(p).name}")

    doc.save(docx_path)
    return True


# ─── GUI ─────────────────────────────────────────────────────────────────────

def run_gui():
    try:
        import customtkinter as ctk
        from tkinter import filedialog, messagebox
        import threading, io, contextlib
        import windnd

        ctk.set_appearance_mode("Dark")
        ctk.set_default_color_theme("blue")

        root = ctk.CTk()
        root.title("Ц.Энхбатын баримт хөрвүүлэгч")
        root.geometry("620x680")
        root.resizable(False, False)

        try:
            base = (sys._MEIPASS if getattr(sys,"frozen",False)
                    else os.path.dirname(os.path.abspath(__file__)))
            ico = os.path.join(base, "assets", "icon.ico")
            if os.path.exists(ico):
                root.iconbitmap(ico)
        except Exception:
            pass

        sel = {"folder": "", "files": []}

        # ── Гарчиг ────────────────────────────────────────────────────────
        ctk.CTkLabel(root, text="Ц.ЭНХБАТЫН БАРИМТ ХӨРВҮҮЛЭГЧ",
                     font=ctk.CTkFont(size=20, weight="bold"),
                     text_color="#7B2CBF").pack(pady=(14,3))

        ctk.CTkLabel(root,
                     text="① Файл эсвэл хавтас чирж оруулна уу (эсвэл Сонгох товчийг дарна уу)\n"
                          "② Горим сонгоно уу   ③ Боловсруулах дарна уу",
                     font=ctk.CTkFont(size=11),
                     text_color="#8C8A97").pack(pady=(0,6))

        # ── Хавтас сонгох ─────────────────────────────────────────────────
        row = ctk.CTkFrame(root, fg_color="#181824", corner_radius=10)
        row.pack(fill="x", padx=20, pady=3)

        folder_lbl = ctk.CTkLabel(
            row, text="Файл/хавтас чирэх эсвэл сонгох...",
            font=ctk.CTkFont(size=11),
            text_color="#8C8A97", anchor="w")
        folder_lbl.pack(side="left", padx=12, pady=10,
                        fill="x", expand=True)

        def pick():
            f = filedialog.askdirectory(title="Зургийн хавтас сонгоно уу")
            if not f:
                return
            sel["folder"] = os.path.normpath(f)
            imgs = collect_images(sel["folder"])
            sel["files"] = imgs
            folder_lbl.configure(
                text=f"{sel['folder']}",
                text_color="#F7F4F9")
            save_lbl.configure(
                text=f"💾  {sel['folder']}\\enhanced\\",
                text_color="#00F5D4")
            log_box.delete("1.0","end")
            log(f"📂 {sel['folder']}")
            log(f"   → {len(imgs)} зургийн файл олдлоо:\n")
            for img in imgs:
                log(f"   • {img.name}")
            if not imgs:
                log("\n   ⚠ Зураг олдсонгүй! Зургийн хавтасаа шалгана уу.")

        def on_drop(files):
            if not files:
                return
            decoded_paths = []
            for f in files:
                if isinstance(f, bytes):
                    try:
                        path = f.decode(sys.getfilesystemencoding())
                    except Exception:
                        path = f.decode('utf-8')
                else:
                    path = f
                decoded_paths.append(os.path.normpath(path))
            
            dirs = [p for p in decoded_paths if os.path.isdir(p)]
            if dirs:
                sel["folder"] = dirs[0]
                imgs = collect_images(sel["folder"])
                sel["files"] = imgs
                folder_lbl.configure(
                    text=f"{sel['folder']}",
                    text_color="#F7F4F9")
                save_lbl.configure(
                    text=f"💾  {sel['folder']}\\enhanced\\",
                    text_color="#00F5D4")
                log_box.delete("1.0", "end")
                log(f"📂 Чирсэн хавтас: {sel['folder']}")
                log(f"   → {len(imgs)} зургийн файл олдлоо:\n")
                for img in imgs:
                    log(f"   • {img.name}")
                if not imgs:
                    log("\n   ⚠ Зураг олдсонгүй! Зургийн хавтасаа шалгана уу.")
            else:
                valid_files = [Path(p) for p in decoded_paths if Path(p).suffix.lower() in IMAGE_EXTS]
                if not valid_files:
                    messagebox.showwarning("Анхааруулга", "Дэмжигдэх форматтай зургийн файл олдсонгүй!\n(Дэмжих формат: .jpg, .jpeg, .png, .bmp, .tiff)")
                    return
                first_file = valid_files[0]
                sel["folder"] = str(first_file.parent)
                sel["files"] = valid_files
                folder_lbl.configure(
                    text=f"{len(valid_files)} зураг сонгогдлоо ({sel['folder']})",
                    text_color="#F7F4F9")
                save_lbl.configure(
                    text=f"💾  {sel['folder']}\\enhanced\\",
                    text_color="#00F5D4")
                log_box.delete("1.0", "end")
                log(f"📂 Чирсэн файлууд ({len(valid_files)} зураг):")
                for f in valid_files:
                    log(f"   • {f.name}")

        ctk.CTkButton(
            row, text="📁  Сонгох", command=pick,
            fg_color="#7B2CBF", hover_color="#9D4EDD",
            width=110).pack(side="right", padx=12, pady=10)

        # Register Drag & Drop Hook
        windnd.hook_dropfiles(root, func=on_drop, force_unicode=True)

        # ── Хадгалах зам ──────────────────────────────────────────────────
        save_row = ctk.CTkFrame(root, fg_color="#0F0F1A", corner_radius=8)
        save_row.pack(fill="x", padx=20, pady=(2,3))
        save_lbl = ctk.CTkLabel(
            save_row,
            text="💾  Хавтас сонгох эсвэл файлаа чирж оруулна уу",
            font=ctk.CTkFont(size=11),
            text_color="#444455", anchor="w")
        save_lbl.pack(fill="x", padx=12, pady=7)

        # ── Горим сонгох ──────────────────────────────────────────────────
        mode_frame = ctk.CTkFrame(root, fg_color="#181824", corner_radius=10)
        mode_frame.pack(fill="x", padx=20, pady=3)

        ctk.CTkLabel(mode_frame,
                     text="Горим:",
                     font=ctk.CTkFont(size=12, weight="bold")).pack(
                         side="left", padx=14, pady=10)

        mode_var = ctk.StringVar(value="Сайжруулаад → PDF + Word (текст)")
        mode_menu = ctk.CTkOptionMenu(
            mode_frame,
            values=[
                "Сайжруулаад → PDF + Word (текст)",
                "Сайжруулаад → PDF + Word (зураг)",
                "Сайжруулаад → PDF",
                "Сайжруулаад → Word (текст)",
                "Сайжруулаад → Word (зураг)",
                "Сайжруулаад → PNG + PDF + Word (текст)",
                "Сайжруулаад → PNG",
                "─────────────────────────────",
                "Зургуудыг PDF болгох",
                "Зургуудыг Word болгох (текст)",
                "Зургуудыг Word болгох (зураг)",
                "Зургуудыг PDF + Word болгох (текст)",
            ],
            variable=mode_var,
            fg_color="#1A1A2E",
            button_color="#7B2CBF",
            button_hover_color="#9D4EDD",
            width=300,
            dynamic_resizing=False
        )
        mode_menu.pack(side="left", padx=4, pady=10)

        # ── Явц мөр ───────────────────────────────────────────────────────
        pf = ctk.CTkFrame(root, fg_color="transparent")
        pf.pack(fill="x", padx=20, pady=(3,2))

        bar = ctk.CTkProgressBar(pf, progress_color="#00F5D4", height=8)
        bar.set(0)
        bar.pack(fill="x")

        status_lbl = ctk.CTkLabel(
            pf, text="Ажиллахад бэлэн.",
            font=ctk.CTkFont(size=10), text_color="#8C8A97")
        status_lbl.pack(anchor="w", pady=(2,0))

        # ── Эхлүүлэх товч — ЛОГО-ОС ӨМНӨ ─────────────────────────────────
        start_btn = ctk.CTkButton(
            root, text="▶   БОЛОВСРУУЛАХ",
            fg_color="#00F5D4", hover_color="#00D2B4",
            text_color="#0A0A12",
            font=ctk.CTkFont(size=14, weight="bold"),
            height=46, corner_radius=10)
        start_btn.pack(fill="x", padx=20, pady=(6,3))

        # ── Лог ───────────────────────────────────────────────────────────
        lf = ctk.CTkFrame(root, fg_color="#181824", corner_radius=10)
        lf.pack(fill="both", expand=True, padx=20, pady=(0,14))

        log_box = ctk.CTkTextbox(
            lf, font=ctk.CTkFont(family="Consolas", size=10),
            fg_color="transparent", text_color="#C8C5D0")
        log_box.pack(fill="both", expand=True, padx=8, pady=8)

        def log(msg):
            root.after(0, lambda: (
                log_box.insert("end", msg+"\n"),
                log_box.see("end")))

        def set_status(text, prog=None):
            root.after(0, lambda: status_lbl.configure(text=text))
            if prog is not None:
                root.after(0, lambda: bar.set(prog))

        # ── Боловсруулах ──────────────────────────────────────────────────
        def run():
            folder = sel["folder"]
            if not folder:
                messagebox.showwarning("Анхааруулга",
                    "Эхлээд хавтас сонгох эсвэл файлаа чирж оруулна уу!")
                return

            files = sel.get("files", [])
            if not files:
                files = collect_images(folder)
                sel["files"] = files

            if not files:
                messagebox.showinfo("Мэдэгдэл",
                    f"'{folder}' хавтасанд зургийн файл олдсонгүй.\n\n"
                    "Дэмжигдэх формат: .jpg .jpeg .png .bmp .tiff")
                return

            mode = mode_var.get()
            if "─" in mode:
                messagebox.showwarning("Анхааруулга", "Горимоо сонгоно уу!")
                return

            # Юу хийх вэ
            do_enhance = "Сайжруулаад" in mode
            do_png     = "PNG" in mode
            do_pdf     = "PDF" in mode
            do_word    = "Word" in mode
            do_ocr     = "текст" in mode      # Word-д текст хэлбэрээр

            start_btn.configure(state="disabled",
                                text="⏳  Боловсруулж байна...")
            log_box.delete("1.0","end")

            out_dir = Path(folder) / "enhanced"
            out_dir.mkdir(exist_ok=True)

            log(f"📄 Нийт {len(files)} зураг")
            log(f"   Горим: {mode}")
            log(f"💾 {out_dir}\n")
            log("━"*48)

            def worker():
                # ── Сайжруулах эсвэл шууд ашиглах ────────────────────────
                if do_enhance:
                    log(f"\n[1/3] Зургуудыг сайжруулж байна...\n")
                    proc_paths = []
                    for i, f in enumerate(files, 1):
                        set_status(
                            f"Сайжруулж байна {i}/{len(files)}...",
                            i/len(files)*0.5)
                        root.after(0, lambda n=f.name, idx=i:
                            log(f"  [{idx}/{len(files)}] {n}"))

                        if do_png:
                            out_img = str(out_dir / f"{f.stem}_enhanced.png")
                        else:
                            out_img = str(out_dir / f"_tmp_{i:04d}.png")

                        r = enhance_document(str(f), out_img)
                        if r:
                            proc_paths.append(r)
                            root.after(0, lambda: log("    ✔"))
                        else:
                            root.after(0, lambda n=f.name:
                                log(f"    ⚠ алдаа: {n}"))

                    root.after(0, lambda n=len(proc_paths):
                        log(f"\n  → {n} зураг бэлэн\n"))
                    pdf_word_step = 2
                else:
                    # Сайжруулалтгүй — байгаа зургуудыг шууд ашиглана
                    proc_paths = [str(f) for f in files]
                    root.after(0, lambda n=len(proc_paths):
                        log(f"\n  → {n} зураг ачаалав\n"))
                    pdf_word_step = 1

                if not proc_paths:
                    root.after(0, lambda: (
                        messagebox.showerror("Алдаа",
                            "Нэг ч зураг боловсруулаж чадсангүй."),
                        start_btn.configure(state="normal",
                                            text="▶   БОЛОВСРУУЛАХ")))
                    return

                saved = []

                # ── PDF ───────────────────────────────────────────────────
                if do_pdf:
                    step = pdf_word_step
                    set_status(f"PDF үүсгэж байна...", 0.65)
                    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                    pdf_name = f"сканнердсан_{ts}.pdf"
                    pdf_path = str(out_dir / pdf_name)
                    root.after(0, lambda s=step, n=len(proc_paths):
                        log(f"[{s}/3] PDF үүсгэж байна "
                            f"({n} зургийг нэгтгэнэ)...\n"))
                    def _log_pdf(m):
                        root.after(0, lambda mm=m: log(f"  {mm}"))
                    try:
                        if images_to_pdf(proc_paths, pdf_path, _log_pdf):
                            sz = os.path.getsize(pdf_path) // 1024
                            saved.append(f"{pdf_name}  ({sz} KB)")
                            root.after(0, lambda s=sz, name=pdf_name:
                                log(f"\n  ✔ {name}  ({s} KB)\n"))
                    except ImportError as e:
                        root.after(0, lambda e=str(e):
                            log(f"  ⚠ {e}\n"))
                    except Exception as e:
                        root.after(0, lambda e=str(e):
                            log(f"  ❌ PDF алдаа: {e}\n"))
                    pdf_word_step += 1

                # ── Word ──────────────────────────────────────────────────
                if do_word:
                    step = pdf_word_step
                    set_status(f"Word файл үүсгэж байна...", 0.85)
                    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                    docx_name = f"сканнердсан_{ts}.docx"
                    docx_path = str(out_dir / docx_name)
                    mode_desc = "OCR текст" if do_ocr else "зураг"
                    root.after(0, lambda s=step, n=len(proc_paths), m=mode_desc:
                        log(f"[{s}/3] Word файл үүсгэж байна "
                            f"({n} зураг → {m})...\n"))
                    def _log_word(m):
                        root.after(0, lambda mm=m: log(f"  {mm}"))
                    try:
                        if images_to_word(proc_paths, docx_path, _log_word,
                                          ocr_mode=do_ocr):
                            sz = os.path.getsize(docx_path) // 1024
                            saved.append(f"{docx_name}  ({sz} KB)")
                            root.after(0, lambda s=sz, name=docx_name:
                                log(f"\n  ✔ {name}  ({s} KB)\n"))
                    except ImportError as e:
                        root.after(0, lambda e=str(e):
                            log(f"  ⚠ {e}\n"))
                    except Exception as e:
                        root.after(0, lambda e=str(e):
                            log(f"  ❌ Word алдаа: {e}\n"))

                # ── Түр файл устгах ───────────────────────────────────────
                if do_enhance and not do_png:
                    for ep in proc_paths:
                        try: os.remove(ep)
                        except Exception: pass

                if do_png:
                    saved.insert(0,
                        f"*_enhanced.png  ({len(proc_paths)} файл)")

                # ── Дуусгах ───────────────────────────────────────────────
                def done():
                    bar.set(1.0)
                    status_lbl.configure(text="✅ Амжилттай дууслаа!")
                    start_btn.configure(state="normal",
                                        text="▶   БОЛОВСРУУЛАХ")
                    log("━"*48)
                    log(f"✅  ДУУСЛАА!  "
                        f"({len(proc_paths)}/{len(files)} зураг)")
                    for s in saved:
                        log(f"  📎 {s}")
                    log(f"📁 {out_dir}")
                    log("━"*48)
                    summary = "\n".join(f"  • {s}" for s in saved)
                    messagebox.showinfo("Амжилттай",
                        f"{len(proc_paths)}/{len(files)} зураг!\n\n"
                        f"Хадгалсан файлууд:\n{summary}\n\n"
                        f"Байршил:\n{out_dir}")

                root.after(0, done)

            threading.Thread(target=worker, daemon=True).start()

        start_btn.configure(command=run)
        root.mainloop()

    except ImportError:
        print("customtkinter олдсонгүй")
        if len(sys.argv) > 1:
            cli_process(sys.argv[1])


# ─── Командын горим ──────────────────────────────────────────────────────────

def cli_process(folder_path):
    files = collect_images(folder_path)
    if not files:
        print("Зураг олдсонгүй."); return

    out_dir = Path(folder_path) / "enhanced"
    out_dir.mkdir(exist_ok=True)
    print(f"📁 {len(files)} зураг  →  {out_dir}\n")

    enhanced = []
    for i, f in enumerate(files, 1):
        print(f"[{i}/{len(files)}] {f.name}")
        out = str(out_dir / f"{f.stem}_enhanced.png")
        r   = enhance_document(str(f), out)
        if r: enhanced.append(r)

    if enhanced:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        pdf_name = f"сканнердсан_{ts}.pdf"
        docx_name = f"сканнердсан_{ts}.docx"
        
        print(f"\n📄 PDF ({len(enhanced)} зураг)...")
        try:
            images_to_pdf(enhanced, str(out_dir / pdf_name))
            print(f"  ✔ {pdf_name}")
        except Exception as e:
            print(f"  ⚠ {e}")
        print("📝 Word...")
        try:
            images_to_word(enhanced, str(out_dir / docx_name))
            print(f"  ✔ {docx_name}")
        except Exception as e:
            print(f"  ⚠ {e}")

    print(f"\n✅ ДУУСЛАА!  {out_dir}")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        path = sys.argv[1]
        if   os.path.isdir(path):  cli_process(path)
        elif os.path.isfile(path): enhance_document(path)
        else: print(f"⚠ Олдсонгүй: {path}")
    else:
        run_gui()