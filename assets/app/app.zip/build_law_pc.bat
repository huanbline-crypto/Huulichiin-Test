@echo off
echo ============================================
echo   ХУУЛЬЧИЙН ТЕСТ - WINDOWS EXE БОЛГОХ СКРИПТ
echo ============================================
echo.
echo [1/2] Windows EXE файл үүсгэж байна...
.venv\Scripts\flet.exe pack test_database.py --icon assets/law_icon.ico --name "Хуульчийн_Тест" --add-data "questions.json;." --add-data "pyfonts;pyfonts" -y
echo.
echo [2/2] ДУУСЛАА!
echo EXE файл: dist\Хуульчийн_Тест.exe
echo ============================================
