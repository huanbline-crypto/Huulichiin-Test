@echo off
start "" ".venv\Scripts\pythonw.exe" ocr_processor.py
exit
