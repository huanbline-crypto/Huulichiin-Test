import os
import sys
import codecs
from law_parser import get_law_text

def main():
    try:
        print("Reading law...")
        text = get_law_text("ТӨРИЙН АЛБАНЫ ТУХАЙ.doc")
        out_path = "law_text.txt"
        with codecs.open(out_path, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"Successfully wrote {len(text)} characters to {out_path}")
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
