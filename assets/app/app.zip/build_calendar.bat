@echo off
echo ============================================
echo   BUILDING CALENDAR APP WINDOWS EXE
echo ============================================
echo Installing required dependencies...
pip install pyinstaller flet requests
echo Running Flet Packager...
flet pack calendar_app.py --icon assets/icon.ico --name "Ц_Энхбатын_Үүлэн_Календарь" -y
echo Done.
pause
