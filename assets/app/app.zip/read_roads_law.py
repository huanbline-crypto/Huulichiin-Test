import docx
import os

docx_path = r"D:\AJIL\ALFA OMEGA\МИНИЙХ\ХУУЛЬЧИЙН СОНГОН ШАЛГАРУУЛАЛТ 2025\хуулиуд\АВТО ЗАМЫН ТУХАЙ.docx"
txt_path = r"C:\Users\DELL\PycharmProjects\pythonProject\roads_law.txt"

def extract_text():
    if not os.path.exists(docx_path):
        print(f"Error: Docx file not found at {docx_path}")
        return
    
    doc = docx.Document(docx_path)
    fullText = []
    for para in doc.paragraphs:
        fullText.append(para.text)
    
    # Also get text from tables, if any
    for table in doc.tables:
        for row in table.rows:
            row_text = [cell.text for cell in row.cells]
            fullText.append(" | ".join(row_text))
            
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write("\n".join(fullText))
    print(f"Successfully extracted text to {txt_path}")

if __name__ == "__main__":
    extract_text()
