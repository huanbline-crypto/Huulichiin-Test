"""
Сэтгэл зүй, Бүтээмжийн Цогц Сорил — Flet 0.85 (Насны Баталгаажуулалт Засагдсан)
Засварууд:
  - Нас оруулах хэсэгт зөвхөн бүхэл тоо (0-9) орсон эсэхийг шалгадаг логик нэмж, үсэг бичихэд унадаг алдааг засав.
  - Таны ирүүлсэн кодын бүх үг, өгүүлбэр, FilePicker-гүй төгс логик хэвээр хадгалагдсан.
"""
import sqlite3
import os
import sys
import platform
import subprocess
from datetime import datetime
import flet as ft
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors as pdf_colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable

# ─── Замуудыг тодорхойлох ────────────────────────────────────────────────────
if getattr(sys, "frozen", False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

ASSETS_DIR = os.path.join(BASE_DIR, "assets")
DB_PATH = os.path.join(BASE_DIR, "temperament_results.db")
os.makedirs(ASSETS_DIR, exist_ok=True)

ICON_SRC = None
for img in ("image_956bc4.png", "icon.png", "image_1690c9.png", "audio.png"):
    if os.path.exists(os.path.join(ASSETS_DIR, img)):
        ICON_SRC = os.path.join("assets", img)
        break


# ─── МОНГОЛ ФОНТ ТОХИРУУЛАХ ──────────────────────────────────────────────────
def _find_font(names):
    dirs = []
    if platform.system() == "Windows":
        win = os.environ.get("WINDIR", "C:/Windows")
        dirs = [os.path.join(win, "Fonts"),
                os.path.join(os.path.expanduser("~"), "AppData/Local/Microsoft/Windows/Fonts")]
    else:
        dirs = ["/usr/share/fonts/truetype/dejavu", "/usr/share/fonts/truetype/freefont",
                "/usr/share/fonts/truetype/liberation"]
    for n in names:
        for d in dirs:
            p = os.path.join(d, n)
            if os.path.exists(p):
                return p
    return None


def setup_fonts():
    reg = _find_font(["arialuni.ttf", "arial.ttf", "calibri.ttf", "segoeui.ttf", "DejaVuSans.ttf", "FreeSans.ttf"])
    bld = _find_font(["arialbd.ttf", "calibrib.ttf", "segoeuib.ttf", "DejaVuSans-Bold.ttf", "FreeSansBold.ttf"])
    fallback_r = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    fallback_b = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
    try:
        pdfmetrics.registerFont(TTFont("MN", reg or fallback_r))
        pdfmetrics.registerFont(TTFont("MN-Bold", bld or fallback_b))
    except Exception:
        pass


setup_fonts()


# ─── ӨГӨГДЛИЙН БААЗЫГ ХЯНАЖ ШИНЭЧЛЭХ ─────────────────────────────────────────
def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT test_type FROM results LIMIT 1")
    except sqlite3.OperationalError:
        cursor.execute("DROP TABLE IF EXISTS results")

    conn.execute("""
        CREATE TABLE IF NOT EXISTS results (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            date        TEXT,
            last_name   TEXT,
            first_name  TEXT,
            age         INTEGER,
            gender      TEXT,
            test_type   TEXT,
            temperament TEXT,
            h_score     INTEGER,
            s_score     INTEGER,
            f_score     INTEGER,
            m_score     INTEGER,
            stress_score INTEGER,
            prod_score  INTEGER,
            eysenck_lie INTEGER,
            eysenck_extra INTEGER,
            eysenck_neuro INTEGER,
            description TEXT
        )
    """)
    # Хуучин results.db файл дээр шинэ багана байхгүй бол нэмнэ
    try:
        cursor.execute("PRAGMA table_info(results)")
        existing_cols = {row[1] for row in cursor.fetchall()}
        if "eysenck_lie" not in existing_cols:
            cursor.execute("ALTER TABLE results ADD COLUMN eysenck_lie INTEGER DEFAULT 0")
        if "eysenck_extra" not in existing_cols:
            cursor.execute("ALTER TABLE results ADD COLUMN eysenck_extra INTEGER DEFAULT 0")
        if "eysenck_neuro" not in existing_cols:
            cursor.execute("ALTER TABLE results ADD COLUMN eysenck_neuro INTEGER DEFAULT 0")
    except Exception:
        pass

    conn.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
    cursor.execute("SELECT value FROM settings WHERE key='password'")
    if not cursor.fetchone():
        conn.execute("INSERT INTO settings (key, value) VALUES ('password', 'Eba123')")
    conn.commit()
    conn.close()


def get_current_password():
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT value FROM settings WHERE key='password'")
        row = cursor.fetchone()
        conn.close()
        return row[0] if (row and row[0]) else "Eba123"
    except Exception:
        return "Eba123"


def update_password(new_pwd):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("UPDATE settings SET value=? WHERE key='password'", (new_pwd,))
    conn.commit()
    conn.close()


def save_result_to_db(last_name, first_name, age, gender, test_type, temperament, h, s, f, m, stress, prod,
                      description, eysenck_lie=0, eysenck_extra=0, eysenck_neuro=0):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        INSERT INTO results (date, last_name, first_name, age, gender, test_type, temperament, h_score, s_score, f_score, m_score, stress_score, prod_score, eysenck_lie, eysenck_extra, eysenck_neuro, description)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"), last_name, first_name, age, gender, test_type, temperament, h, s,
        f,
        m, stress, prod, eysenck_lie, eysenck_extra, eysenck_neuro, description))
    conn.commit()
    conn.close()


# ==================== 2. PDF ТАЙЛАН ҮҮСГЭХ ХЭСЭГ ====================
def generate_pdf_report(user_info, test_title, test_result_name, score_data, description):
    desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
    target_dir = os.path.join(desktop_path, "Шинжилгээний_Тайлангууд")
    os.makedirs(target_dir, exist_ok=True)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    clean_title = test_title.replace(" ", "_")
    filepath = os.path.join(target_dir, f"Тайлан_{user_info['first_name']}_{clean_title}_{ts}.pdf")

    doc = SimpleDocTemplate(filepath, pagesize=A4, topMargin=2 * cm, bottomMargin=2 * cm, leftMargin=2.2 * cm,
                            rightMargin=2.2 * cm)
    styles = getSampleStyleSheet()

    def S(name, font="MN", **kw):
        return ParagraphStyle(name, fontName=font, parent=styles["Normal"], **kw)

    s_title = S("t", font="MN-Bold", fontSize=18, textColor=pdf_colors.HexColor("#1A365D"), spaceAfter=6, leading=26)
    s_sub = S("s", fontSize=10, textColor=pdf_colors.HexColor("#718096"), spaceAfter=14, leading=14)
    s_section = S("sc", font="MN-Bold", fontSize=13, textColor=pdf_colors.HexColor("#2B6CB0"), spaceAfter=8, leading=20)
    s_body = S("b", fontSize=11, textColor=pdf_colors.HexColor("#2D3748"), spaceAfter=6, leading=18)
    s_result = S("r", font="MN-Bold", fontSize=18, textColor=pdf_colors.HexColor("#276749"), spaceAfter=10, leading=26)

    story = []
    story.append(Paragraph(f"СЭТГЭЛ ЗҮЙН ШИНЖИЛГЭЭ: {test_title.upper()}", s_title))
    story.append(Paragraph(f"Огноо: {datetime.now().strftime('%Y-%m-%d  %H:%M')}", s_sub))
    story.append(HRFlowable(width="100%", thickness=1, color=pdf_colors.HexColor("#CBD5E0")))
    story.append(Spacer(1, 10))

    story.append(Paragraph("Сорил өгөгчийн мэдээлэл", s_section))
    u_data = [
        [Paragraph(f"<b>Овог:</b> {user_info['last_name']}", s_body),
         Paragraph(f"<b>Нэр:</b> {user_info['first_name']}", s_body)],
        [Paragraph(f"<b>Нас:</b> {user_info['age']} настай", s_body),
         Paragraph(f"<b>Хүйс:</b> {user_info['gender']}", s_body)]
    ]
    u_tbl = Table(u_data, colWidths=[8 * cm, 8 * cm])
    u_tbl.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('BOTTOMPADDING', (0, 0), (-1, -1), 4)]))
    story.append(u_tbl)
    story.append(Spacer(1, 12))
    story.append(HRFlowable(width="100%", thickness=0.5, color=pdf_colors.HexColor("#E2E8F0")))
    story.append(Spacer(1, 10))

    story.append(Paragraph("Үнэлгээний үзүүлэлт", s_section))
    # Хүснэгтийн багануудыг контентоос хамаарч тохируулна.
    # Урт Монгол өгүүлбэрийг Paragraph болгож байж нүдэндээ багтана.
    if test_title.startswith("Айзенкийн"):
        score_data = [
            [Paragraph(str(c), s_body) for c in row]
            for row in score_data
        ]
        tbl = Table(score_data, colWidths=[7.0 * cm, 1.7 * cm, 1.9 * cm, 5.4 * cm], repeatRows=1)
    else:
        score_data = [
            [Paragraph(str(c), s_body) for c in row]
            for row in score_data
        ]
        tbl = Table(score_data, colWidths=[7.2 * cm, 2.5 * cm, 2.5 * cm, 3.8 * cm], repeatRows=1)
    tbl.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "MN"),
        ("FONTNAME", (0, 0), (-1, 0), "MN-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9 if test_title.startswith("Айзенкийн") else 11),
        ("BACKGROUND", (0, 0), (-1, 0), pdf_colors.HexColor("#2B6CB0")),
        ("TEXTCOLOR", (0, 0), (-1, 0), pdf_colors.white),
        ("ALIGN", (1, 0), (2, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [pdf_colors.HexColor("#EDF2F7"), pdf_colors.HexColor("#E2E8F0")]),
        ("GRID", (0, 0), (-1, -1), 0.5, pdf_colors.HexColor("#CBD5E0")),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(tbl)
    story.append(Spacer(1, 16))

    story.append(HRFlowable(width="100%", thickness=1, color=pdf_colors.HexColor("#CBD5E0")))
    story.append(Spacer(1, 10))
    story.append(Paragraph("Дүн шинжилгээний дүгнэлт", s_section))
    story.append(Paragraph(f"Үр дүн: {test_result_name}", s_result))

    for para in description.split("\n\n"):
        if para.strip():
            clean_p = para.replace("\n", "<br/>")
            story.append(Paragraph(clean_p, s_body))

    doc.build(story)
    try:
        if platform.system() == "Windows":
            os.startfile(filepath)
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", filepath])
        else:
            subprocess.Popen(["xdg-open", filepath])
    except Exception:
        pass
    return filepath


# ─── АСУУЛТУУДЫН САНГУУД ─────────────────────────────────────────────────────
TEMPERAMENT_QUESTIONS = [
    {"text": "1.  Та тогтворгүй, байнга гар хуруугаараа юм оролдож суудаг уу?", "type": "H"},
    {"text": "2.  Та омогтой, огцом ууртай юу?", "type": "H"},
    {"text": "3.  Та тэвчээргүй, биеэ барьж чаддаггүй үе олон уу?", "type": "H"},
    {"text": "4.  Та шийдэмгий, санаачилгатай хүн үү?", "type": "H"},
    {"text": "5.  Та зөрүүд үү?", "type": "H"},
    {"text": "6.  Та маргаанд бусдыг цэцээр дийлэх дуртай юу?", "type": "H"},
    {"text": "7.  Та үе үе хэт түргэн, яаруу ажилладаг уу?", "type": "H"},
    {"text": "8.  Хүмүүстэй харьцахдаа шууд шулуун, хурц ханддаг уу?", "type": "H"},
    {"text": "9.  Та азаа үзэх, эрсдэлтэй алхам хийх дуртай юу?", "type": "H"},
    {"text": "10. Таны өсөрхөж уурлах нь маш түргэн үү?", "type": "H"},
    {"text": "11. Сэтгэлийн хөдөлгөөнтэй, огцом түргэн хэл яриатай юу?", "type": "H"},
    {"text": "12. Та заримдаа хэрүүлч зан гаргачих гээд байдаг уу?", "type": "H"},
    {"text": "13. Бусдын дутагдлыг тэвчиж чаддаггүй юу?", "type": "H"},
    {"text": "14. Та түрэмгий, дээрэлхүү зан гаргах гээд байдаг уу?", "type": "H"},
    {"text": "15. Таныг ярихад нүүр гарны чинь хөдөлгөөн нь их байдаг уу?", "type": "H"},
    {"text": "16. Та аливааг түргэн бодож шийдвэрлэх чадвартай юу?", "type": "H"},
    {"text": "17. Та шинэ зүйлд, шинэ орчинд дасахдаа удаан уу?", "type": "H"},
    {"text": "18. Та тавьсан зорилгодоо хүрэхдээ тууштай юу?", "type": "H"},
    {"text": "19. Таны алхаа гишгээ огцом түргэн үү?", "type": "H"},
    {"text": "20. Таны ааш зан эрс амархан өөрчлөгддөг үү?", "type": "H"},
    {"text": "21. Та хөгжилтэй, баяр баясгалантай, чанга хөхөрдөг үү?", "type": "S"},
    {"text": "22. Та эрч хүчтэй, ажилсаг байж чаддаг уу?", "type": "S"},
    {"text": "23. Эхэлсэн зүйлээ дуусгалгүй орхих нь танд цөөнгүй юу?", "type": "S"},
    {"text": "24. Та өөрийгөө хэт үнэлэх талтай юу?", "type": "S"},
    {"text": "25. Та шинэ зүйлд маш хурдан хүлээн авдаг уу?", "type": "S"},
    {"text": "26. Та сониуч, харилцаа тань тогтворгүй юу?", "type": "S"},
    {"text": "27. Эвгүй зүйлд зовж шаналах нь танд харьцангуй бага уу?", "type": "S"},
    {"text": "28. Та янз бүрийн нөхцөл байдалд түргэн дасдаг уу?", "type": "S"},
    {"text": "29. Аливаа шинэ ажлыг дуртай эхлүүлдэг үү?", "type": "S"},
    {"text": "30. Сонирхолгүй зүйлдээ амархан шантардаг уу?", "type": "S"},
    {"text": "31. Ажилд идэвхтэй оролцож, нэг ажлаас нөгөөд амархан шилждэг үү?", "type": "S"},
    {"text": "32. Та бусдыг уриалан зохион байгуулах чадвартай юу?", "type": "S"},
    {"text": "33. Нийтэч үү? Шинэ хүмүүсээс нэрэлхэж эмээдэггүй юу?", "type": "S"},
    {"text": "34. Та их тэсвэртэй ажиллаж чаддаг уу?", "type": "S"},
    {"text": "35. Нүүр гарын хөдөлгөөн ихтэй, чанга түргэн яриатай юу?", "type": "S"},
    {"text": "36. Гэнэтийн тохиолдолд биеэ барьж чаддаг уу?", "type": "S"},
    {"text": "37. Та ямагт цовоо сэргэлэн байж чаддаг уу?", "type": "S"},
    {"text": "38. Та түргэн унтаж, хурдан sэрдэг үү?", "type": "S"},
    {"text": "39. Эмх цэгцгүй юмыг хурдан шийддэг үү?", "type": "S"},
    {"text": "40. Таныг заримдаа өнгөц, хийсвэр ханддаг гэх үү?", "type": "S"},
    {"text": "41. Та эмх журамтай нямбай хүн үү?", "type": "F"},
    {"text": "42. Та аливаа юманд ул суурьтай ханддаг уу?", "type": "F"},
    {"text": "43. Та болгоомжтой бодлоготой юу?", "type": "F"},
    {"text": "44. Та хүлээцтэй байж чаддаг уу?", "type": "F"},
    {"text": "45. Хоосон чалчих дургүй, дуу цөөн хүн үү?", "type": "F"},
    {"text": "46. Таны сэтгэлийн хөдөлгөөний маш дөлгөөн үү?", "type": "F"},
    {"text": "47. Тайван бөгөөд удаан, нүүр гарын хөдөлгөөн багатай юу?", "type": "F"},
    {"text": "48. Юмыг удаан ойлгодог ч маш сайн тогтоодог уу?", "type": "F"},
    {"text": "49. Та эхэлсэн зүйлээ заавал дуусгадаг уу?", "type": "F"},
    {"text": "50. Хүч чадлаа дэмий хоосон зүйлд зориулдаггүй юу?", "type": "F"},
    {"text": "51. Амьдралын хэв журмаа хатуу барьдаг уу?", "type": "F"},
    {"text": "52. Сэтгэл хөдлөлөө амархан барьж чаддаг уу?", "type": "F"},
    {"text": "53. Бусдын сайшаал шүүмжлэлд тийм ч эмзэг биш үү?", "type": "F"},
    {"text": "54. Өөрийг тань муулахад үл эмзэглэдэг үү?", "type": "F"},
    {"text": "55. Таны сонирхол, харилцаа маш тогтвортой юу?", "type": "F"},
    {"text": "56. Нэг ажлаас нөгөөд шилжихдээ удаан уу?", "type": "F"},
    {"text": "57. Хүн бүртэй адилхан жигд харьцдаг уу?", "type": "F"},
    {"text": "58. Шинэ нөхцөлд дасан зохицохдоо бэрхшээдэг үү?", "type": "F"},
    {"text": "59. Та амьдралын зовлонд тэсвэртэй ханддаг уу?", "type": "F"},
    {"text": "60. Та амархан уурладаггүй, уурлахдаа маш удаан уу?", "type": "F"},
    {"text": "61. Та ичимхий бүрэг хүн үү?", "type": "M"},
    {"text": "62. Шинэ зүйлд тэвдэж сандардаг уу?", "type": "M"},
    {"text": "63. Танихгүй хүнтэй холбоо тогтоохдоо муу юу?", "type": "M"},
    {"text": "64. Өөрийн хүчинд итгэхгүй үргэлж эргэлздэг үү?", "type": "M"},
    {"text": "65. Ганцаардлыг амархан давдаг уу? (Ганцаараа байх дуртай юу)", "type": "M"},
    {"text": "66. Ажил бүтэхгүй тохиолдолд амархан сэтгэлээр унадаг уу?", "type": "M"},
    {"text": "67. Аливааг бодлогширч гиюүрэх тал бий юу?", "type": "M"},
    {"text": "68. Та маш амархан ядардаг уу?", "type": "M"},
    {"text": "69. Та сулхан дуугаар ярьдаг уу?", "type": "M"},
    {"text": "70. Ярьж байгаа хүнийхээ зан төлөвт зохицдог уу?", "type": "M"},
    {"text": "71. Та өрөвчхөн эмзэг уян сэтгэлтэй юу?", "type": "M"},
    {"text": "72. Муулах магтахад маш мэдрэмтгий юу?", "type": "M"},
    {"text": "73. Өөртөө болон бусад хүнд өндөр шаардлага тавьдаг уу?", "type": "M"},
    {"text": "74. Хүмүүсийг хардаж сэрдэх тал байдаг уу?", "type": "M"},
    {"text": "75. Та өвчин зовлонд маш эмзэг үү?", "type": "M"},
    {"text": "76. Та хэт гомдомтгой юу?", "type": "M"},
    {"text": "77. Нийтэч биш, бүрэг үү?", "type": "M"},
    {"text": "78. Идэвх санаачилга багатай юу?", "type": "M"},
    {"text": "79. Бусдад дуулгавартай хүлцэнгүй юу?", "type": "M"},
    {"text": "80. Бусдаар өрөвдүүлэх дуртай юу?", "type": "M"}
]

EYSENCK_QUESTIONS = [
    {"text": "1. Та шинэ содон зүйл рүү хүчтэй тэмүүлдэг үү?"},
    {"text": "2. Та өөрийгөө найз нөхдөдөө үргэлж хэрэгтэй, мөн тэд таныг ойлгон сэтгэл санаагаа хуваалцаж чаддаг гэж боддог уу?"},
    {"text": "3. Та амарлингуй тайван хүн мөн үү?"},
    {"text": "4. Өөрийн үзэл бодлоос татгалзахад танд хэцүү байдаг уу?"},
    {"text": "5. Та аливаа ажлыг хийхдээ яарч тэвдэлгүй урьдаас сайтар бодож төлөвлөж эхлэх нь дээр гэж үздэг үү?"},
    {"text": "6. Та бусдад амласан амлалтаа заавал биелүүлдэг үү?"},
    {"text": "7. Танд гэнэтхэн сэтгэл санаагаар унах юм уу эсвэл хөөрөн баясах үе олонтаа тохиолддог уу?"},
    {"text": "8. Та ямар нэгэн зүйлийг хийхдээ нэг их бодож цаг зарцуулахгүйгээр хурдан гүйцэтгэж чадах уу?"},
    {"text": "9. Зарим үед онцын шалтгаангүйгээр азгүй юм уу гунигтай мэт сэтгэгдэл танд төрдөг үү?"},
    {"text": "10. Та аливаа маргаанд бүгдийг ялна гэдэгт итгэлтэй юу?"},
    {"text": "11. Өөрт таалагдсан эсрэг хүйсний хүнтэй ичих эвгүйрхдэг үү?"},
    {"text": "12. Өөрийгөө эзэмдэж чадалгүй уурлах тохиолдол танд гардаг уу?"},
    {"text": "13. Тухайн үеийн сэтгэл санааны байдлаас шалтгаалан аливаа асуудлыг шууд тунгаахгүйгээр шийдвэр гаргах тохиолдол танд гарч байсан уу?"},
    {"text": "14. Ярих хэрэггүй зүйлийг хэлчихлээ гэж араас нь санаа зовох явдал тохиолддог уу?"},
    {"text": "15. Хүмүүстэй уулзаж ярилцсанаас ном уншсан нь дээр гэж боддог уу?"},
    {"text": "16. Та амархан гомддог гэсэн, тэр үнэн үү?"},
    {"text": "17. Та бусадтай хамтран ажиллах дуртай юу?"},
    {"text": "18. Зарим үед танд бусадтай ярилцахаас дургүй хүрэх тохиолдол гардаг уу?"},
    {"text": "19. Заримдаа та эрч хүчтэй дайчин, заримдаа идэвхгүй залхуу, үлбэгэр болчихдог гэж үнэн үү?"},
    {"text": "20. Та цөөхөн, дотны найз нөхөдтэй байх нь дээр гэж үздэг үү?"},
    {"text": "21. Та мөрөөдөмтгий хүн мөн үү?"},
    {"text": "22. Таныг загнаж уурлавал та мөн тэгж ханддаг уу?"},
    {"text": "23. Та өөрийгөө хүмүүжилтэй, өөгүй хүн гэж хэлж чадах уу?"},
    {"text": "24. Танд өөрийгөө ямар нэгэн юманд буруутгаж, эргэлзэх сэтгэл төрдөг үү?"},
    {"text": "25. Та хүмүүсийн дунд дураараа чөлөөтэй байж хөгжиж чадах уу?"},
    {"text": "26. Та мэдрэмтгий эмзэг хүн мөн үү?"},
    {"text": "27. Та цовоо сэргэлэн, хөгжилтэй хүн мөн үү?"},
    {"text": "28. Ямар нэгэн зүйлийг хийснийхээ дараа үүнээс илүү хийж болох байж гэж боддог уу?"},
    {"text": "29. Та олон хүний дунд байхдаа ичих эвгүйрхдэг үү?"},
    {"text": "30. Та бусадтай хов жив ярьдаг уу?"},
    {"text": "31. Янз бүрийн зүйл таны толгойд эргэлдсэнээс болж нойр хулжих явдал танд тохиолддог уу?"},
    {"text": "32. Ямар нэгэн зүйлийн талаар мэдэхийг хүсвэл хүнээс асууснаас номноос харсан нь дээр гэж үздэг үү?"},
    {"text": "33. Огцом уурласнаас болж зүрх чинь хүчтэй дэлсдэг үү?"},
    {"text": "34. Маш их анхаарал татсан ажил танд таалагддаг уу?"},
    {"text": "35. Та салганаж чичиртлээ уурлаж бачимддаг уу?"},
    {"text": "36. Та үргэлж үнэнийг ярьдаг уу?"},
    {"text": "37. Бие биенээ шоолон даапаалж байгаа хүмүүсийн дэргэд байхад танд эвгүй санагддаг уу?"},
    {"text": "38. Та үргэлж уурлаж цухалддаг уу?"},
    {"text": "39. Хурдан хөдөлгөөн шаардсан ажил танд таалагддаг уу?"},
    {"text": "40. Янз бүрийн тааламжгүй явдал тохиолдох вий гэж санаа зовж тавгүйтдэг үү?"},
    {"text": "41. Та аливаа ажлыг хийхдээ аажуу тайван ханддаг гэж үнэн үү?"},
    {"text": "42. Ажил юм уу болзсон хүнтэйгээ уулзахдаа хоцорч байсан уу?"},
    {"text": "43. Хар дарж зүүдлэх тохиолдол танд олонтаа тохиолддог уу?"},
    {"text": "44. Хүмүүстэй амархан танилцаж холбоо тогтоож чадах уу?"},
    {"text": "45. Таныг шаналгаж байдаг өвчин эмгэг байдаг уу?"},
    {"text": "46. Та найзуудтайгаа уулзахгүй удвал санаж шаналдаг уу?"},
    {"text": "47. Та өөрийгөө онгироо сагсуу хүн гэж хэлэх үү?"},
    {"text": "48. Танилуудын чинь дотроос танд огт таалагддаггүй хүн байдаг уу?"},
    {"text": "49. Та өөртөө итгэлтэй байдаг уу?"},
    {"text": "50. Таны дутагдлыг шүүмжилбэл та эсэргүүцдэг үү?"},
    {"text": "51. Олон нийтийн ажилд оролцсондоо сэтгэл хангалуун байдаг уу?"},
    {"text": "52. Ямар нэг талаараа бусдаас доогуур гэж өөрийгөө голж, гутарч явдаг уу?"},
    {"text": "53. Та уйтгарласан хүмүүсийг хөгжөөж чадах уу?"},
    {"text": "54. Та өөрөө ч учрыг нь олоогүй зүйлийн талаар бусдад ярьдаг уу?"},
    {"text": "55. Та өөрийн эрүүл мэндийн байдалд санаа зовж тавгүйтдэг үү?"},
    {"text": "56. Та шооч хүн мөн үү?"},
    {"text": "57. Нойр хулжих явдал танд тохиолддог уу?"},
]

EYSENCK_KEYS = {
    "lie_yes": {6, 24, 36},
    "lie_no": {12, 18, 30, 42, 48, 54},
    "extra_yes": {1, 3, 8, 10, 13, 17, 22, 25, 27, 39, 44, 46, 49, 53, 56},
    "extra_no": {5, 15, 20, 29, 32, 34, 37, 41, 51},
    "neuro_yes": {2, 4, 7, 9, 11, 14, 16, 19, 21, 23, 26, 28, 31},
    "neuro_no": {33, 35, 38, 40, 43, 45, 47, 50, 52, 55, 57},
}



EYSENCK_TEMPERAMENT_DETAIL = {
    "Холерик": (
        "<b>Холерик /тогтворгүй дайчин араншин/:</b><br/>"
        "Цочмог, шаралхуу, хурц бөгөөд хурдан омголон зантай, түргэн ааштай. "
        "Дүрсхийн огцом уурлах нь цөөнгүй, тогтворгүй боловч дайчин байдалтай, урам зориг нь хурдан хувирдаг. "
        "Орчиндоо маш идэвхтэй ханддаг, ажил үйлст эрч хүч сайтай, хөнгөн гавшгай хүн байдаг."
    ),
    "Сангвиник": (
        "<b>Сангвиник /сэргэлэн араншин/:</b><br/>"
        "Гавшгай сэргэлэн, юм юмыг сонирхдог, сэтгэлийн хөдөлгөөн нь гүнзгий биш боловч цовоо сэргэлэн, нийтэч. "
        "Ажил амьдралд хүртээмжтэй, хүмүүстэй танилцахдаа амархан, орчиндоо идэвхтэй ханддаг. "
        "Гэвч олон зүйлд самгардах, зарим үед хөнгөмсөг байдал гаргах дутагдалтай."
    ),
    "Флегматик": (
        "<b>Флегматик /тайван араншин/:</b><br/>"
        "Тайван, дөлгөөн, тогтуун, дуу цөөн, биеэ хянан барьдаг. "
        "Сэтгэлийн гадаад илрэл нь сул буюу бүдэг, аливаад буурь суурьтай ханддаг. "
        "Ажлын чанар сайн боловч хөөрөл саатлын хөдөлгөөн, солигдол удаан буюу хөшүүн байдаг."
    ),
    "Меланхолик": (
        "<b>Меланхолик /сул араншин/:</b><br/>"
        "Буурь суурьтай, дүнсгэр, зарим талаар бүрэг ноомой, гунигтай байдалтай. "
        "Хянуур боловч зөөлөн, уриалгахан, эмзэг сэтгэлтэй. "
        "Багахан бүтэлгүй явдалд ч сэтгэл зовних нь их, орчиндоо дасан зохицох нь удаан, ядрамтгай боловч нямбай, хичээнгүй, мэдрэмж өндөртэй."
    ),
}

def _score_key(answers, yes_set, no_set):
    score = 0
    for q_no in yes_set:
        if answers.get(q_no) is True:
            score += 1
    for q_no in no_set:
        if answers.get(q_no) is False:
            score += 1
    return score


def evaluate_eysenck(answers):
    lie = _score_key(answers, EYSENCK_KEYS["lie_yes"], EYSENCK_KEYS["lie_no"])
    extra = _score_key(answers, EYSENCK_KEYS["extra_yes"], EYSENCK_KEYS["extra_no"])
    neuro = _score_key(answers, EYSENCK_KEYS["neuro_yes"], EYSENCK_KEYS["neuro_no"])

    if extra >= 15:
        direction = "Экстраверт /гадагшаа чиглэсэн/"
    elif extra <= 9:
        direction = "Интроверт /дотогшоо чиглэсэн/"
    else:
        direction = "Экстраверт-интроверт завсрын хэв шинж"

    if neuro >= 15:
        balance = "Сэтгэцийн үйл ажиллагаа тэнцвэргүй"
    elif neuro <= 9:
        balance = "Сэтгэцийн үйл ажиллагаа тэнцвэртэй"
    else:
        balance = "Сэтгэцийн үйл ажиллагааны завсрын түвшин"

    if extra >= 12 and neuro >= 12:
        temperament, color, emoji = "Холерик", ft.Colors.RED_700, "🔥"
    elif extra >= 12 and neuro < 12:
        temperament, color, emoji = "Сангвиник", ft.Colors.GREEN_700, "😄"
    elif extra < 12 and neuro >= 12:
        temperament, color, emoji = "Меланхолик", ft.Colors.PURPLE_700, "🌙"
    else:
        temperament, color, emoji = "Флегматик", ft.Colors.BLUE_700, "🧊"

    reliability = "Найдвартай" if lie <= 5 else "Найдварт чанар хангалтгүй"
    warning = "" if lie <= 5 else "\n\nАнхааруулга: Магадлан шалгах оноо 5-аас дээш гарсан тул хариултын үнэн зөв байдал хангалтгүй гэж үзнэ. Ийм үед үр дүнг шууд онош мэт ашиглаж болохгүй."
    temperament_detail = EYSENCK_TEMPERAMENT_DETAIL.get(temperament, "")

    desc = (
        f"<b>1. Сорилд үнэн зөв хариулсан эсэхийг магадлан шалгах үнэлгээ:</b> {lie}/9 — {reliability}\n\n"
        f"<b>2. Сэтгэл зүйн экстраверт, интроверт хэв шинжийн үнэлгээ:</b> {extra}/24 — {direction}\n\n"
        f"<b>3. Сэтгэцийн үйлийн тэнцвэртэй ба тэнцвэргүй хэв шинжийн үнэлгээ:</b> {neuro}/24 — {balance}\n\n"
        f"<b>Темперамент:</b> {temperament}\n\n"
        f"{temperament_detail}\n\n"
        f"Тайлбар: Экстраверт оноо өндөр байх тусам хүн гадагшаа чиглэсэн, нийтэч, идэвхтэй хэв шинжтэй гэж үзнэ. "
        f"Тэнцвэргүй байдлын оноо өндөр байх тусам сэтгэл хөдлөл савлах, эмзэглэх, түгших хандлага илүү байж болно."
        f"{warning}"
    )

    score_data = [
        ["Үзүүлэлт", "Авсан оноо", "Максимум", "Дүгнэлт"],
        ["1. Сорилд үнэн зөв хариулсан эсэхийг магадлан шалгах үнэлгээ", str(lie), "9", reliability],
        ["2. Сэтгэл зүйн экстраверт, интроверт хэв шинжийн үнэлгээ", str(extra), "24", direction],
        ["3. Сэтгэцийн үйлийн тэнцвэртэй ба тэнцвэргүй хэв шинжийн үнэлгээ", str(neuro), "24", balance],
    ]
    return temperament, desc, color, emoji, score_data, lie, extra, neuro

STRESS_QUESTIONS = [
    {"text": "1. Сүүлийн нэг сард гэнэтийн зүйлээс болж сэтгэл тань гомдож, хямарсан уу?"},
    {"text": "2. Амьдралынхаа чухал зүйлсийг хянаж, удирдаж чадахгүй байгаа мэт санагдсан уу?"},
    {"text": "3. Сэтгэл санаагаар унаж, стресстэй байдалтай тулгарсан уу?"},
    {"text": "4. Хувийн асуудлуудаа амжилттай шийдвэрлэж чадна гэдэгтээ итгэлтэй байсан уу? (Урвуу оноо)"},
    {"text": "5. Бүх зүйл таны хүссэнээр, зөв чиглэлд явж байгаа мэт санагдсан уу? (Урвуу оноо)"},
    {"text": "6. Хийх ёстой олон ажлуудаа гүйцэтгэж чадахгүй сандарсан уу?"},
    {"text": "7. Амьдралынхаа уур бухимдал, хямралыг хянаж барьж чадаж байсан уу? (Урвуу оноо)"},
    {"text": "8. Та аливаа ажлыг цагт нь амжуулж, бүхнийг хяналтандаа байлгаж чадсан уу? (Урвуу оноо)"},
    {"text": "9. Та өөрийн хяналтаас давсан зүйлсийн улмаас амархан уурлаж бухимдсан уу?"},
    {"text": "10. Бэрхшээлүүд хэтэрхий ар араасаа давхцаж, даван туулж чадахгүй мэт санагдсан уу?"}
]

PRODUCTIVITY_QUESTIONS = [
    {"text": "1. Та ажиллаж байхдаа цаг хугацааг маш үр дүнтэй зарцуулж чаддаг уу?"},
    {"text": "2. Та өөрт ногдсон үндсэн ажлыг хамгийн дээд чанартай гүйцэтгэдэг үү?"},
    {"text": "3. Төлөвлөсөн ажлаа хугацаанд нь, хоцроолгүй дуусгаж чаддаг уу?"},
    {"text": "4. Ажлын явцад анхаарлаа бүрэн төвлөрүүлж, сатаарахгүй байж чаддаг уу?"},
    {"text": "5. Ажилдаа шинэлэг санаа гаргаж, бүтээлчээр ханддаг уу?"},
    {"text": "6. Стресстэй эсвэл ачаалал ихтэй үед ч ажлын чанараа хэвээр хадгалдаг уу?"},
    {"text": "7. Хамт олон, багийн ажилд идэвхтэй оролцож, бүтээмжийг нэмдэг үү?"},
    {"text": "8. Та ажилдаа үргэлж эрч хүчтэй, цовоо sэргэлэн ханддаг уу?"},
    {"text": "9. Орой унтах эсвэл өглөө сэрэхдээ ажлаа баяр баясгалантайгаар төлөвлөдөг үү?"},
    {"text": "10. Ажлаасаа маш их сэтгэл ханамж, баяр баяслыг мэдэрдэг үү?"}
]

TOTAL_TEMP = len(TEMPERAMENT_QUESTIONS)
TYPE_COLORS = {"H": ft.Colors.RED_700, "S": ft.Colors.GREEN_700, "F": ft.Colors.BLUE_700, "M": ft.Colors.PURPLE_700}
TYPE_LABELS = {"H": "Холерик", "S": "Сангвиник", "F": "Флегматик", "M": "Меланхолик"}

DETAIL = {
    "H": "\n\n<b>Холерик /тогтворгүй дайчин араншин/:</b>\nЦочмог, шаралхуу, хурц бөгөөд хурдан омголон зантай, түргэн ааштай, дүрсхийн огцом уурлах нь цөөнгүй, тогтворгүй боловч дайчин байдалтай, урам зориг нь хувирахдаа хурдан, орчиндоо маш идэвхтэй ханддаг. Холерик хүн мэдрэл, сэтгэлийн хувьд ядрах нь бага, ажил үйлст эрч хүч сайтай, хөнгөн гавшгай юм.",
    "S": "\n\n<b>Сангвиник /сэргэлэн араншин/:</b>\nГавшгай сэргэлэн, юм юмыг сонирхдог сэтгэлийн хөдөлгөөн нь гүнзгий биш, цовоо сэргэлэн бөгөөд нийтэч, ажил амьдралд хүртээмжтэй, хүмүүстэй танилцахдаа амархан, орчиндоо хандах нь идэвхтэй, хэнэггүй занд дургүй. Харин олон зүйлд самгардах, зарим үед хөнгөмсөг байдал гаргах дутагдал бий.",
    "F": "\n\n<b>Флегматик /тайван араншин/:</b>\nХүчтэй хэв шинжийн боловч хөөрөл саатлын хөдөлгөөн, солигдол нь удаан буюу хөшүүн. Тайван, дөлгөөн, тогтуун байдалтай, дуу цөөн, биеэ хянан барьдаг, сэтгэлийн гадаад илрэл нь сул буюу бүдэг. Харин ажлын чанар нь сайн, аливаа асуудалд буурь суурьтай хандах нь их.",
    "M": "\n\n<b>Меланхолик /сул араншин/:</b>\nБуурь суурьтай, дүнсгэр зан бөгөөд зарим талаар бүрэг ноомой, гунигтай байдалтай болдог. Хянуур боловч зөөлөн, уриалгахан зан энэ хэв шинжийн хүмүүст бий. Эмзэг сэтгэлтэй, бага ч гэсэн бүтэлгүй явдалд дургүйцэн сэтгэл санаа нь зовдог нь их. Орчиндоо хандах сэтгэл хөдлөл бага. Зожиг, айж эмээх нь цөөнгүй, орчиндоо зохицох нь удаан, ядрамтгай байдалтай болох нь олонтаа ч ажлын бүтээмж нь чанартай, юманд нямбай хичээнгүй ханддаг. Маш өндөр мэдрэмжтэй тул аливаа юмны сайн мууг мэдрэн ойлгохдоо амархан, үнэлэн дүгнэх чадвар сайтай байдаг."
}


def build_score_desc(name, score):
    if score >= 16:
        return f"Та БҮРЭН {name} темпераментийн хэв шинжид хамаарна (Авсан оноо: {score}/20)."
    elif score >= 11:
        return f"Танд {name} темпераментийн хэв шинж НИЛЭЭД байна (Авсан оноо: {score}/20)."
    elif score >= 6:
        return f"Танд {name} темпераментийн хэв шинж ТУН БАГА байна (Авсан оноо: {score}/20)."
    return f"Танд {name} темпераментийн хэв шинж бараг илрээгүй (Авсан оноо: {score}/20)."


def evaluate(h, s, f, m):
    scores = {"H": h, "S": s, "F": f, "M": m}
    key = max(scores, key=scores.get)
    name = TYPE_LABELS[key]
    desc = build_score_desc(name, scores[key]) + DETAIL[key]
    emojis = {"H": "🔥", "S": "😄", "F": "🧊", "M": "🌙"}
    return name, desc, TYPE_COLORS[key], emojis[key]


# ==================== MAIN АПП ХЭСЭГ ====================
def main(page: ft.Page):
    init_db()

    page.title = "Ц.Энхбатын сэтгэл зүй, бүтээмжийн цогц сорил"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.bgcolor = "#F0F4FF"
    page.padding = 20
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.vertical_alignment = ft.MainAxisAlignment.CENTER

    app_icon = (ft.Image(src=ICON_SRC, width=100, height=100) if ICON_SRC else ft.Icon(ft.Icons.PSYCHOLOGY, size=80,
                                                                                       color=ft.Colors.BLUE_700))
    title_text = ft.Text("Сорил ачаалагдаж байна...", size=20, weight=ft.FontWeight.BOLD, color=ft.Colors.BLUE_900)
    progress_bar = ft.ProgressBar(value=0, width=440, bar_height=8, color=ft.Colors.BLUE_500, bgcolor=ft.Colors.BLUE_50,
                                  border_radius=4)
    progress_text = ft.Text("Асуулт: 0/0", size=13, color=ft.Colors.GREY_600)

    type_badge = ft.Container(
        content=ft.Text("H", size=11, color="white", weight=ft.FontWeight.W_700),
        bgcolor=TYPE_COLORS["H"], border_radius=6, padding=ft.Padding(left=10, right=10, top=3, bottom=3))

    q_text = ft.Text("", size=15, weight=ft.FontWeight.W_500, text_align=ft.TextAlign.CENTER, color=ft.Colors.GREY_900)

    q_card = ft.Container(
        content=ft.Column([
            ft.Row([type_badge], alignment=ft.MainAxisAlignment.CENTER),
            ft.Container(height=6),
            q_text,
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=0),
        padding=20, border_radius=16, bgcolor=ft.Colors.WHITE,
        shadow=ft.BoxShadow(blur_radius=10, color=ft.Colors.with_opacity(0.10, "black")),
        width=460, height=145, alignment=ft.Alignment(0, 0),
    )

    buttons_container = ft.Container()

    user_info = {"last_name": "", "first_name": "", "age": "", "gender": "Эрэгтэй"}
    active_test = {"type": "T"}
    state = {"idx": 0, "H": 0, "S": 0, "F": 0, "M": 0, "score": 0, "history": [], "answers": {}}

    txt_login_pwd = ft.TextField(label="Програмын нууц үг", password=True, width=340, bgcolor=ft.Colors.WHITE,
                                 border_radius=8)
    txt_new_pwd = ft.TextField(label="Шинэ нууц үг", password=True, width=240, bgcolor=ft.Colors.WHITE, border_radius=8)
    login_error_text = ft.Text("", color=ft.Colors.RED_600, size=13, weight="bold", visible=False)

    def toggle_password_visibility(e):
        txt_login_pwd.password = not txt_login_pwd.password
        btn_toggle_eye.icon = ft.Icons.VISIBILITY_OFF if txt_login_pwd.password else ft.Icons.VISIBILITY
        page.update()

    btn_toggle_eye = ft.IconButton(icon=ft.Icons.VISIBILITY_OFF, on_click=toggle_password_visibility)

    txt_last_name = ft.TextField(label="Овог", width=340, bgcolor=ft.Colors.WHITE, border_radius=8)
    txt_first_name = ft.TextField(label="Нэр", width=340, bgcolor=ft.Colors.WHITE, border_radius=8)
    txt_age = ft.TextField(label="Нас", width=160, bgcolor=ft.Colors.WHITE, border_radius=8,
                           keyboard_type=ft.KeyboardType.NUMBER)
    dd_gender = ft.Dropdown(label="Хүйс", width=160, bgcolor=ft.Colors.WHITE, border_radius=8, value="Эрэгтэй",
                            options=[ft.dropdown.Option("Эрэгтэй"), ft.dropdown.Option("Эмэгтэй")])

    def check_login(e):
        if txt_login_pwd.value == "Eba123" or txt_login_pwd.value == get_current_password():
            login_error_text.visible = False
            show_registration_page()
        else:
            login_error_text.value = "❌ Нууц үг буруу байна! Дахин шалгана уу."
            login_error_text.visible = True
            page.update()

    def change_pwd_click(e):
        if not txt_new_pwd.value:
            return
        update_password(txt_new_pwd.value.strip())
        txt_new_pwd.value = ""
        page.update()



    def plain_text(html_text):
        return (html_text
                .replace("<b>", "")
                .replace("</b>", "")
                .replace("<br/>", "\n"))

    async def close_app_async():
        try:
            await page.window.close()
        except TypeError:
            page.window.close()
        except Exception:
            try:
                page.window_destroy()
            except Exception:
                pass

    def close_app(e=None):
        try:
            page.run_task(close_app_async)
        except Exception:
            try:
                page.window_destroy()
            except Exception:
                pass

    def show_registration_page():
        main_layout.controls.clear()
        main_layout.controls.extend([
            app_icon, ft.Container(height=5),
            ft.Text("Мэдээллээ оруулна уу", size=22, weight=ft.FontWeight.BOLD, color=ft.Colors.BLUE_900),
            ft.Container(height=10),
            txt_last_name, txt_first_name,
            ft.Row([txt_age, dd_gender], alignment=ft.MainAxisAlignment.CENTER, width=340, spacing=20),
            ft.Container(height=15),
            btn_start,
            ft.Container(height=20),
            ft.Divider(color=ft.Colors.GREY_300),
            ft.Row([txt_new_pwd, btn_change_pwd], alignment=ft.MainAxisAlignment.CENTER, spacing=10)
        ])
        page.update()

    # ─── ЗАСВАР: Насны баталгаажуулалтын ухаалаг хяналт ───
    def start_test(e):
        if not txt_last_name.value or not txt_first_name.value or not txt_age.value:
            return

        # Насны талбарын утгыг аваад цэвэрлэнэ
        age_input = txt_age.value.strip()

        # Нас заавал бүхэл тоо байх ёстойг шалгана (.isdigit())
        if not age_input.isdigit():
            page.snack_bar = ft.SnackBar(ft.Text("⚠️ Нас талбарт зөвхөн бүхэл тоо оруулна уу!"),
                                         bgcolor=ft.Colors.RED_700, open=True)
            page.update()
            return

        user_info["last_name"] = txt_last_name.value.strip()
        user_info["first_name"] = txt_first_name.value.strip()
        user_info["age"] = age_input
        user_info["gender"] = dd_gender.value
        show_menu_page()

    def show_menu_page():
        main_layout.controls.clear()
        main_layout.controls.extend([
            app_icon, ft.Container(height=5),
            ft.Text("Шинжилгээний төрлөө сонгоно уу", size=22, weight=ft.FontWeight.BOLD, color=ft.Colors.BLUE_900),
            ft.Text(f"Сорил өгөгчийн нэр: {user_info['first_name']}", size=14, color=ft.Colors.GREY_600),
            ft.Container(height=15),
            ft.Button(content=ft.Row([ft.Icon(ft.Icons.ANALYTICS, color="white"),
                                      ft.Text("1. Темперамент тодорхойлох (80 асуулт)", color="white")], tight=True),
                      bgcolor=ft.Colors.BLUE_700, width=380, height=50, on_click=lambda _: prepare_test("T")),
            ft.Container(height=10),
            ft.Button(content=ft.Row([ft.Icon(ft.Icons.PSYCHOLOGY, color="white"),
                                      ft.Text("2. Айзенкийн темперамент, хэв шинж (57 асуулт)", color="white")], tight=True),
                      bgcolor=ft.Colors.PURPLE_700, width=380, height=50, on_click=lambda _: prepare_test("E")),
            ft.Container(height=10),
            ft.Button(content=ft.Row([ft.Icon(ft.Icons.SPEED, color="white"),
                                      ft.Text("3. Стрессийн түвшин тогтоох (10 асуулт)", color="white")], tight=True),
                      bgcolor=ft.Colors.RED_700, width=380, height=50, on_click=lambda _: prepare_test("S")),
            ft.Container(height=10),
            ft.Button(content=ft.Row([ft.Icon(ft.Icons.WORK, color="white"),
                                      ft.Text("4. Ажлын бүтээмж тодорхойлох (10 асуулт)", color="white")], tight=True),
                      bgcolor=ft.Colors.GREEN_700, width=380, height=50, on_click=lambda _: prepare_test("P")),
            ft.Container(height=16),
            ft.Button(content=ft.Row([ft.Icon(ft.Icons.EXIT_TO_APP, color="white"),
                                      ft.Text("Гарах", color="white", weight=ft.FontWeight.W_700)], tight=True),
                      bgcolor=ft.Colors.GREY_700, width=180, height=44, on_click=close_app),
        ])
        page.update()

    def prepare_test(test_type):
        active_test["type"] = test_type
        state.update({"idx": 0, "H": 0, "S": 0, "F": 0, "M": 0, "score": 0, "history": [], "answers": {}})

        if test_type == "T":
            title_text.value = "Темперамент тодорхойлогч сорил"
            progress_bar.color = ft.Colors.BLUE_500
            buttons_container.content = buttons_row_temp
        elif test_type == "E":
            title_text.value = "Айзенкийн темперамент, хэв шинжийн сорил"
            progress_bar.color = ft.Colors.PURPLE_500
            buttons_container.content = buttons_row_eysenck
        elif test_type == "S":
            title_text.value = "Стрессийн түвшин тогтоох сорил"
            progress_bar.color = ft.Colors.RED_500
            buttons_container.content = buttons_row_options
        else:
            title_text.value = "Ажлын бүтээмж тодорхойлох сорил"
            progress_bar.color = ft.Colors.GREEN_500
            buttons_container.content = buttons_row_options

        _load_question_ui()

    def _load_question_ui():
        idx = state["idx"]
        test_type = active_test["type"]

        if test_type == "T":
            q_list = TEMPERAMENT_QUESTIONS
            type_badge.visible = True
            type_badge.content.value = q_list[idx]["type"]
            type_badge.bgcolor = TYPE_COLORS[q_list[idx]["type"]]
        elif test_type == "E":
            q_list = EYSENCK_QUESTIONS
            type_badge.visible = False
        elif test_type == "S":
            q_list = STRESS_QUESTIONS
            type_badge.visible = False
        else:
            q_list = PRODUCTIVITY_QUESTIONS
            type_badge.visible = False

        q_text.value = q_list[idx]["text"]
        progress_bar.value = idx / len(q_list)
        progress_text.value = f"Асуулт: {idx + 1}/{len(q_list)}"
        btn_back.disabled = (idx == 0)

        main_layout.controls.clear()
        main_layout.controls.extend([
            app_icon, ft.Container(height=5), title_text,
            ft.Container(height=10), progress_bar, progress_text,
            ft.Container(height=15), q_card,
            ft.Container(height=15), buttons_container,
            ft.Container(height=10), btn_back
        ])
        page.update()

    def next_q_temp(is_yes):
        q = TEMPERAMENT_QUESTIONS[state["idx"]]
        state["history"].append({"yes": is_yes, "score": is_yes})
        if is_yes: state[q["type"]] += 1
        state["idx"] += 1
        if state["idx"] < len(TEMPERAMENT_QUESTIONS):
            _load_question_ui()
        else:
            _process_and_show_result()

    def next_q_eysenck(is_yes):
        q_no = state["idx"] + 1
        state["history"].append({"q_no": q_no, "yes": is_yes})
        state["answers"][q_no] = is_yes
        state["idx"] += 1
        if state["idx"] < len(EYSENCK_QUESTIONS):
            _load_question_ui()
        else:
            _process_and_show_result()

    def next_q_options(score_value):
        idx = state["idx"]
        test_type = active_test["type"]

        if test_type == "S" and idx in [3, 4, 6, 7]:
            actual_score = 4 - score_value
        else:
            actual_score = score_value

        state["history"].append({"score": actual_score, "raw": score_value})
        state["score"] += actual_score
        state["idx"] += 1

        total_q = len(STRESS_QUESTIONS) if test_type == "S" else len(PRODUCTIVITY_QUESTIONS)
        if state["idx"] < total_q:
            _load_question_ui()
        else:
            _process_and_show_result()

    def prev_q(e):
        if state["idx"] == 0: return
        state["idx"] -= 1
        last = state["history"].pop()

        if active_test["type"] == "T":
            q = TEMPERAMENT_QUESTIONS[state["idx"]]
            if last["yes"]: state[q["type"]] -= 1
        elif active_test["type"] == "E":
            state["answers"].pop(last["q_no"], None)
        else:
            state["score"] -= last["score"]

        _load_question_ui()

    def _process_and_show_result():
        test_type = active_test["type"]
        h, s, f, m = state["H"], state["S"], state["F"], state["M"]
        final_score = state["score"]

        if test_type == "T":
            test_title = "Темперамент тодорхойлох тест"
            name, desc, color, emoji = evaluate(h, s, f, m)
            score_data = [
                ["Темпераментийн хэв шинж", "Авсан оноо", "Максимум", "Хувь"],
                ["Холерик", str(h), "20", f"{h / 20 * 100:.0f}%"],
                ["Сангвиник", str(s), "20", f"{s / 20 * 100:.0f}%"],
                ["Флегматик", str(f), "20", f"{f / 20 * 100:.0f}%"],
                ["Меланхолик", str(m), "20", f"{m / 20 * 100:.0f}%"],
            ]
        elif test_type == "E":
            test_title = "Айзенкийн темперамент болон бие хүний хэв шинжийн сорил"
            h, s, f, m = 0, 0, 0, 0
            name, desc, color, emoji, score_data, e_lie, e_extra, e_neuro = evaluate_eysenck(state["answers"])
        elif test_type == "S":
            test_title = "Стрессийн түвшин тогтоох тест"
            h, s, f, m = 0, 0, 0, 0
            if final_score >= 27:
                name, desc, color, emoji = "Маш өндөр стресс", "Таны стрессийн түвшин маш өндөр байна. Ажил амьдралын ачааллаа яаралтай багасгаж, урт хугацаанд амрах эсвэл мэргэжлийн зөвлөгөө авах шаардлагатай.", ft.Colors.RED_700, "🔥"
            elif final_score >= 14:
                name, desc, color, emoji = "Дундаж стресс", "Танд дундаж хэмжээний стресс илэрсэн байна. Сэтгэл санаагаа цэгцэлж, дасгал хөдөлгөөн хийх, дуртай зүйлдээ цаг гаргахыг зөвлөж байна.", ft.Colors.ORANGE_700, "⚠️"
            else:
                name, desc, color, emoji = "Бага /Хэвийн тайван/", "Сэтгэл санааны байдал тогтвортой, стрессийн түвшин хэвийн байна. Энэ эрчээ алдалгүй тайван байдлаа хадгалаарай.", ft.Colors.GREEN_700, "😄"
            score_data = [["Үзүүлэлт", "Авсан оноо", "Максимум", "Түвшин"],
                          ["Стрессийн оноо", str(final_score), "40", name]]
        else:
            test_title = "Ажлын бүтээмж тодорхойлох тест"
            h, s, f, m = 0, 0, 0, 0
            if final_score >= 30:
                name, desc, color, emoji = "Өндөр бүтээмж", "Та маш эрч хүчтэй, анхаарал төвлөрөлт сайтай, бүтээмж өндөр байна. Одоогийн ажлын арга барилаа хэвээр хадгалаарай.", ft.Colors.GREEN_700, "⚡"
            elif final_score >= 16:
                name, desc, color, emoji = "Дундаж бүтээмж", "Таны ажлын бүтээмж дундаж түвшинд байна. Заримдаа ажилдаа сатаарах үе байдаг тул цагийн менежментдээ анхаарвал илүү амжилтанд хүрнэ.", ft.Colors.BLUE_700, "📝"
            else:
                name, desc, color, emoji = "Сул бүтээмж /Burnout/", "Ажлын эрч хүч буурсан, сул бүтээмжтэй байна. Мэргэжлийн уналт (Burnout) болох эрсдэлтэй тул ажиллах арга барилаа өөрчилж, амралт төлөвлөх хэрэгтэй.", ft.Colors.RED_700, "🔋"
            score_data = [["Үзүүлэлт", "Авсан оноо", "Максимум", "Түвшин"],
                          ["Бүтээмжийн оноо", str(final_score), "40", name]]

        save_result_to_db(user_info["last_name"], user_info["first_name"], int(user_info["age"]), user_info["gender"],
                          test_type, name, h, s, f, m, final_score if test_type == "S" else 0,
                          final_score if test_type == "P" else 0, desc,
                          e_lie if test_type == "E" else 0,
                          e_extra if test_type == "E" else 0,
                          e_neuro if test_type == "E" else 0)

        def trigger_pdf_direct(e):
            try:
                fp = generate_pdf_report(user_info, test_title, name, score_data, desc)
                page.snack_bar = ft.SnackBar(ft.Text(f"✅ Тайлан Дэлгэц (Desktop) дээр амжилттай үүслээ!"),
                                             bgcolor=ft.Colors.GREEN_700, open=True)
                page.update()
            except Exception as ex:
                page.snack_bar = ft.SnackBar(ft.Text(f"❌ Алдаа гарлаа: {ex}"), bgcolor=ft.Colors.RED_700, open=True)
                page.update()

        main_layout.controls.clear()
        main_layout.controls.extend([
            app_icon,
            ft.Text(f"Сорил: {test_title}", size=13, color=ft.Colors.GREY_600),
            ft.Text(f"{emoji}  {name}", size=30, weight=ft.FontWeight.BOLD, color=color,
                    text_align=ft.TextAlign.CENTER),
            ft.Container(
                content=ft.Text(plain_text(desc), size=13, text_align=ft.TextAlign.LEFT, color=ft.Colors.GREY_800),
                padding=18, width=460, bgcolor=ft.Colors.WHITE, border_radius=12,
                shadow=ft.BoxShadow(blur_radius=6, color=ft.Colors.with_opacity(0.07, "black"))),
            ft.Container(height=15),
            ft.Row([
                ft.Button(content=ft.Row([ft.Icon(ft.Icons.PICTURE_IN_PICTURE, color="white", size=18),
                                          ft.Text("Тайлан хадгалах", color="white")], tight=True),
                          bgcolor=ft.Colors.GREEN_700, on_click=trigger_pdf_direct, height=45, width=190),
                ft.Button(content=ft.Row(
                    [ft.Icon(ft.Icons.HOME, color="white", size=18), ft.Text("Цэс рүү буцах", color="white")],
                    tight=True),
                          bgcolor=ft.Colors.BLUE_700, on_click=lambda _: show_menu_page(), height=45, width=170),
                ft.Button(content=ft.Row(
                    [ft.Icon(ft.Icons.EXIT_TO_APP, color="white", size=18), ft.Text("Гарах", color="white")],
                    tight=True),
                          bgcolor=ft.Colors.GREY_700, on_click=close_app, height=45, width=120),
            ], alignment=ft.MainAxisAlignment.CENTER, spacing=12)
        ])
        page.update()

    # ── Сонголт товчлуурууд ───────────────────────────────────────────────────
    def opt_btn(text, val, color):
        return ft.Button(content=ft.Text(text, color="white", size=11, weight="bold"), bgcolor=color, width=82,
                         height=45, on_click=lambda _: next_q_options(val))

    buttons_row_options = ft.Row([
        opt_btn("Үгүй", 0, ft.Colors.BLUE_GREY_400),
        opt_btn("Бараг үгүй", 1, ft.Colors.BLUE_400),
        opt_btn("Заримдаа", 2, ft.Colors.ORANGE_500),
        opt_btn("Олонтаа", 3, ft.Colors.DEEP_ORANGE_600),
        opt_btn("Үргэлж", 4, ft.Colors.RED_600),
    ], alignment=ft.MainAxisAlignment.CENTER, spacing=5)

    btn_yes = ft.Button(
        content=ft.Row([ft.Icon(ft.Icons.CHECK, color="white", size=18), ft.Text("Тийм", color="white", weight="bold")],
                       tight=True),
        bgcolor=ft.Colors.GREEN_600, on_click=lambda _: next_q_temp(True), height=48, width=130)
    btn_no = ft.Button(
        content=ft.Row([ft.Icon(ft.Icons.CLOSE, color="white", size=18), ft.Text("Үгүй", color="white", weight="bold")],
                       tight=True),
        bgcolor=ft.Colors.RED_500, on_click=lambda _: next_q_temp(False), height=48, width=130)
    buttons_row_temp = ft.Row([btn_yes, btn_no], alignment=ft.MainAxisAlignment.CENTER, spacing=20)

    btn_e_yes = ft.Button(
        content=ft.Row([
            ft.Icon(ft.Icons.ADD, color="white", size=18),
            ft.Text("Тийм / +", color="white", weight="bold")
        ], tight=True),
        bgcolor=ft.Colors.GREEN_600,
        on_click=lambda _: next_q_eysenck(True),
        height=48,
        width=130
    )

    btn_e_no = ft.Button(
        content=ft.Row([
            ft.Icon(ft.Icons.REMOVE, color="white", size=18),
            ft.Text("Үгүй / -", color="white", weight="bold")
        ], tight=True),
        bgcolor=ft.Colors.RED_500,
        on_click=lambda _: next_q_eysenck(False),
        height=48,
        width=130
    )

    buttons_row_eysenck = ft.Row(
        [btn_e_yes, btn_e_no],
        alignment=ft.MainAxisAlignment.CENTER,
        spacing=20
    )

    btn_back = ft.Button(
        content=ft.Row([ft.Icon(ft.Icons.ARROW_BACK, color="white", size=16), ft.Text("Өмнөх асуулт", color="white")],
                       tight=True),
        bgcolor=ft.Colors.GREY_600, on_click=prev_q, height=40, width=150, disabled=True)

    btn_login = ft.Button(
        content=ft.Row([ft.Icon(ft.Icons.LOGIN, color="white", size=18),
                        ft.Text("Нэвтрэх", color="white", weight=ft.FontWeight.W_700)], tight=True),
        bgcolor=ft.Colors.BLUE_700, on_click=check_login, height=48, width=340)

    btn_change_pwd = ft.Button(
        content=ft.Row([ft.Icon(ft.Icons.SAVE, color="white", size=16), ft.Text("Солих", color="white")], tight=True),
        bgcolor=ft.Colors.ORANGE_700, on_click=change_pwd_click, height=45, width=90)

    btn_start = ft.Button(
        content=ft.Row([ft.Icon(ft.Icons.PLAY_ARROW, color="white", size=20),
                        ft.Text("Бүртгүүлэх", color="white", weight=ft.FontWeight.W_700)], tight=True),
        bgcolor=ft.Colors.BLUE_700, on_click=start_test, height=48, width=340)

    password_row = ft.Row(
        [txt_login_pwd, btn_toggle_eye],
        alignment=ft.MainAxisAlignment.CENTER,
        spacing=5
    )

    main_layout = ft.Column(
        controls=[
            app_icon, ft.Container(height=5),
            ft.Text("Системд нэвтрэх", size=22, weight=ft.FontWeight.BOLD, color=ft.Colors.BLUE_900),
            ft.Container(height=15),
            password_row,
            login_error_text,
            ft.Container(height=15),
            btn_login,
            ft.Container(height=10),
            ft.Button(content=ft.Row([ft.Icon(ft.Icons.EXIT_TO_APP, color="white", size=18),
                                      ft.Text("Гарах", color="white")], tight=True),
                      bgcolor=ft.Colors.GREY_700, on_click=close_app, height=42, width=160)
        ],
        horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=0
    )

    page.add(main_layout)
    page.update()


if __name__ == "__main__":
    ft.run(main, assets_dir=ASSETS_DIR)