"""
Ц.Энхбатын ухаалаг дуу хураагуур — PC болон Android хувилбар (Flet 0.85)
ЗАСВАРЛАСАН: Android дээр бичлэг хадгалагдахгүй байсан асуудлыг зассан
"""
import flet as ft
import flet_audio_recorder as ftar
import flet_audio as fta
import time
import datetime
import os
import sys
import threading
import subprocess
import shutil
import asyncio
import tempfile

# Android систем дээр tkinter-ийг импортлохоос бүрэн сэргийлнэ (гацах болон хар дэлгэц гарахаас сэргийлнэ)
IS_ANDROID_PLATFORM = (
    hasattr(sys, "getandroidapilevel")
    or os.path.exists("/system/bin/app_process")
    or "ANDROID_ARGUMENT" in os.environ
)

HAS_TKINTER = False
if not IS_ANDROID_PLATFORM:
    try:
        from tkinter import filedialog, Tk
        HAS_TKINTER = True
    except ImportError:
        pass

if getattr(sys, "frozen", False):
    BUNDLE_DIR = sys._MEIPASS
    EXE_DIR    = os.path.dirname(sys.executable)
else:
    BUNDLE_DIR = os.path.dirname(os.path.abspath(__file__))
    EXE_DIR    = BUNDLE_DIR

ASSETS_DIR = os.path.join(BUNDLE_DIR, "assets")
OUTPUT_DIR = os.path.join(EXE_DIR, "Бичлэгүүд")
os.makedirs(ASSETS_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

IMG_SRC = None
for img in ("audio.png", "icon.png", "icon1.png"):
    if os.path.exists(os.path.join(ASSETS_DIR, img)):
        IMG_SRC = img
        break

FFMPEG = shutil.which("ffmpeg") or r"C:\ffmpeg\bin\ffmpeg.exe"
HAS_FFMPEG = shutil.which("ffmpeg") is not None or os.path.isfile(r"C:\ffmpeg\bin\ffmpeg.exe")


def open_file(path: str):
    try:
        if sys.platform == "win32":
            os.startfile(path)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        elif sys.platform == "linux" and not os.path.exists("/system/bin/app_process"):
            subprocess.Popen(["xdg-open", path])
        else:
            print("Direct shell open not supported on this platform.")
    except Exception as ex:
        print(f"Нээж чадсангүй: {ex}")


def wav_to_mp3(wav_path: str, mp3_path: str) -> bool:
    try:
        cmd = ["ffmpeg", "-y", "-i", wav_path, "-q:a", "2", mp3_path]
        r = subprocess.run(cmd, capture_output=True, timeout=120)
        return r.returncode == 0 and os.path.exists(mp3_path)
    except Exception:
        return False


def format_time(sec: float) -> str:
    h = int(sec // 3600)
    m = int((sec % 3600) // 60)
    s = int(sec % 60)
    return f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def format_size(path: str) -> str:
    try:
        b = os.path.getsize(path)
        if b < 1024:     return f"{b} B"
        if b < 1024**2:  return f"{b/1024:.1f} KB"
        return f"{b/1024**2:.2f} MB"
    except Exception:
        return "—"


def make_btn(label, icon, color, on_click=None, width=165):
    return ft.Button(
        content=ft.Row(
            [ft.Icon(icon, color="white", size=18),
             ft.Text(label, color="white", size=13, weight=ft.FontWeight.W_600)],
            tight=True, spacing=6),
        bgcolor=color, on_click=on_click,
        height=48, width=width,
        style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=12)),
    )


# ── ЗАСВАР: Android аюулгүй файл хуулах функц ─────────────────────────────
def safe_copy_file(src: str, dst: str) -> bool:
    """
    shutil.move()-ийн оронд chunk-аар хуулна.
    Android Scoped Storage-д cross-filesystem move алддаг тул
    эхлээд хуулж, дараа нь эх файлыг устгана.
    """
    try:
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        with open(src, "rb") as fsrc, open(dst, "wb") as fdst:
            shutil.copyfileobj(fsrc, fdst, length=1024 * 256)  # 256KB chunk
        # Хуулсан файл хоосон биш эсэхийг шалгана
        if os.path.exists(dst) and os.path.getsize(dst) > 0:
            try:
                os.remove(src)
            except Exception:
                pass
            return True
        else:
            return False
    except Exception as ex:
        print(f"safe_copy_file алдаа: {ex}")
        return False


def get_android_output_dir() -> str:
    """
    Android дээр бичих боломжтой хамгийн тохиромжтой хавтсыг тодорхойлно.
    """
    candidates = [
        "/storage/emulated/0/Android/media/com.enkhbat.audiorecorder/Бичлэгүүд",
    ]
    env_data = os.getenv("FLET_APP_STORAGE_DATA")
    if env_data:
        candidates.append(os.path.join(env_data, "Бичлэгүүд"))
    candidates.append(os.path.join(tempfile.gettempdir(), "Бичлэгүүд"))

    for path in candidates:
        try:
            os.makedirs(path, exist_ok=True)
            test = os.path.join(path, ".write_test")
            with open(test, "w") as f:
                f.write("ok")
            os.remove(test)
            return path
        except Exception:
            continue
    return tempfile.gettempdir()


AUDIO_EXTS = (".wav", ".m4a", ".aac", ".mp4", ".ogg", ".flac")

def find_latest_wav_android(hint_path: str | None, after_ts: float) -> str | None:
    """
    Android дээр recorder файлыг хаана хадгалсныг бүх боломжит замаас хайна.
    Дэд хавтсуудыг мөн рекурсив байдлаар хайна (os.walk).
    hint_path  — start_recording()-д өгсөн зам
    after_ts   — бичлэг эхэлсэн Unix timestamp
    """
    # 1. Өгсөн hint замыг шалгана
    if hint_path and os.path.exists(hint_path) and os.path.getsize(hint_path) > 0:
        return hint_path

    # 2. Бүх боломжит root хавтаснуудыг цуглуулна
    env_data = os.getenv("FLET_APP_STORAGE_DATA") or ""
    env_temp = os.getenv("FLET_APP_STORAGE_TEMP") or ""
    pkg      = "com.enkhbat.audiorecorder"
    search_roots = [
        f"/data/user/0/{pkg}/cache",
        f"/data/user/0/{pkg}/app_flutter",
        f"/data/user/0/{pkg}/files",
        tempfile.gettempdir(),
        env_data,
        env_temp,
        f"/storage/emulated/0/Android/media/{pkg}",
        "/storage/emulated/0/Music",
        "/storage/emulated/0/Downloads",
        "/storage/emulated/0/Recordings",
    ]

    best       = None
    best_mtime = 0.0

    # Сүүлийн 15 минутын дотор үүссэн файлыг хайна (timezone/clock drift-ээс сэргийлнэ)
    now = time.time()
    for root in search_roots:
        if not root or not os.path.isdir(root):
            continue
        try:
            # os.walk — дэд хавтсуудыг бүгдийг хайна
            for dirpath, _, filenames in os.walk(root):
                for fn in filenames:
                    if not any(fn.lower().endswith(ext) for ext in AUDIO_EXTS):
                        continue
                    fp = os.path.join(dirpath, fn)
                    try:
                        mt = os.path.getmtime(fp)
                        sz = os.path.getsize(fp)
                        if sz > 0 and (now - 900 <= mt <= now + 900) and mt > best_mtime:
                            best       = fp
                            best_mtime = mt
                    except Exception:
                        continue
        except Exception:
            continue
    return best


def clean_path(path_str: str | None) -> str | None:
    if not path_str or not isinstance(path_str, str):
        return path_str
    import urllib.parse
    unquoted = urllib.parse.unquote(path_str)
    if unquoted.startswith("file://"):
        unquoted = unquoted[7:]
    elif unquoted.startswith("file:"):
        unquoted = unquoted[5:]
    
    if os.name == "nt" and unquoted.startswith("/") and len(unquoted) > 2 and unquoted[2] == ":":
        unquoted = unquoted[1:]
    return os.path.normpath(unquoted)


def main(page: ft.Page):
    page.title         = "Ц.Энхбатын ухаалаг дуу хураагуур 🎙️"
    page.window_width  = 680
    page.window_height = 840
    page.window_resizable = True
    page.theme_mode    = ft.ThemeMode.LIGHT
    page.padding       = 20
    page.bgcolor       = "#F3F4F6"

    # ── Багажууд ──────────────────────────────────────────────────────────
    recorder     = ftar.AudioRecorder()
    audio_player = fta.Audio(autoplay=False)
    page.services.append(recorder)
    page.services.append(audio_player)

    error_snack = ft.SnackBar(content=ft.Text(""), bgcolor=ft.Colors.RED_500)
    page.overlay.append(error_snack)

    # ── Платформ тодорхойлох ───────────────────────────────────────────────
    is_android = (
        page.platform == ft.PagePlatform.ANDROID
        or str(page.platform).lower() in ["android", "pageplatform.android"]
        or hasattr(sys, "getandroidapilevel")
        or os.path.exists("/system/bin/app_process")
    )
    is_ios = (
        page.platform == ft.PagePlatform.IOS
        or str(page.platform).lower() in ["ios", "pageplatform.ios"]
    )

    # ── Хадгалах хавтас тодорхойлох ──────────────────────────────────────
    if is_android:
        initial_output_dir = get_android_output_dir()
    elif is_ios:
        app_storage = os.getenv("FLET_APP_STORAGE_DATA") or os.getenv("FLET_APP_STORAGE_TEMP") or tempfile.gettempdir()
        initial_output_dir = os.path.normpath(os.path.join(app_storage, "Бичлэгүүд"))
        os.makedirs(initial_output_dir, exist_ok=True)
    else:
        initial_output_dir = OUTPUT_DIR

    # ── Төлөв ─────────────────────────────────────────────────────────────
    state = {
        "recording":   False,
        "paused":      False,
        "wav_path":    None,   # recorder руу өгсөн түр зам (temp dir дотор)
        "start_time":  None,
        "pause_accum": 0.0,
        "pause_start": None,
        "display_sec": 0.0,
        "output_dir":  initial_output_dir,
    }
    device_map = {}

    def show_err(msg):
        error_snack.content = ft.Text(msg)
        error_snack.open    = True
        status_text.value   = msg
        status_text.color   = ft.Colors.RED_600
        page.update()

    # ── UI элементүүд ──────────────────────────────────────────────────────
    mic_dropdown = ft.Dropdown(
        label="Микрофон сонгох",
        options=[ft.dropdown.Option(key="default", text="🎙️  Default (системийн микрофон)")],
        value="default", width=600, bgcolor="white", border_radius=8,
    )

    fmt_options = [ft.dropdown.Option(key="wav", text="🎵  WAV — Өндөр чанар")]
    if HAS_FFMPEG:
        fmt_options.append(ft.dropdown.Option(key="mp3", text="🎧  MP3 — Шахсан формат"))
    else:
        fmt_options.append(ft.dropdown.Option(key="mp3", text="🎧  MP3 — Шахсан формат (WAV-аар хадгалагдана)"))

    format_dropdown = ft.Dropdown(
        label="Хадгалах формат", options=fmt_options, value="wav",
        width=340, bgcolor="white", border_radius=8,
    )

    timer_text  = ft.Text("00:00", size=48, weight=ft.FontWeight.BOLD, color=ft.Colors.GREY_700)
    status_text = ft.Text("🎙️  Микрофон сонгоод эхлэнэ үү.", color=ft.Colors.GREY_600, size=13)
    dir_text    = ft.Text(f"📁 Хадгалах газар: {state['output_dir']}", size=11, color=ft.Colors.GREY_500, italic=True)
    history_list = ft.ListView(expand=True, spacing=6, padding=8)

    # ── Хавтас сонгох ─────────────────────────────────────────────────────
    def choose_folder(e):
        if not HAS_TKINTER:
            show_err("Гар утсан дээр хавтас сонгох боломжгүй. Апп-ын хувийн хавтаст хадгалагдана.")
            return
        try:
            root = Tk()
            root.withdraw()
            root.attributes('-topmost', True)
            selected_path = filedialog.askdirectory(initialdir=state["output_dir"])
            root.destroy()
            if selected_path:
                state["output_dir"] = os.path.normpath(selected_path)
                dir_text.value = f"📁 Хадгалах газар: {state['output_dir']}"
                load_history()
                status_text.value = "📁 Хадгалах хавтас амжилттай солигдлоо."
                status_text.color = ft.Colors.GREEN_700
                page.update()
        except Exception as ex:
            show_err(f"Хавтас сонгоход алдаа: {ex}")

    def open_folder_clicked(e):
        if is_android or is_ios:
            show_err("Гар утсан дээр хавтсыг шууд нээх боломжгүй.")
        else:
            open_file(state["output_dir"])

    # ── Тоолуур ───────────────────────────────────────────────────────────
    async def _timer_task():
        while state["recording"]:
            if not state["paused"]:
                elapsed = (time.time() - state["start_time"]) - state["pause_accum"]
                state["display_sec"] = elapsed
                timer_text.value = format_time(elapsed)
                timer_text.color = ft.Colors.RED_600
                page.update()
            await asyncio.sleep(0.2)

    # ── Аудио тоглуулах ────────────────────────────────────────────────────
    def play_audio(fp):
        if is_android or is_ios:
            audio_player.src = fp
            audio_player.update()
            audio_player.play()
            status_text.value = "🔊 Тоглож байна..."
            status_text.color = ft.Colors.GREEN_700
            page.update()
        else:
            open_file(fp)

    # ── Хадгалагдсан файлуудын жагсаалт ───────────────────────────────────
    def load_history():
        history_list.controls.clear()
        target_dir = state["output_dir"]
        try:
            files = sorted(
                [f for f in os.listdir(target_dir) if f.lower().endswith(AUDIO_EXTS + (".mp3",))],
                reverse=True)
        except Exception:
            files = []

        if not files:
            history_list.controls.append(
                ft.Container(
                    content=ft.Text("Энэ хавтсанд бичлэг алга байна...", color=ft.Colors.GREY_400, italic=True),
                    alignment=ft.Alignment(0, 0), padding=24))
        else:
            for f in files:
                fpath = os.path.join(target_dir, f)
                try:
                    st     = os.stat(fpath)
                    dt_str = datetime.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d  %H:%M:%S")
                    sz     = format_size(fpath)
                    ext    = f.rsplit(".", 1)[-1].upper()
                    
                    if ext == "WAV":
                        badge_color = ft.Colors.BLUE_700
                        icon_char = "🎵"
                    elif ext == "MP3":
                        badge_color = ft.Colors.GREEN_700
                        icon_char = "🎧"
                    else:
                        badge_color = ft.Colors.ORANGE_700
                        icon_char = "🔊"

                    def _make_del(fp):
                        def _del(e):
                            try:
                                if os.path.exists(fp):
                                    os.remove(fp)
                            except Exception:
                                pass
                            load_history()
                        return _del

                    tile = ft.Container(
                        content=ft.Row([
                            ft.Text(icon_char, size=26),
                            ft.Column([
                                ft.Text(f, size=12, weight=ft.FontWeight.W_600, overflow=ft.TextOverflow.ELLIPSIS),
                                ft.Row([
                                    ft.Container(
                                        content=ft.Text(ext, size=10, color="white", weight=ft.FontWeight.W_700),
                                        bgcolor=badge_color, border_radius=4, padding=ft.Padding(7, 2, 7, 2)),
                                    ft.Text(f"📅 {dt_str}", size=11, color=ft.Colors.GREY_600),
                                    ft.Text(f"💾 {sz}", size=11, color=ft.Colors.GREY_600),
                                ], spacing=8),
                            ], expand=True, spacing=3),
                            ft.Row([
                                ft.IconButton(icon=ft.Icons.PLAY_CIRCLE_OUTLINE, icon_color=ft.Colors.BLUE_600, icon_size=24, on_click=lambda e, fp=fpath: play_audio(fp)),
                                ft.IconButton(icon=ft.Icons.DELETE_OUTLINE, icon_color=ft.Colors.RED_400, icon_size=24, on_click=_make_del(fpath)),
                            ], spacing=0),
                        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                        bgcolor="white", border_radius=10, padding=ft.Padding(14, 6, 10, 10),
                        shadow=ft.BoxShadow(blur_radius=5, color=ft.Colors.with_opacity(0.07, "black")),
                    )
                    history_list.controls.append(tile)
                except Exception:
                    pass
        page.update()

    # ── Микрофон татах ─────────────────────────────────────────────────────
    async def load_devices():
        try:
            devices = await recorder.get_input_devices()
            device_map.clear()
            new_opts = [ft.dropdown.Option(key="default", text="🎙️  Default (системийн микрофон)")]
            for d in devices:
                key = str(d.id)
                device_map[key] = d
                short = d.label if len(d.label) <= 54 else d.label[:51] + "..."
                new_opts.append(ft.dropdown.Option(key=key, text=f"  [{d.id}]  {short}"))
            mic_dropdown.options = new_opts
            page.update()
        except Exception as ex:
            status_text.value = f"ℹ️  Микрофон жагсаалт авах боломжгүй: {ex}"
            page.update()

    # ── Товчнууд ───────────────────────────────────────────────────────────
    btn_row    = ft.Row(alignment=ft.MainAxisAlignment.CENTER, spacing=14)
    rec_btn    = make_btn("Бичиж эхлэх",   ft.Icons.MIC,        ft.Colors.RED_600,    width=200)
    pause_btn  = make_btn("Түр зогсоох",   ft.Icons.PAUSE,      ft.Colors.ORANGE_600, width=175)
    resume_btn = make_btn("Үргэлжлүүлэх", ft.Icons.PLAY_ARROW,  ft.Colors.BLUE_700,   width=175)
    finish_btn = make_btn("Дуусгах",       ft.Icons.CHECK,      ft.Colors.GREEN_700,  width=145)

    def _show_idle():
        btn_row.controls         = [rec_btn]
        mic_dropdown.disabled    = False
        format_dropdown.disabled = False
        timer_text.color         = ft.Colors.GREY_700
        page.update()

    def _show_recording():
        btn_row.controls         = [pause_btn, finish_btn]
        mic_dropdown.disabled    = True
        format_dropdown.disabled = True
        page.update()

    def _show_paused():
        btn_row.controls = [resume_btn, finish_btn]
        page.update()

    # ── Бичиж эхлэх ───────────────────────────────────────────────────────
    async def start_recording(e):
        if state["recording"]:
            return

        has_perm = await recorder.has_permission()
        if not has_perm:
            show_err("Микрофон ашиглах зөвшөөрөл олгоно уу! 🎙️")
            return

        timer_text.value = "00:00"

        # ── ЗАСВАР: Төхөөрөмж WAV дэмждэг эсэхийг шалгаж, үгүй бол AAC-LC (m4a) ашиглана ──
        encoder_to_use = ftar.AudioEncoder.WAV
        file_ext = "wav"
        try:
            is_wav_supported = await recorder.is_supported_encoder(ftar.AudioEncoder.WAV)
            if not is_wav_supported:
                encoder_to_use = ftar.AudioEncoder.AACLC
                file_ext = "m4a"
        except Exception:
            if is_android or is_ios:
                encoder_to_use = ftar.AudioEncoder.AACLC
                file_ext = "m4a"

        # Temp файлыг үргэлж апп-ын дотоод temp хавтаст үүсгэнэ
        if is_android:
            pkg = "com.enkhbat.audiorecorder"
            candidates = [
                f"/data/user/0/{pkg}/app_flutter",
            ]
            env_data = os.getenv("FLET_APP_STORAGE_DATA")
            if env_data:
                candidates.append(env_data)
            candidates.append(tempfile.gettempdir())
            
            app_temp = tempfile.gettempdir()
            for path in candidates:
                try:
                    os.makedirs(path, exist_ok=True)
                    test_fp = os.path.join(path, ".write_test")
                    with open(test_fp, "w") as f:
                        f.write("test")
                    os.remove(test_fp)
                    app_temp = path
                    break
                except Exception:
                    continue
        else:
            app_temp = tempfile.gettempdir()
            os.makedirs(app_temp, exist_ok=True)

        ts = time.strftime("%Y%m%d_%H%M%S")
        wav_fp = os.path.join(app_temp, f"_rec_{ts}.{file_ext}")

        rec_start = time.time()
        state.update({
            "wav_path":    wav_fp,
            "start_time":  rec_start,
            "rec_start_ts": rec_start,   # бичлэг эхэлсэн цаг — файл хайхад ашиглана
            "pause_accum": 0.0,
            "pause_start": None,
            "display_sec": 0.0,
        })

        sel_key = mic_dropdown.value
        sel_dev = device_map.get(sel_key) if sel_key != "default" else None

        config = ftar.AudioRecorderConfiguration(
            encoder=encoder_to_use,
            suppress_noise=True,
            cancel_echo=True,
            auto_gain=True,
            channels=1,
            sample_rate=44100,
            device=sel_dev,
        )
        try:
            ok = await recorder.start_recording(output_path=wav_fp, configuration=config)
            if ok is False:
                raise RuntimeError("Эхлүүлэх хариу ирсэнгүй")
            state["recording"] = True
            state["paused"]    = False
            status_text.value  = "🔴  Бичиж байна..."
            status_text.color  = ft.Colors.RED_600
            _show_recording()
            page.run_task(_timer_task)
        except Exception as ex:
            show_err(f"❌ Эхлэхэд алдаа: {ex}")

    # ── Түр зогсоох / Үргэлжлүүлэх ───────────────────────────────────────
    async def toggle_pause(e):
        if not state["recording"]:
            return
        try:
            if not state["paused"]:
                await recorder.pause_recording()
                state.update({"paused": True, "pause_start": time.time()})
                status_text.value = "⏸  Түр зогсоосон..."
                status_text.color = ft.Colors.ORANGE_600
                timer_text.color  = ft.Colors.ORANGE_600
                _show_paused()
            else:
                await recorder.resume_recording()
                if state["pause_start"]:
                    state["pause_accum"] += time.time() - state["pause_start"]
                state.update({"paused": False, "pause_start": None})
                status_text.value = "🔴  Бичиж байна..."
                status_text.color = ft.Colors.RED_600
                timer_text.color  = ft.Colors.RED_600
                _show_recording()
        except Exception as ex:
            show_err(f"❌ Үйлдэл амжилтгүй: {ex}")

    # ── Дуусгах ───────────────────────────────────────────────────────────
    async def finish_recording(e):
        if not state["recording"]:
            return
        try:
            # stop_recording() — recorder хаасан WAV/M4A файлын замыг буцаана
            saved  = await recorder.stop_recording()
            state["recording"] = False

            if state["pause_start"]:
                state["pause_accum"] += time.time() - state["pause_start"]

            elapsed = state["display_sec"]
            timer_text.value  = format_time(elapsed)
            timer_text.color  = ft.Colors.GREEN_700
            mn, sc = int(elapsed // 60), int(elapsed % 60)
            status_text.value = f"⏳  Хадгалж байна...  ⏱ {mn}:{sc:02d}"
            status_text.color = ft.Colors.BLUE_600
            _show_idle()

            rec_start_ts = state.get("rec_start_ts", time.time() - 3600)
            hint = state["wav_path"]

            actual_wav = None

            # ⭐ 1. stop_recording() буцаасан замыг ЭХЛЭЭД шалгана (Android-д энэ нь зөв зам)
            cleaned_saved = clean_path(saved)
            if cleaned_saved and os.path.exists(cleaned_saved) and os.path.getsize(cleaned_saved) > 0:
                actual_wav = cleaned_saved
                status_text.value = f"⏳  Файл олдлоо: {os.path.basename(cleaned_saved)}"
                page.update()

            # 2. Олдоогүй бол бүх хавтсаар хайна
            if actual_wav is None:
                if is_android or is_ios:
                    actual_wav = find_latest_wav_android(hint, rec_start_ts)
                else:
                    actual_wav = hint if hint and os.path.exists(hint) else None

            # Clean the found path just in case
            if actual_wav:
                actual_wav = clean_path(actual_wav)

            page.run_thread(_finalize, actual_wav, elapsed, saved)
        except Exception as ex:
            show_err(f"❌ Дуусгахад алдаа: {ex}")

    def _finalize(wav_fp: str | None, elapsed: float, saved_raw_path: str | None = None):
        ts     = time.strftime("%Y%m%d_%H%M%S")
        mn, sc = int(elapsed // 60), int(elapsed % 60)
        fmt    = format_dropdown.value
        target_dir = state["output_dir"]
        os.makedirs(target_dir, exist_ok=True)

        if wav_fp is None or not os.path.exists(wav_fp):
            env_data = os.getenv("FLET_APP_STORAGE_DATA", "байхгүй")
            pkg = "com.enkhbat.audiorecorder"
            cache_dir = f"/data/user/0/{pkg}/cache"
            app_flutter_dir = f"/data/user/0/{pkg}/app_flutter"
            
            cache_files = []
            if os.path.isdir(cache_dir):
                for dp, _, fns in os.walk(cache_dir):
                    for fn in fns:
                        cache_files.append(fn)
                        
            flutter_files = []
            if os.path.isdir(app_flutter_dir):
                for dp, _, fns in os.walk(app_flutter_dir):
                    for fn in fns:
                        flutter_files.append(fn)
                        
            cache_info = ", ".join(cache_files[:5]) if cache_files else "хоосон"
            flutter_info = ", ".join(flutter_files[:5]) if flutter_files else "хоосон"
            
            show_err(f"⚠️ Файл олдсонгүй.\nstop() буцаасан: {saved_raw_path}\nCache: {cache_info}\nFlutter: {flutter_info}")
            return

        if os.path.getsize(wav_fp) == 0:
            show_err("⚠️  Бичлэгийн файл хоосон байна. Микрофон зөв ажиллаж байгааг шалгана уу.")
            return

        # ── ЗАСВАР: Эх өргөтгөлийг хадгалах ──
        orig_ext = os.path.splitext(wav_fp)[1].lower() or ".wav"
        final = None

        # ── ЗАСВАР: shutil.move() → safe_copy_file() ──────────────────────
        if fmt == "mp3" and HAS_FFMPEG:
            mp3_fp = os.path.join(target_dir, f"Bichleg_{ts}_{mn}m{sc:02d}s.mp3")
            status_text.value = "⏳  MP3 болгож хөрвүүлж байна..."
            page.update()
            if wav_to_mp3(wav_fp, mp3_fp) and os.path.getsize(mp3_fp) > 0:
                try:
                    os.remove(wav_fp)
                except Exception:
                    pass
                final = mp3_fp
            else:
                # MP3 болгож чадахгүй бол эх өргөтгөлөөр нь хадгална
                dst_fp = os.path.join(target_dir, f"Bichleg_{ts}_{mn}m{sc:02d}s{orig_ext}")
                if safe_copy_file(wav_fp, dst_fp):
                    final = dst_fp
        else:
            # Эх өргөтгөлийг хадгална
            dst_fp = os.path.join(target_dir, f"Bichleg_{ts}_{mn}m{sc:02d}s{orig_ext}")
            if safe_copy_file(wav_fp, dst_fp):
                final = dst_fp
            else:
                # Хуулж чадаагүй → эх файл аль хавтаст байгааг шалгана
                show_err(f"⚠️  Файл хуулж чадсангүй. Эх зам: {wav_fp}")
                # Файл temp-д үлдсэн ч жагсаалтад харуулна
                final = wav_fp

        if final and os.path.exists(final) and os.path.getsize(final) > 0:
            sz = format_size(final)
            status_text.value = f"✅  Хадгалагдлаа!  💾 {sz}  ⏱ {mn}:{sc:02d}"
            status_text.color = ft.Colors.GREEN_700
            saved_dir = os.path.dirname(final)
            if saved_dir != state["output_dir"]:
                state["output_dir"] = saved_dir
                dir_text.value = f"📁 Хадгалах газар: {saved_dir}"
        else:
            status_text.value = "⚠️  Хадгалах үед алдаа гарлаа."
            status_text.color = ft.Colors.ORANGE_700

        load_history()

    # ── Шинэчлэх ──────────────────────────────────────────────────────────
    async def refresh_all(e):
        status_text.value = "🔄 Шинэчилж байна..."
        page.update()
        state["display_sec"] = 0.0
        timer_text.value = "00:00"
        timer_text.color = ft.Colors.GREY_700
        await load_devices()
        load_history()
        status_text.value = "🎙️ Шинэчлэгдлээ."
        status_text.color = ft.Colors.GREEN_700
        page.update()

    rec_btn.on_click    = lambda e: page.run_task(start_recording, e)
    pause_btn.on_click  = lambda e: page.run_task(toggle_pause, e)
    resume_btn.on_click = lambda e: page.run_task(toggle_pause, e)
    finish_btn.on_click = lambda e: page.run_task(finish_recording, e)

    _show_idle()

    # ── Нэвтрэх ───────────────────────────────────────────────────────────
    APP_PASSWORD    = "2026"
    login_container = ft.Container(visible=True,  expand=True)
    main_container  = ft.Container(visible=False, expand=True)
    pw_input = ft.TextField(
        label="Нууц үг", password=True, can_reveal_password=True,
        width=300, border_radius=8,
    )

    async def check_login(e):
        if pw_input.value == APP_PASSWORD:
            login_container.visible = False
            main_container.visible  = True
            page.update()
            await load_devices()
            load_history()
        else:
            show_err("Нууц үг буруу байна!")

    pw_input.on_submit = lambda e: page.run_task(check_login, e)

    def logout(e):
        if state["recording"]:
            show_err("⚠️  Бичлэг дуусгаад гарна уу!")
            return
        main_container.visible  = False
        login_container.visible = True
        pw_input.value          = ""
        timer_text.value        = "00:00"
        timer_text.color        = ft.Colors.GREY_700
        page.update()

    # ── Дэлгэц угсралт ────────────────────────────────────────────────────
    login_icon = (
        ft.Image(src=IMG_SRC, width=110, height=110)
        if IMG_SRC
        else ft.Icon(ft.Icons.MIC_EXTERNAL_ON, size=90, color=ft.Colors.BLUE_700)
    )
    login_container.content = ft.Column([
        login_icon,
        ft.Text("Ц.Энхбатын ухаалаг", size=22, weight=ft.FontWeight.BOLD),
        ft.Text("дуу хураагуур 🎙️",   size=22, weight=ft.FontWeight.BOLD),
        ft.Container(height=15),
        pw_input,
        ft.Container(height=10),
        ft.Button(
            content=ft.Text("Нэвтрэх", color="white"),
            bgcolor=ft.Colors.BLUE_700,
            on_click=lambda e: page.run_task(check_login, e),
            width=300, height=50,
        ),
    ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER)

    header = ft.Container(
        content=ft.Row([
            ft.Row([
                ft.Image(src=IMG_SRC, width=34, height=34) if IMG_SRC else ft.Icon(ft.Icons.MIC, color="white"),
                ft.Column([
                    ft.Text("Ц.Энхбатын ухаалаг дуу хураагуур", size=14, weight="bold", color="white"),
                    ft.Text("Хувийн хэрэгцээнд зориулав", size=10, color=ft.Colors.GREY_300),
                ]),
            ]),
            ft.Row([
                ft.IconButton(icon=ft.Icons.CREATE_NEW_FOLDER, icon_color=ft.Colors.GREEN_400,     tooltip="Хадгалах хавтас сонгох", on_click=choose_folder),
                ft.IconButton(icon=ft.Icons.FOLDER_OPEN,       icon_color=ft.Colors.YELLOW_300,    tooltip="Хавтас нээх",            on_click=open_folder_clicked),
                ft.IconButton(icon=ft.Icons.REFRESH,           icon_color=ft.Colors.LIGHT_BLUE_200,tooltip="Шинэчлэх",               on_click=lambda e: page.run_task(refresh_all, e)),
                ft.IconButton(icon=ft.Icons.LOGOUT,            icon_color=ft.Colors.RED_300,        tooltip="Гарах",                  on_click=logout),
            ], spacing=5),
        ], alignment="spaceBetween"),
        bgcolor="#1e3a8a", padding=ft.Padding(12, 6, 8, 8), border_radius=8,
    )

    main_container.content = ft.Column([
        header,
        ft.Container(height=10),
        ft.Card(content=ft.Container(
            content=ft.Column([mic_dropdown, ft.Row([format_dropdown])], spacing=10),
            padding=14,
        )),
        ft.Container(height=15),
        ft.Row([
            ft.Container(
                content=ft.Column([
                    timer_text,
                    ft.Text("Бичлэгийн хугацаа", size=11, color=ft.Colors.GREY_500),
                ], horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                bgcolor="white", border_radius=14,
                padding=ft.Padding(40, 20, 40, 20),
                shadow=ft.BoxShadow(blur_radius=8, color=ft.Colors.with_opacity(0.08, "black")),
            )
        ], alignment=ft.MainAxisAlignment.CENTER),
        ft.Container(height=15),
        btn_row,
        ft.Container(height=6),
        ft.Row([status_text], alignment=ft.MainAxisAlignment.CENTER),
        ft.Divider(height=18, color=ft.Colors.GREY_300),
        ft.Row([
            ft.Icon(ft.Icons.HISTORY, color=ft.Colors.GREY_700, size=18),
            ft.Text("Хадгалагдсан бичлэгүүд", weight=ft.FontWeight.BOLD, size=14),
        ]),
        ft.Container(content=history_list, expand=True, bgcolor="#EAECF0", border_radius=10),
        ft.Container(height=6),
        dir_text,
        ft.Container(height=6),
    ], expand=True, spacing=0)

    page.add(login_container, main_container)


if __name__ == "__main__":
    ft.app(main, assets_dir=ASSETS_DIR)
