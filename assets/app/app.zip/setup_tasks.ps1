# ══════════════════════════════════════════════════════════════
#  setup_tasks.ps1  —  Windows Task Scheduler тохируулах
#  PowerShell-д Administrator эрхтэй ажиллуулна
#  Хэрэглэх: Right-click → "Run with PowerShell"
# ══════════════════════════════════════════════════════════════

# ── ЗАМЫГ ӨӨРИЙН КОМПЬЮТЕРТ ТОХИРУУЛНА ──────────────────────
$ScriptFolder = "C:\Users\DELL\PycharmProjects\pythonProject"
$PythonPath   = "C:\Users\DELL\PycharmProjects\pythonProject\.venv\Scripts\python.exe"

$CheckinScript  = "$ScriptFolder\erp_auto_checkin.py"
$TaskUser       = $env:USERNAME                # одоогийн хэрэглэгч

# ── 1. ИРСЭН ЦАГ — Баасан 07:50 ─────────────────────────────
$actionIn  = New-ScheduledTaskAction `
    -Execute $PythonPath `
    -Argument "`"$CheckinScript`" checkin" `
    -WorkingDirectory $ScriptFolder

$triggerIn = New-ScheduledTaskTrigger `
    -Weekly `
    -DaysOfWeek Friday `
    -At "07:50AM"

$settingsIn = New-ScheduledTaskSettingsSet `
    -ExecutionTimeLimit (New-TimeSpan -Minutes 5) `
    -StartWhenAvailable `
    -RunOnlyIfNetworkAvailable

Register-ScheduledTask `
    -TaskName   "ERP_CheckIn_Friday" `
    -Action     $actionIn `
    -Trigger    $triggerIn `
    -Settings   $settingsIn `
    -RunLevel   Highest `
    -Force

Write-Host "✅ Check-IN даалгавар бүртгэгдлээ (Баасан 07:50)" -ForegroundColor Green

# ── 2. ЯВСАН ЦАГ — Баасан 17:30 ─────────────────────────────
$actionOut  = New-ScheduledTaskAction `
    -Execute $PythonPath `
    -Argument "`"$CheckinScript`" checkout" `
    -WorkingDirectory $ScriptFolder

$triggerOut = New-ScheduledTaskTrigger `
    -Weekly `
    -DaysOfWeek Friday `
    -At "05:30PM"

$settingsOut = New-ScheduledTaskSettingsSet `
    -ExecutionTimeLimit (New-TimeSpan -Minutes 5) `
    -StartWhenAvailable `
    -RunOnlyIfNetworkAvailable

Register-ScheduledTask `
    -TaskName   "ERP_CheckOut_Friday" `
    -Action     $actionOut `
    -Trigger    $triggerOut `
    -Settings   $settingsOut `
    -RunLevel   Highest `
    -Force

Write-Host "✅ Check-OUT даалгавар бүртгэгдлээ (Баасан 17:30)" -ForegroundColor Green

# ── 3. ШАЛГАХ ────────────────────────────────────────────────
Write-Host ""
Write-Host "── Бүртгэгдсэн даалгаврууд ──" -ForegroundColor Cyan
Get-ScheduledTask | Where-Object { $_.TaskName -like "ERP_Check*" } |
    Select-Object TaskName, State |
    Format-Table -AutoSize

Write-Host ""
Write-Host "Дуусгавар болов. Task Scheduler-д 'ERP_CheckIn_Friday' болон" -ForegroundColor Yellow
Write-Host "'ERP_CheckOut_Friday' нэртэй 2 даалгавар нэмэгдсэн байна." -ForegroundColor Yellow