import flet as ft
import json
import threading
import time
import os
import sys
import datetime
import asyncio


QUESTIONS_PER_TEST = 60
TIME_SECONDS = 3600  # 60 минут


def get_assets_path():
    # 1. Android Flet environment
    flet_assets = os.environ.get("FLET_ASSETS_DIR")
    if flet_assets:
        return flet_assets
    # 2. PyInstaller MEIPASS environment
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, "assets")
    # 3. Local development fallback
    base_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_dir, "assets")


def get_pdf_save_path(filename, page: ft.Page = None):
    # 0. On Web
    if page and page.web:
        return f"/tmp/{filename}"


    import platform
    # 1. On Android
    if os.environ.get("FLET_ASSETS_DIR") or os.path.exists("/system/build.prop"):
        # Try /storage/emulated/0/Download/Хуульчийн_Тест/ first
        try:
            download_dir = "/storage/emulated/0/Download/Хуульчийн_Тест"
            os.makedirs(download_dir, exist_ok=True)
            test_file = os.path.join(download_dir, filename)
            # Try to write dummy file to test access
            with open(test_file, "w") as f:
                f.write("")
            return test_file
        except Exception:
            # Fallback to App's public media directory which is always writable
            media_dir = "/storage/emulated/0/Android/media/com.enkhbat.lawyer"
            os.makedirs(media_dir, exist_ok=True)
            return os.path.join(media_dir, filename)
            
    # 2. On Windows / Desktop
    else:
        # Get real Windows Desktop path (resolving OneDrive and foreign language redirects)
        desktop_path = None
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders")
            path, _ = winreg.QueryValueEx(key, "Desktop")
            desktop_path = os.path.expandvars(path)
        except Exception:
            pass
            
        if not desktop_path or not os.path.exists(desktop_path):
            desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
            
        if not os.path.exists(desktop_path):
            desktop_path = os.path.expanduser("~")
            
        target_dir = os.path.join(desktop_path, "Хуульчийн_Тестийн_Үр_Дүн")
        os.makedirs(target_dir, exist_ok=True)
        return os.path.join(target_dir, filename)


def open_pdf(path, page: ft.Page):
    if page and page.web:
        return
    import os
    import platform
    import subprocess
    try:
        if platform.system() == "Windows":
            os.startfile(path)
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", path])
        else:
            # Android or Linux
            if os.path.exists("/system/build.prop"):
                try:
                    page.run_task(page.launch_url, f"file://{path}")
                except Exception:
                    page.snack_bar = ft.SnackBar(
                        ft.Text("Файлыг шууд нээх боломжгүй. Та утасныхаа Download/Хуульчийн_Тест хавтаснаас нээнү үү."),
                        open=True
                    )
                    page.update()
            else:
                subprocess.Popen(["xdg-open", path])
    except Exception as e:
        page.snack_bar = ft.SnackBar(
            ft.Text(f"Файлыг нээхэд алдаа гарлаа: {e}. Хадгалсан зам: {path}"),
            open=True
        )
        page.update()


def open_folder(path, page: ft.Page):
    if page and page.web:
        return
    import os
    import platform
    import subprocess
    try:
        if platform.system() == "Windows":
            # Highlight the file in Windows Explorer
            subprocess.run(['explorer.exe', '/select,', os.path.normpath(path)])
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", "-R", path])
        else:
            # On Linux/Android
            pass
    except Exception as e:
        page.snack_bar = ft.SnackBar(ft.Text(f"Хавтсыг нээхэд алдаа гарлаа: {e}"), open=True)
        page.update()


LAW_MAPPING = {
    1: "МОНГОЛ УЛСЫН ҮНДСЭН ХУУЛЬ",
    2: "МОНГОЛ УЛСЫН ҮНДСЭН ХУУЛЬ",
    3: "МОНГОЛ УЛСЫН ҮНДСЭН ХУУЛЬ",
    4: "МОНГОЛ УЛСЫН ҮНДСЭН ХУУЛЬ",
    5: "ИРГЭНИЙ ХУУЛЬ",
    6: "ЭРҮҮГИЙН ХУУЛЬ",
    7: "ЗАХИРГААНЫ ЕРӨНХИЙ ХУУЛЬ",
    8: "ИРГЭНИЙ ХЭРЭГ ШҮҮХЭД ХЯНАН ШИЙДВЭРЛЭХ ТУХАЙ ХУУЛЬ",
    9: "ЭРҮҮГИЙН ХЭРЭГ ХЯНАН ШИЙДВЭРЛЭХ ТУХАЙ ХУУЛЬ",
    10: "ҮНДСЭН ХУУЛИЙН ЦЭЦЭД МАРГААН ХЯНАН ШИЙДВЭРЛЭХ АЖИЛЛАГААНЫ ТУХАЙ ХУУЛЬ",
    11: "ЗӨРЧЛИЙН ТУХАЙ ХУУЛЬ",
    12: "ЗӨРЧИЛ ШАЛГАН ШИЙДВЭРЛЭХ ТУХАЙ ХУУЛЬ",
    13: "КОМПАНИЙН ТУХАЙ ХУУЛЬ",
    14: "ХӨДӨЛМӨРИЙН ТУХАЙ ХУУЛЬ (Шинэчилсэн найруулга)",
    15: "ӨМГӨӨЛЛИЙН ТУХАЙ ХУУЛЬ",
    16: "МОНГОЛ УЛСЫН ШҮҮХИЙН ТУХАЙ ХУУЛЬ (Шинэчилсэн найруулга)",
    17: "ХУУЛЬЧИЙН ЭРХ ЗҮЙН БАЙДЛЫН ТУХАЙ ХУУЛЬ",
    18: "ПРОКУРОРЫН ТУХАЙ ХУУЛЬ",
    19: "ТӨРИЙН АЛБАНЫ ТУХАЙ ХУУЛЬ",
    20: "ТӨРИЙН АЛБАН ХААГЧИЙН ЁС ЗҮЙН ТУХАЙ ХУУЛЬ",
    21: "МОНГОЛ УЛСЫН ЗАСАГ ЗАХИРГАА, НУТАГ ДЭВСГЭРИЙН НЭГЖ, ТҮҮНИЙ УДИРДЛАГЫН ТУХАЙ ХУУЛЬ",
    22: "МОНГОЛ УЛСЫН ХҮНИЙ ЭРХИЙН ҮНДЭСНИЙ КОМИССЫН ТУХАЙ ХУУЛЬ",
    23: "ЦАГДААГИЙН АЛБАНЫ ТУХАЙ ХУУЛЬ",
    24: "ДОТООДЫН ЦЭРГИЙН ТУХАЙ ХУУЛЬ",
    25: "ШҮҮХИЙН ШИЙДВЭР ГҮЙЦЭТГЭХ ТУХАЙ ХУУЛЬ",
    26: "ТӨРИЙН БОЛОН АЛБАНЫ НУУЦЫН ТУХАЙ ХУУЛЬ",
    27: "ХӨДӨЛМӨРИЙН АЮУЛГҮЙ БАЙДАЛ, ЭРҮҮЛ АХУЙН ТУХАЙ ХУУЛЬ",
    28: "АВТО ЗАМЫН ТУХАЙ ХУУЛЬ"
}

def get_law_name(q):
    if isinstance(q, dict) and "law" in q:
        return q["law"]
    q_id = q.get("id") if isinstance(q, dict) else None
    if q_id is not None:
        test_num = ((q_id - 1) // 40) + 1
        return LAW_MAPPING.get(test_num, "Тодорхойгүй хууль")
    return "Тодорхойгүй хууль"


def _find_font(names):
    # 0. Check if running inside Pyodide Web Wasm environment
    try:
        import js
        # Get origin in a worker-safe way
        origin = ""
        try:
            if hasattr(js, "window") and js.window:
                origin = js.window.location.origin
            elif hasattr(js, "self") and js.self:
                origin = js.self.location.origin
            else:
                origin = js.location.origin
        except Exception:
            pass

        if origin:
            for n in names:
                p = f"/tmp/{n}"
                if os.path.exists(p):
                    return p
                try:
                    url = f"{origin}/{n}"
                    from js import XMLHttpRequest
                    xhr = XMLHttpRequest.new()
                    xhr.open("GET", url, False)
                    xhr.overrideMimeType("text/plain; charset=x-user-defined")
                    xhr.send(None)
                    if xhr.status == 200:
                        text = xhr.responseText
                        data = bytes(ord(c) & 0xFF for c in text)
                        with open(p, "wb") as f:
                            f.write(data)
                        return p
                except Exception:
                    pass
    except Exception:
        pass

    import platform
    base_dir = os.path.dirname(os.path.abspath(__file__))
    dirs = [
        os.path.join(base_dir, "pyfonts"),
        base_dir,
        get_assets_path()
    ]
    if platform.system() == "Windows":
        win = os.environ.get("WINDIR", "C:\\Windows")
        dirs.extend([
            os.path.join(win, "Fonts"),
            os.path.join(os.path.expanduser("~"), "AppData\\Local\\Microsoft\\Windows\\Fonts")
        ])
    else:
        dirs.extend([
            "/system/fonts", # Android
            "/usr/share/fonts/truetype/dejavu", # Linux
            "/usr/share/fonts/truetype/freefont",
            "/usr/share/fonts/truetype/liberation"
        ])
    for n in names:
        for d in dirs:
            p = os.path.join(d, n)
            if os.path.exists(p):
                return p
    return None



def generate_pdf_report(pdf_path, test_num, results, total, score, pct, passed, user_info=None):
    from reportlab.lib.pagesizes import letter
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib import colors
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    
    reg_font = _find_font(["arial.ttf", "Roboto-Regular.ttf", "Roboto.ttf", "NotoSans-Regular.ttf", "NotoSans.ttf", "arialuni.ttf", "calibri.ttf", "segoeui.ttf", "DejaVuSans.ttf", "FreeSans.ttf"])
    bold_font = _find_font(["arialbd.ttf", "Roboto-Bold.ttf", "Roboto.ttf", "NotoSans-Bold.ttf", "NotoSans.ttf", "calibrib.ttf", "segoeuib.ttf", "DejaVuSans-Bold.ttf", "FreeSansBold.ttf"])
    
    font_name = 'Arial'
    if reg_font:
        try:
            pdfmetrics.registerFont(TTFont('Arial', reg_font))
        except Exception:
            font_name = 'Helvetica'
    else:
        font_name = 'Helvetica'

    bold_font_name = 'Arial-Bold'
    if bold_font:
        try:
            pdfmetrics.registerFont(TTFont('Arial-Bold', bold_font))
        except Exception:
            bold_font_name = 'Helvetica-Bold'
    else:
        bold_font_name = 'Helvetica-Bold'
        
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(
        'MongolianTitle',
        parent=styles['Heading1'],
        fontName=bold_font_name,
        fontSize=18,
        leading=22,
        textColor=colors.HexColor('#1A365D'),
        alignment=1, # Center
        spaceAfter=15
    )

    normal_style = ParagraphStyle(
        'MongolianNormal',
        parent=styles['Normal'],
        fontName=font_name,
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#2D3748')
    )

    green_style = ParagraphStyle(
        'MongolianGreen',
        parent=styles['Normal'],
        fontName=bold_font_name,
        fontSize=11,
        leading=15,
        textColor=colors.HexColor('#2F855A')
    )

    red_style = ParagraphStyle(
        'MongolianRed',
        parent=styles['Normal'],
        fontName=bold_font_name,
        fontSize=11,
        leading=15,
        textColor=colors.HexColor('#C53030')
    )
    
    story = []

    # Title
    story.append(Paragraph("⚖️ ХУУЛЬЧИЙН ШАЛГАЛТЫН ТЕСТИЙН ҮР ДҮН", title_style))
    story.append(Spacer(1, 10))

    # Info table
    info_data = []
    if user_info:
        info_data.extend([
            [Paragraph("<b>Сорил өгөгч:</b>", normal_style), Paragraph(f"{user_info.get('last_name', '')} {user_info.get('first_name', '')}", normal_style)],
            [Paragraph("<b>Нас / Хүйс:</b>", normal_style), Paragraph(f"{user_info.get('age', '')} настай ({user_info.get('gender', '')})", normal_style)],
        ])
    first_q = results[0][0] if results and len(results) > 0 else {}
    is_theory = False
    if isinstance(first_q, dict) and first_q.get("law") == "Эрх зүйн онол":
        is_theory = True
        
    test_title_pdf = f"Эрх зүйн онол-{test_num}" if is_theory else f"Тест {test_num} (Холимог тест)"

    info_data.extend([
        [Paragraph("<b>Тест:</b>", normal_style), Paragraph(test_title_pdf, normal_style)],
        [Paragraph("<b>Хугацаа:</b>", normal_style), Paragraph(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), normal_style)],
        [Paragraph("<b>Нийт асуулт:</b>", normal_style), Paragraph(str(total), normal_style)],
        [Paragraph("<b>Зөв хариулсан:</b>", normal_style), Paragraph(f"{score} ({pct}%)", green_style if passed else red_style)],
        [Paragraph("<b>Буруу хариулсан:</b>", normal_style), Paragraph(str(total - score), red_style if (total - score) > 0 else normal_style)],
        [Paragraph("<b>Шалгалтын төлөв:</b>", normal_style), Paragraph("ТЭНЦСЭН" if passed else "ТЭНЦСЭНГҮЙ", green_style if passed else red_style)]
    ])

    t_info = Table(info_data, colWidths=[150, 300])
    t_info.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#F7FAFC')),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor('#E2E8F0')),
        ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor('#EDF2F7')),
        ('PADDING', (0,0), (-1,-1), 8),
    ]))
    story.append(t_info)
    story.append(Spacer(1, 20))

    # Title for details
    story.append(Paragraph("<b>Дэлгэрэнгүй хариултууд:</b>", ParagraphStyle('Sub', parent=normal_style, fontName=bold_font_name, fontSize=14, spaceAfter=10)))

    law_style = ParagraphStyle(
        'MongolianLaw',
        parent=normal_style,
        fontName=bold_font_name,
        fontSize=9.5,
        leading=13,
        textColor=colors.HexColor('#1A365D'),
        spaceAfter=4
    )

    # Detail list
    for i, r in enumerate(results):
        is_corr = (r["user"] == r["correct"])
        lbl = "✅ Зөв" if is_corr else "❌ Буруу"
        lbl_style = green_style if is_corr else red_style
        
        opts = r.get("opts", {})
        if isinstance(opts, dict):
            user_text = f"{r['user']}) {opts.get(r['user'], r['user'])}"
            correct_text = f"{r['correct']}) {opts.get(r['correct'], r['correct'])}"
        else:
            user_text = r["user"]
            correct_text = r["correct"]
            
        law_name = get_law_name(r)
        q_story = []
        q_story.append(Paragraph(f"<b>{i+1}. {lbl}</b>", lbl_style))
        q_story.append(Paragraph(f"<b>⚖️ Хууль:</b> {law_name}", law_style))
        q_story.append(Paragraph(f"<b>Асуулт:</b> {r['q']}", normal_style))
        q_story.append(Paragraph(f"<b>Таны хариулт:</b> {user_text}", red_style if not is_corr else green_style))
        q_story.append(Paragraph(f"<b>Зөв хариулт:</b> {correct_text}", green_style))
        q_story.append(Paragraph(f"<i>Тайлбар:</i> {r['exp']}", ParagraphStyle('Exp', parent=normal_style, fontSize=9, textColor=colors.HexColor('#4A5568'))))
        
        # Table container for each question to style it nicely
        t_q = Table([[q_story]], colWidths=[460])
        bg_color = colors.HexColor('#F0FFF4') if is_corr else colors.HexColor('#FFF5F5')
        border_color = colors.HexColor('#38A169') if is_corr else colors.HexColor('#E53E3E')
        t_q.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,-1), bg_color),
            ('BOX', (0,0), (-1,-1), 1, border_color),
            ('PADDING', (0,0), (-1,-1), 10),
        ]))
        
        story.append(t_q)
        story.append(Spacer(1, 10))

    doc = SimpleDocTemplate(pdf_path, pagesize=letter, rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
    doc.build(story)



def main(page: ft.Page):
    import sys
    sys.stderr.write(f"PAGE_METHODS: {dir(page)}\n")
    sys.stderr.flush()
    prefs = ft.SharedPreferences()
    page.theme_mode = ft.ThemeMode.LIGHT
    page.title = "Ц.Энхбатын хуульчийн шалгалтанд бэлтгэх тест"
    page.scroll = "adaptive"

    # ── Өгөгдөл ачаалах ────────────────────────────────────────────
    try:
        import os
        import sys
        if getattr(sys, "frozen", False):
            meipass_path = os.path.join(sys._MEIPASS, "questions.json")
            exe_dir = os.path.dirname(sys.executable)
            exe_path = os.path.join(exe_dir, "questions.json")
            
            if os.path.exists(meipass_path):
                json_path = meipass_path
            elif os.path.exists(exe_path):
                json_path = exe_path
            else:
                json_path = meipass_path
        else:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            json_path = os.path.join(base_dir, "questions.json")

        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            raw_questions = data
        elif isinstance(data, dict) and "questions" in data:
            raw_questions = data["questions"]
        else:
            raise ValueError("JSON формат буруу")
        
        # Separate law and theory questions
        law_questions = [q for q in raw_questions if q.get("law") != "Эрх зүйн онол"]
        theory_questions = [q for q in raw_questions if q.get("law") == "Эрх зүйн онол"]

        import random
        shuffled_law = list(law_questions)
        random.seed(42)
        random.shuffle(shuffled_law)
        law_questions = shuffled_law
        
        # Do not shuffle theory questions to keep them in order (1 to 200)
    except Exception as e:
        page.add(ft.Text(f"Алдаа: questions.json файл олдсонгүй: {e}"))
        return

    # Тест тус бүрийн асуултыг хуваах
    def get_test_qs(test_type, test_num):
        if test_type == "theory":
            s = (test_num - 1) * 50
            return theory_questions[s: s + 50]
        else:
            s = (test_num - 1) * QUESTIONS_PER_TEST
            return law_questions[s: s + QUESTIONS_PER_TEST]

    total_mixed_tests = len(law_questions) // QUESTIONS_PER_TEST
    if len(law_questions) % QUESTIONS_PER_TEST:
        total_mixed_tests += 1

    total_theory_tests = len(theory_questions) // 50
    if len(theory_questions) % 50:
        total_theory_tests += 1

    # ── State ──────────────────────────────────────────────────────
    state = {
        "test_type": "mixed",
        "test_num": 1,
        "questions": [],
        "current_idx": 0,
        "score": 0,
        "user_results": [],
        "timer_active": False,
        "user_info": None,
        "password": "Eba2026*",
    }

    async def load_saved_password():
        await asyncio.sleep(2.0)
        try:
            saved_pwd = await prefs.get("user_password")
            if saved_pwd:
                state["password"] = saved_pwd
        except Exception as ex:
            import sys
            sys.stderr.write(f"Error loading saved password: {ex}\n")
            sys.stderr.flush()

    page.run_task(load_saved_password)

    async def close_app_async():
        try:
            await page.window.close()
        except TypeError:
            page.window.close()
        except Exception:
            try:
                await page.window.destroy()
            except Exception:
                try:
                    page.window.destroy()
                except Exception:
                    pass

    def exit_app(e):
        if page.web:
            # Show goodbye screen
            page.clean()
            page.add(
                ft.SafeArea(
                    ft.Column([
                        ft.Icon(ft.Icons.BALANCE, size=100, color="blue"),
                        ft.Text("Хуульчийн Тест", size=30, weight="bold", color="blue"),
                        ft.Container(height=20),
                        ft.Text("Шалгалтын бэлтгэл системээс гарлаа. Танд амжилт хүсье!", size=18, weight="bold", color="black"),
                        ft.Container(height=20),
                        ft.ElevatedButton("Дахин эхлүүлэх", on_click=show_registration_page, bgcolor=ft.Colors.BLUE_700, color=ft.Colors.WHITE),
                    ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    expand=True
                )
            )
            page.update()
            return

        if page.platform in (ft.PagePlatform.ANDROID, ft.PagePlatform.IOS):
            import os
            os._exit(0)
        else:
            try:
                page.run_task(close_app_async)
            except Exception:
                try:
                    page.window.destroy()
                except Exception:
                    import os
                    os._exit(0)


    # ── Бүртгэлийн хэсэг ──────────────────────────────────────────────
    txt_last_name = ft.TextField(label="Овог", width=340, bgcolor=ft.Colors.WHITE, border_radius=8)
    txt_first_name = ft.TextField(label="Нэр", width=340, bgcolor=ft.Colors.WHITE, border_radius=8)
    txt_age = ft.TextField(label="Нас", width=160, bgcolor=ft.Colors.WHITE, border_radius=8,
                           keyboard_type=ft.KeyboardType.NUMBER)
    dd_gender = ft.Dropdown(label="Хүйс", width=160, bgcolor=ft.Colors.WHITE, border_radius=8, value="Эрэгтэй",
                            options=[ft.dropdown.Option("Эрэгтэй"), ft.dropdown.Option("Эмэгтэй")])
    txt_password = ft.TextField(label="Нэвтрэх нууц үг", password=True, can_reveal_password=True,
                                width=340, bgcolor=ft.Colors.WHITE, border_radius=8)

    def start_test_click(e):
        if not txt_last_name.value or not txt_first_name.value or not txt_age.value or not txt_password.value:
            page.snack_bar = ft.SnackBar(ft.Text("⚠️ Овог, нэр, нас болон нэвтрэх нууц үгээ оруулна уу!"), bgcolor="red", open=True)
            page.update()
            return

        if txt_password.value.strip() != state["password"]:
            page.snack_bar = ft.SnackBar(ft.Text("❌ Нэвтрэх нууц үг буруу байна!"), bgcolor="red", open=True)
            page.update()
            return

        age_input = txt_age.value.strip()
        if not age_input.isdigit():
            page.snack_bar = ft.SnackBar(ft.Text("⚠️ Нас талбарт зөвхөн бүхэл тоо оруулна уу!"), bgcolor=ft.Colors.RED_700, open=True)
            page.update()
            return

        state["user_info"] = {
            "last_name": txt_last_name.value.strip(),
            "first_name": txt_first_name.value.strip(),
            "age": age_input,
            "gender": dd_gender.value,
        }
        show_menu()

    def open_change_password_dialog(e):
        txt_cur_pwd = ft.TextField(label="Одоогийн нууц үг", password=True, can_reveal_password=True, bgcolor=ft.Colors.WHITE, border_radius=8, width=300)
        txt_new_pwd = ft.TextField(label="Шинэ нууц үг", password=True, can_reveal_password=True, bgcolor=ft.Colors.WHITE, border_radius=8, width=300)
        txt_rep_pwd = ft.TextField(label="Шинэ нууц үг давтах", password=True, can_reveal_password=True, bgcolor=ft.Colors.WHITE, border_radius=8, width=300)

        def save_new_password(e):
            cur_val = txt_cur_pwd.value.strip()
            new_val = txt_new_pwd.value.strip()
            rep_val = txt_rep_pwd.value.strip()

            if not cur_val or not new_val or not rep_val:
                page.snack_bar = ft.SnackBar(ft.Text("⚠️ Бүх талбарыг оруулна уу!"), bgcolor="red", open=True)
                page.update()
                return

            if cur_val != state["password"]:
                page.snack_bar = ft.SnackBar(ft.Text("❌ Одоогийн нууц үг буруу байна!"), bgcolor="red", open=True)
                page.update()
                return

            if new_val != rep_val:
                page.snack_bar = ft.SnackBar(ft.Text("❌ Шинэ нууц үгнүүд зөрж байна!"), bgcolor="red", open=True)
                page.update()
                return

            if len(new_val) < 4:
                page.snack_bar = ft.SnackBar(ft.Text("⚠️ Шинэ нууц үг хамгийн багадаа 4 тэмдэгт байх ёстой!"), bgcolor="red", open=True)
                page.update()
                return

            async def do_save():
                await prefs.set("user_password", new_val)
                state["password"] = new_val
                pwd_dialog.open = False
                page.snack_bar = ft.SnackBar(ft.Text("✅ Нууц үг амжилттай солигдлоо!"), bgcolor="green", open=True)
                page.update()

            page.run_task(do_save)

        def close_pwd_dialog(e):
            pwd_dialog.open = False
            page.update()

        pwd_dialog = ft.AlertDialog(
            title=ft.Text("🔑 Нууц үг өөрчлөх", size=18, weight="bold"),
            content=ft.Column([
                txt_cur_pwd,
                txt_new_pwd,
                txt_rep_pwd
            ], spacing=12, tight=True, width=300),
            actions=[
                ft.TextButton("Хадгалах", on_click=save_new_password),
                ft.TextButton("Цуцлах", on_click=close_pwd_dialog)
            ],
            actions_alignment=ft.MainAxisAlignment.END,
        )

        page.overlay.append(pwd_dialog)
        pwd_dialog.open = True
        page.update()

    def show_registration_page(e=None):
        page.clean()
        
        has_logo = os.path.exists(os.path.join(get_assets_path(), "law_icon.png"))
        logo_src = os.path.join(get_assets_path(), "law_icon.png") if has_logo else None

        reg_card = ft.Container(
            content=ft.Column([
                ft.Image(src=logo_src, width=100, height=100) if logo_src else ft.Icon(ft.Icons.BALANCE, size=80, color="blue"),
                ft.Text("Хуульчийн Тест - Бүртгэл", size=24, weight="bold", color="blue"),
                ft.Container(height=10),
                txt_last_name,
                txt_first_name,
                ft.Row([txt_age, dd_gender], alignment=ft.MainAxisAlignment.CENTER, width=340, spacing=20),
                txt_password,
                ft.Container(height=15),
                ft.ElevatedButton(
                    content=ft.Row([ft.Icon(ft.Icons.PLAY_ARROW), ft.Text("Эхлүүлэх", weight="bold")], tight=True),
                    bgcolor=ft.Colors.BLUE_700,
                    color=ft.Colors.WHITE,
                    width=200,
                    height=45,
                    on_click=start_test_click
                ),
                ft.TextButton("🔑 Нууц үг өөрчлөх", on_click=open_change_password_dialog),
                ft.Container(height=10),
                ft.ElevatedButton("❌ Гарах", on_click=exit_app, width=120),

            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=12),
            padding=30,
            bgcolor="#F7FAFC",
            border_radius=16,
            border=ft.Border(
                top=ft.BorderSide(1, "#E2E8F0"),
                bottom=ft.BorderSide(1, "#E2E8F0"),
                left=ft.BorderSide(1, "#E2E8F0"),
                right=ft.BorderSide(1, "#E2E8F0")
            ),
            width=400,
            shadow=ft.BoxShadow(blur_radius=10, color=ft.Colors.with_opacity(0.1, "black"))
        )
        
        page.add(
            ft.SafeArea(
                ft.Row([reg_card], alignment=ft.MainAxisAlignment.CENTER, vertical_alignment=ft.CrossAxisAlignment.CENTER),
                expand=True
            )
        )


    timer_text = ft.Text(
        "Үлдсэн хугацаа: 60:00",
        size=20, weight="bold", color="red"
    )

    # ── Таймер ─────────────────────────────────────────────────────
    async def timer_loop():
        remaining = state.get("time_limit", TIME_SECONDS)
        while remaining > 0 and state["timer_active"]:
            mins, secs = divmod(remaining, 60)
            timer_text.value = f"Үлдсэн хугацаа: {mins:02d}:{secs:02d}"
            try:
                page.update()
            except Exception:
                pass
            await asyncio.sleep(1)
            remaining -= 1
        if state["timer_active"] and remaining <= 0:
            timer_text.value = "Хугацаа дууслаа!"
            try:
                page.update()
            except Exception:
                pass
            show_final_results()

    def start_timer():
        state["timer_active"] = True
        page.run_task(timer_loop)

    def stop_timer():
        state["timer_active"] = False


    # ══════════════════════════════════════════════════════════════
    #  ҮНДСЭН ЦЭС — тест сонгох
    # ══════════════════════════════════════════════════════════════
    def show_menu(e=None):
        stop_timer()
        page.clean()

        # Mixed tests cards
        mixed_cards = []
        for i in range(1, total_mixed_tests + 1):
            qs = get_test_qs("mixed", i)
            n = i  # lambda capture
            mixed_cards.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text(f"Тест {i}", size=22, weight="bold", color="black"),
                        ft.Text(f"Асуулт: {len(qs)}", size=14, color="grey"),
                        ft.Text("Хугацаа: 60 мин", size=14, color="grey"),
                        ft.ElevatedButton(
                            f"Тест {i} эхлүүлэх",
                            on_click=lambda e, num=n: start_test("mixed", num),
                        ),
                    ],
                    spacing=8,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=20,
                    margin=10,
                    border_radius=12,
                    border=ft.Border(
                        top=ft.BorderSide(2, "blue"),
                        bottom=ft.BorderSide(2, "blue"),
                        left=ft.BorderSide(2, "blue"),
                        right=ft.BorderSide(2, "blue"),
                    ),
                    width=200,
                )
            )

        # Theory tests cards
        theory_cards = []
        for i in range(1, total_theory_tests + 1):
            qs = get_test_qs("theory", i)
            n = i  # lambda capture
            theory_cards.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text(f"Онол {i}", size=22, weight="bold", color="black"),
                        ft.Text(f"Асуулт: {len(qs)}", size=14, color="grey"),
                        ft.Text("Хугацаа: 50 мин", size=14, color="grey"),
                        ft.ElevatedButton(
                            f"Онол {i} эхлүүлэх",
                            on_click=lambda e, num=n: start_test("theory", num),
                        ),
                    ],
                    spacing=8,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=20,
                    margin=10,
                    border_radius=12,
                    border=ft.Border(
                        top=ft.BorderSide(2, "green"),
                        bottom=ft.BorderSide(2, "green"),
                        left=ft.BorderSide(2, "green"),
                        right=ft.BorderSide(2, "green"),
                    ),
                    width=200,
                )
            )

        tabs = ft.Tabs(
            selected_index=0,
            animation_duration=300,
            tabs=[
                ft.Tab(
                    text="⚖️ Холимог шалгалтууд",
                    content=ft.Container(
                        content=ft.Column([
                            ft.Row(mixed_cards, wrap=True, alignment=ft.MainAxisAlignment.CENTER)
                        ], scroll=ft.ScrollMode.AUTO),
                        padding=10
                    )
                ),
                ft.Tab(
                    text="📚 Эрх зүйн онол",
                    content=ft.Container(
                        content=ft.Column([
                            ft.Row(theory_cards, wrap=True, alignment=ft.MainAxisAlignment.CENTER)
                        ], scroll=ft.ScrollMode.AUTO),
                        padding=10
                    )
                )
            ],
            expand=1
        )

        user_info = state["user_info"]
        page.add(
            ft.SafeArea(
                ft.Column([
                    ft.Text("⚖️ Хуульчийн шалгалтын тест",
                            size=28, weight="bold", color="black"),
                    ft.Container(
                        content=ft.Row([
                            ft.Icon(ft.Icons.PERSON, color=ft.Colors.BLUE_800),
                            ft.Text(f"Сорил өгөгч: {user_info['last_name']} {user_info['first_name']} ({user_info['gender']}, {user_info['age']} настай)", weight="bold", color=ft.Colors.BLUE_800, size=15),
                        ], alignment=ft.MainAxisAlignment.CENTER),
                        padding=10,
                        bgcolor="#EBF8FF",
                        border_radius=8,
                        border=ft.Border(
                            top=ft.BorderSide(1, "#BEE3F8"),
                            bottom=ft.BorderSide(1, "#BEE3F8"),
                            left=ft.BorderSide(1, "#BEE3F8"),
                            right=ft.BorderSide(1, "#BEE3F8")
                        ),
                        width=500
                    ),
                    ft.Text(
                        f"Нийт {len(raw_questions)} асуулт  |  "
                        f"{total_mixed_tests} холимог тест, {total_theory_tests} онолын тест",
                        size=15, color="grey"
                    ),
                    ft.Container(content=tabs, expand=True, width=1000),
                    ft.Row([
                        ft.ElevatedButton(
                            content=ft.Row([ft.Icon(ft.Icons.ARROW_BACK, size=18), ft.Text("Бүртгэл засах")], tight=True),
                            on_click=show_registration_page
                        ),
                        ft.ElevatedButton(
                            content=ft.Row([ft.Icon(ft.Icons.EXIT_TO_APP, size=18), ft.Text("Програмаас гарах")], tight=True),
                            on_click=exit_app
                        ),
                    ], alignment=ft.MainAxisAlignment.CENTER, spacing=15),
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=16),
                expand=True
            )
        )

    # ══════════════════════════════════════════════════════════════
    #  ТЕСТ ЭХЛҮҮЛЭХ
    # ══════════════════════════════════════════════════════════════
    def start_test(test_type, test_num, e=None):
        state["test_type"]    = test_type
        state["test_num"]     = test_num
        state["questions"]    = get_test_qs(test_type, test_num)
        state["current_idx"]  = 0
        state["score"]        = 0
        state["user_results"] = []
        state["time_limit"]   = 3000 if test_type == "theory" else 3600
        start_timer()
        show_question()

    # ══════════════════════════════════════════════════════════════
    #  АСУУЛТ ХАРУУЛАХ
    # ══════════════════════════════════════════════════════════════
    def show_question():
        page.clean()
        idx = state["current_idx"]
        qs  = state["questions"]
        q   = qs[idx]

        # options нь {"A": "...", "B": "...", ...} эсвэл list байж болно
        opts = q.get("options", {})
        if isinstance(opts, dict):
            radio_options = [
                ft.ListTile(
                    leading=ft.Radio(value=letter, fill_color="blue"),
                    title=ft.Text(f"{letter})  {text}", size=15, color="black"),
                    toggle_inputs=True,
                    shape=ft.RoundedRectangleBorder(radius=8),
                    hover_color=ft.Colors.BLUE_50,
                )
                for letter, text in opts.items()
            ]
            correct_val = q.get("correct", "")
        else:
            # хуучин list формат
            radio_options = [
                ft.ListTile(
                    leading=ft.Radio(value=opt, fill_color="blue"),
                    title=ft.Text(opt, size=15, color="black"),
                    toggle_inputs=True,
                    shape=ft.RoundedRectangleBorder(radius=8),
                    hover_color=ft.Colors.BLUE_50,
                )
                for opt in opts
            ]
            correct_val = q.get("correct", "")

        radio_group = ft.RadioGroup(
            content=ft.Column(radio_options, spacing=10)
        )

        def submit(e):
            if not radio_group.value:
                page.snack_bar = ft.SnackBar(
                    ft.Text("Хариултаа сонгоно уу!"), open=True
                )
                page.update()
                return

            chosen = radio_group.value
            is_correct = (chosen == correct_val)
            if is_correct:
                state["score"] += 1

            state["user_results"].append({
                "q":       q["question"],
                "user":    chosen,
                "correct": correct_val,
                "exp":     q.get("explanation", "Тайлбар байхгүй"),
                "opts":    opts,
                "id":      q["id"],
            })

            state["current_idx"] += 1
            if state["current_idx"] < len(qs):
                show_question()
            else:
                stop_timer()
                show_final_results()

        # Create a scrollable column to prevent content and buttons from cropping on mobile screens
        test_title = f"Эрх зүйн онол-{state['test_num']}" if state.get("test_type") == "theory" else f"Тест {state['test_num']}"
        question_content = ft.Column([
            timer_text,
            ft.Text(
                f"{test_title}  |  "
                f"Асуулт {idx + 1}/{len(qs)}",
                weight="bold", color="black", size=16
            ),
            ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.BALANCE, color="blue", size=16),
                    ft.Text(f"Хууль: {get_law_name(q)}", size=14, weight="bold", color="blue"),
                ], tight=True),
                padding=8,
                bgcolor="#EBF8FF",
                border_radius=6,
                margin=ft.Margin.only(bottom=5)
            ),
            ft.Text(q["question"], size=18, color="black", weight="bold"),
            radio_group,
            ft.Container(height=10),
            ft.Row([
                ft.ElevatedButton("Дараагийнх →", on_click=submit),
                ft.ElevatedButton("🏠 Цэс рүү буцах", on_click=show_menu),
                ft.ElevatedButton("❌ Гарах", on_click=exit_app),
            ], wrap=True, spacing=10),
        ], scroll=ft.ScrollMode.AUTO, expand=True, spacing=15)

        page.add(ft.SafeArea(question_content, expand=True))

    # ══════════════════════════════════════════════════════════════
    #  ҮР ДҮН
    # ══════════════════════════════════════════════════════════════
    def show_final_results(e=None):
        stop_timer()
        page.clean()

        qs      = state["questions"]
        score   = state["score"]
        results = state["user_results"]
        total   = len(qs)
        pct     = round(score / total * 100) if total else 0
        passed  = pct >= 60

        results_col = ft.Column(spacing=10)

        # Оноо
        test_title = f"Эрх зүйн онол-{state['test_num']}" if state.get("test_type") == "theory" else f"Тест {state['test_num']}"
        results_col.controls.append(
            ft.Container(
                ft.Column([
                    ft.Text(
                        f"{test_title} дууслаа!",
                        size=22, weight="bold", color="black"
                    ),
                    ft.Text(
                        f"Оноо: {score}/{total}  ({pct}%)",
                        size=28, weight="bold",
                        color="green" if passed else "red"
                    ),
                    ft.Text(
                        "✅ ТЭНЦЛЭЭ" if passed else "❌ ТЭНЦСЭНГҮЙ",
                        size=18, weight="bold",
                        color="green" if passed else "red"
                    ),
                    ft.Row([
                        ft.Text(f"Зөв: {score}", color="green", size=15),
                        ft.Text(f"  Буруу: {total - score}", color="red", size=15),
                    ]),
                ], spacing=6),
                padding=20, margin=10, border_radius=10,
                bgcolor="#F0FFF4" if passed else "#FFF0F0",
                border=ft.Border(
                    top=ft.BorderSide(2, "green" if passed else "red"),
                    bottom=ft.BorderSide(2, "green" if passed else "red"),
                    left=ft.BorderSide(2, "green" if passed else "red"),
                    right=ft.BorderSide(2, "green" if passed else "red"),
                ),
            )
        )

        # Дэлгэрэнгүй хариулт
        for r in results:
            is_corr  = (r["user"] == r["correct"])
            bc       = "green" if is_corr else "red"
            tc       = "green" if is_corr else "red"
            lbl      = "✅ Зөв" if is_corr else "❌ Буруу"

            # Хариулт текстийг гаргах
            opts = r.get("opts", {})
            if isinstance(opts, dict):
                user_text    = f"{r['user']}) {opts.get(r['user'], r['user'])}"
                correct_text = f"{r['correct']}) {opts.get(r['correct'], r['correct'])}"
            else:
                user_text    = r["user"]
                correct_text = r["correct"]

            results_col.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text(lbl, weight="bold", color=bc, size=14),
                        ft.Container(
                            content=ft.Row([
                                ft.Icon(ft.Icons.BALANCE, color="blue", size=14),
                                ft.Text(f"Хууль: {get_law_name(r)}", size=12, weight="bold", color="blue"),
                            ], tight=True),
                            padding=4,
                            bgcolor="#EBF8FF",
                            border_radius=4,
                            margin=ft.Margin.only(bottom=5)
                        ),
                        ft.Text(f"❓ {r['q']}",
                                weight="bold", color="black", size=14),
                        ft.Text(f"Таны хариулт:  {user_text}",
                                color=tc, size=13),
                        ft.Text(f"Зөв хариулт:   {correct_text}",
                                color="green", size=13),
                        ft.Text(f"💡 {r['exp']}",
                                italic=True, color="black", size=12),
                    ], spacing=4),
                    border=ft.Border(
                        top=ft.BorderSide(1, bc),
                        bottom=ft.BorderSide(1, bc),
                        left=ft.BorderSide(3, bc),
                        right=ft.BorderSide(1, bc),
                    ),
                    padding=12, margin=5, border_radius=6,
                    bgcolor="#F9FFF9" if is_corr else "#FFF9F9",
                )
            )

        # Товчнууд
        def download_pdf(e):
            try:
                user_info = state["user_info"]
                import datetime
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                # Remove non-alphanumeric chars from first name for filename safety
                first_name_clean = "".join(c for c in user_info["first_name"] if c.isalnum() or c in ("_", "-"))
                filename = f"Хуульчийн_Тест_Үр_Дүн_{first_name_clean}_{timestamp}.pdf"
                pdf_path = get_pdf_save_path(filename, page)
                
                # Generate PDF
                generate_pdf_report(
                    pdf_path=pdf_path,
                    test_num=state["test_num"],
                    results=results,
                    total=total,
                    score=score,
                    pct=pct,
                    passed=passed,
                    user_info=user_info
                )
                
                # Show success AlertDialog with Open File & Open Folder actions
                def close_dialog(e):
                    dialog.open = False
                    page.update()

                if page.web:
                    import base64
                    with open(pdf_path, "rb") as f:
                        pdf_data = f.read()

                    import js
                    import pyodide
                    try:
                        import pyodide.ffi
                        to_js = pyodide.ffi.to_js
                    except ImportError:
                        to_js = pyodide.to_js

                    js_bytes = to_js(pdf_data)
                    js_array = js.Array.new()
                    js_array.push(js_bytes)
                    js_options = js.JSON.parse('{"type": "application/pdf"}')
                    blob = js.Blob.new(js_array, js_options)
                    blob_url = js.URL.createObjectURL(blob)

                    dialog = ft.AlertDialog(
                        title=ft.Text("📄 PDF файл бэлэн боллоо", size=18, weight="bold"),
                        content=ft.Text("Таны шалгалтын үр дүнгийн PDF файлыг амжилттай үүсгэлээ. Доорх товчлуур дээр дарж татна уу эсвэл шинэ цонхонд нээнэ үү.", size=14),
                        actions=[
                            ft.TextButton(
                                "📥 PDF файлыг нээх / татах",
                                url=ft.controls.types.Url(blob_url, target="_blank"),
                                on_click=close_dialog
                            ),
                            ft.TextButton("Хаах", on_click=close_dialog)
                        ],
                        actions_alignment=ft.MainAxisAlignment.END,
                    )



                else:
                    dialog = ft.AlertDialog(
                        title=ft.Text("📄 PDF файл хадгалагдлаа", size=18, weight="bold"),
                        content=ft.Column([
                            ft.Text("Шалгалтын үр дүнг амжилттай хадгаллаа.", size=14),
                            ft.Text("Хадгалсан зам:", weight="bold", size=13),
                            ft.Container(
                                content=ft.Text(pdf_path, selectable=True, size=12, color="blue"),
                                padding=8,
                                bgcolor="#F7FAFC",
                                border=ft.Border(
                                    top=ft.BorderSide(1, "#E2E8F0"),
                                    bottom=ft.BorderSide(1, "#E2E8F0"),
                                    left=ft.BorderSide(1, "#E2E8F0"),
                                    right=ft.BorderSide(1, "#E2E8F0")
                                ),
                                border_radius=6
                            )
                        ], spacing=8, tight=True),
                        actions=[
                            ft.TextButton("📄 Файлыг нээх", on_click=lambda e: (open_pdf(pdf_path, page), close_dialog(None))),
                            ft.TextButton("📂 Хавтсыг нээх", on_click=lambda e: (open_folder(pdf_path, page), close_dialog(None))),
                            ft.TextButton("Хаах", on_click=close_dialog)
                        ],
                        actions_alignment=ft.MainAxisAlignment.END,
                    )
                page.overlay.append(dialog)
                dialog.open = True
                page.update()
            except Exception as ex:
                import traceback
                import sys
                tb_str = traceback.format_exc()
                sys.stderr.write(f"PDF_DOWNLOAD_ERROR:\n{tb_str}\n")
                sys.stderr.flush()
                import json
                js_tb = json.dumps(tb_str)
                try:
                    page.run_javascript(f"alert('Python PDF Error:\\n' + {js_tb})")
                except Exception:
                    pass
                page.snack_bar = ft.SnackBar(ft.Text(f"PDF үүсгэхэд алдаа гарлаа: {ex}"), open=True)
                page.update()



        results_col.controls.append(
            ft.Row([
                ft.ElevatedButton(
                    "🔄 Дахин өгөх",
                    on_click=lambda e: start_test(state.get("test_type", "mixed"), state["test_num"])
                ),
                ft.ElevatedButton(
                    "🏠 Тест сонгох",
                    on_click=show_menu
                ),
                ft.ElevatedButton(
                    "📄 PDF-ээр татах",
                    on_click=download_pdf
                ),
                ft.ElevatedButton(
                    "❌ Гарах",
                    on_click=exit_app
                ),
            ], wrap=True, alignment=ft.MainAxisAlignment.CENTER, spacing=12)
        )

        page.add(ft.SafeArea(results_col, expand=True))

    # ── Эхлэх ──────────────────────────────────────────────────────
    show_registration_page()


if __name__ == "__main__":
    ft.app(target=main)