import os
import sys
sys.path.append(r"C:\Users\DELL\PycharmProjects\pythonProject")
from law_parser import get_law_text

def main():
    law_name = "МОНГОЛ УЛСЫН ХҮНИЙ ЭРХИЙН ҮНДЭСНИЙ КОМИССЫН ТУХАЙ.doc"
    try:
        print(f"Reading '{law_name}'...")
        text = get_law_text(law_name)
        output_file = r"C:\Users\DELL\PycharmProjects\pythonProject\nhrc_law_text.txt"
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"Successfully saved to {output_file}. Length: {len(text)} characters.")
    except Exception as e:
        print("Error:", e)
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
