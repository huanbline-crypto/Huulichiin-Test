import os
import sys
from law_parser import get_law_text

def main():
    try:
        law_name = "КОМПАНИЙН ТУХАЙ.doc"
        print(f"Reading law: {law_name}")
        text = get_law_text(law_name)
        
        output_path = r"C:\Users\DELL\PycharmProjects\pythonProject\company_law_text.txt"
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"Successfully wrote law text to {output_path}")
        print(f"Total characters: {len(text)}")
    except Exception as e:
        print(f"Error occurred: {e}")

if __name__ == "__main__":
    main()
