import os
import sys
import argparse
import docx
import win32com.client as win32

LAWS_DIR = r"D:\AJIL\ALFA OMEGA\МИНИЙХ\ХУУЛЬЧИЙН СОНГОН ШАЛГАРУУЛАЛТ 2025\хуулиуд"

def list_laws():
    sys.stdout.reconfigure(encoding='utf-8')
    if not os.path.exists(LAWS_DIR):
        print(f"Алдаа: Хавтас олдсонгүй: {LAWS_DIR}")
        return
    
    print("--- БОЛОМЖИТ ХУУЛИУДЫН ЖАГСААЛТ ---")
    files = os.listdir(LAWS_DIR)
    valid_files = [f for f in files if f.lower().endswith(('.doc', '.docx'))]
    for idx, name in enumerate(sorted(valid_files)):
        print(f"[{idx+1}] {name}")

def read_docx(file_path):
    doc = docx.Document(file_path)
    full_text = []
    for para in doc.paragraphs:
        full_text.append(para.text)
    for table in doc.tables:
        for row in table.rows:
            row_text = [cell.text.strip() for cell in row.cells]
            full_text.append(" | ".join(row_text))
    return "\n".join(full_text)

def read_doc_via_word(file_path):
    # Convert .doc to temporary .docx using Word Application COM
    try:
        word = win32.gencache.EnsureDispatch('Word.Application')
    except Exception:
        # Fallback for some environment setups
        word = win32.Dispatch('Word.Application')
        
    word.Visible = False
    
    abs_path = os.path.abspath(file_path)
    temp_docx = abs_path + "x" # Append 'x' to make it .docx
    
    doc = word.Documents.Open(abs_path)
    doc.SaveAs2(temp_docx, FileFormat=16) # 16 is wdFormatXMLDocument (docx)
    doc.Close()
    word.Quit()
    
    # Read the temporary docx
    text = read_docx(temp_docx)
    
    # Clean up temp file
    if os.path.exists(temp_docx):
        os.remove(temp_docx)
        
    return text

def get_law_text(law_name):
    # Find file
    file_path = os.path.join(LAWS_DIR, law_name)
    if not os.path.exists(file_path):
        # Try finding case-insensitively
        files = os.listdir(LAWS_DIR)
        matched = [f for f in files if f.lower() == law_name.lower()]
        if matched:
            file_path = os.path.join(LAWS_DIR, matched[0])
        else:
            raise FileNotFoundError(f"Хуулийн файл олдсонгүй: {law_name}")
            
    if file_path.lower().endswith('.docx'):
        return read_docx(file_path)
    elif file_path.lower().endswith('.doc'):
        return read_doc_via_word(file_path)
    else:
        raise ValueError("Зөвхөн .doc эсвэл .docx файлуудыг дэмжинэ.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Хууль уншигч ба текст задлагч")
    parser.add_argument("--list", action="store_true", help="Бүх хуулийг жагсаах")
    parser.add_argument("--read", type=str, help="Хуулийн нэрийг зааж текст хөрвүүлэх")
    
    args = parser.parse_args()
    
    if args.list:
        list_laws()
    elif args.read:
        sys.stdout.reconfigure(encoding='utf-8')
        try:
            print(f"'{args.read}' хуулийг уншиж байна...")
            text = get_law_text(args.read)
            print("\n--- ХУУЛИЙН ТЕКСТ (ЭХНИЙ 2000 ТЭМДЭГТ) ---")
            print(text[:2000])
            print("\n-------------------------------------------")
            print(f"Нийт тэмдэгтийн тоо: {len(text)}")
        except Exception as e:
            print("Алдаа гарлаа:", e)
    else:
        parser.print_help()
