import sys
import os
sys.path.append(r"C:\Users\DELL\PycharmProjects\pythonProject")
from law_parser import get_law_text

try:
    text = get_law_text("ЭРҮҮГИЙН ХЭРЭГ ХЯНАН ШИЙДВЭРЛЭХ ТУХАЙ.doc")
    with open(r"C:\Users\DELL\PycharmProjects\pythonProject\crim_proc_text.txt", "w", encoding="utf-8") as f:
        f.write(text)
    print("SUCCESS")
except Exception as e:
    print("ERROR:", e)
