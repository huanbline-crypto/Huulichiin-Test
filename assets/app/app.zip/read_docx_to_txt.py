import docx
import os

docx_path = r"D:\AJIL\ALFA OMEGA\МИНИЙХ\ХУУЛЬЧИЙН СОНГОН ШАЛГАРУУЛАЛТ 2025\хуулиуд\ШҮҮХИЙН ШИЙДВЭР ГҮЙЦЭТГЭХ ТУХАЙ.docx"
txt_path = r"C:\Users\DELL\PycharmProjects\pythonProject\law_text.txt"

print(f"Reading {docx_path}...")
try:
    doc = docx.Document(docx_path)
    text = []
    for para in doc.paragraphs:
        text.append(para.text)
    
    # Also check tables if there are any
    for table in doc.tables:
        for row in table.rows:
            row_text = [cell.text for cell in row.cells]
            text.append(" | ".join(row_text))
            
    full_text = "\n".join(text)
    
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write(full_text)
        
    print(f"Saved {len(doc.paragraphs)} paragraphs to {txt_path}")
    print(f"Total character count: {len(full_text)}")
except Exception as e:
    print(f"Error: {e}")
