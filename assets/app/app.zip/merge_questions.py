import json
import os
import sys

def merge_batch(new_questions_file, test_num):
    sys.stdout.reconfigure(encoding='utf-8')
    
    if not os.path.exists("questions.json"):
        print("Error: questions.json not found!")
        return False
        
    try:
        with open("questions.json", "r", encoding="utf-8") as f:
            db = json.load(f)
    except Exception as e:
        print(f"Error loading questions.json: {e}")
        return False
        
    try:
        with open(new_questions_file, "r", encoding="utf-8") as f:
            new_qs = json.load(f)
    except Exception as e:
        print(f"Error loading {new_questions_file}: {e}")
        return False
        
    if not isinstance(new_qs, list):
        print(f"Error: {new_questions_file} must contain a list of questions.")
        return False
        
    # Get last ID
    last_id = db[-1]["id"] if db else 0
    print(f"Current database has {len(db)} questions. Last ID: {last_id}")
    print(f"New batch has {len(new_qs)} questions. Target Test Number: {test_num}")
    
    # Validate and re-index
    formatted_qs = []
    for idx, q in enumerate(new_qs):
        required_keys = ["question", "options", "correct", "correct_text", "explanation"]
        for key in required_keys:
            if key not in q:
                print(f"Error: Question at index {idx} is missing required key '{key}'")
                return False
                
        # Validate options keys
        opts = q["options"]
        if not isinstance(opts, dict) or sorted(opts.keys()) != ["A", "B", "C", "D"]:
            print(f"Error: Question at index {idx} options must be a dict with keys A, B, C, D. Got: {opts}")
            return False
            
        # Validate correct answer
        if q["correct"] not in ["A", "B", "C", "D"]:
            print(f"Error: Question at index {idx} correct must be A, B, C, or D. Got: {q['correct']}")
            return False
            
        new_id = last_id + 1 + idx
        formatted_q = {
            "id": new_id,
            "test": test_num,
            "question": q["question"],
            "options": q["options"],
            "correct": q["correct"],
            "correct_text": q["correct_text"],
            "explanation": q["explanation"]
        }
        formatted_qs.append(formatted_q)
        
    # Append to database
    db.extend(formatted_qs)
    
    # Save back
    try:
        with open("questions.json", "w", encoding="utf-8") as f:
            json.dump(db, f, indent=2, ensure_ascii=False)
        print(f"Successfully merged {len(formatted_qs)} questions. Total questions now: {len(db)}")
        return True
    except Exception as e:
        print(f"Error writing questions.json: {e}")
        return False

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python merge_questions.py <new_questions_file.json> <test_num>")
        sys.exit(1)
        
    file_path = sys.argv[1]
    try:
        t_num = int(sys.argv[2])
    except ValueError:
        print("Error: test_num must be an integer")
        sys.exit(1)
        
    success = merge_batch(file_path, t_num)
    if not success:
        sys.exit(1)
